typedef long __off_t;
typedef long __off64_t;
typedef unsigned long size_t;
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef unsigned long uint64;
struct __anonstruct_TIFFHeaderCommon_247895168 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_247895168 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_760666174 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_760666174 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_665510643 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_665510643 TIFFHeaderBig;
enum __anonenum_TIFFDataType_93392101 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_93392101 TIFFDataType;
struct tiff ;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint64 toff_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef void *thandle_t;
struct _IO_FILE ;
typedef struct _IO_FILE FILE;
typedef __builtin_va_list __gnuc_va_list;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef __gnuc_va_list va_list;
struct _TIFFField ;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray ;
typedef struct _TIFFFieldArray TIFFFieldArray;
struct __anonstruct_TIFFTagMethods_173844845 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_173844845 TIFFTagMethods;
struct __anonstruct_TIFFTagValue_185027364 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_185027364 TIFFTagValue;
struct __anonstruct_TIFFDirectory_699263496 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double *td_sminsamplevalue ;
   double *td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   float *td_refblackwhite ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_699263496 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_877458051 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_877458051 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_524461147 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_524461147 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
union __anonunion_tif_header_769774682 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_769774682 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   tmsize_t tif_rawdataoff ;
   tmsize_t tif_rawdataloaded ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   toff_t (*tif_seekproc)(thandle_t  , toff_t  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   toff_t (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   size_t tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   size_t tif_nfieldscompat ;
};
struct offset {
   uint32 tmargin ;
   uint32 lmargin ;
   uint32 bmargin ;
   uint32 rmargin ;
   uint32 crop_width ;
   uint32 crop_length ;
   uint32 startx ;
   uint32 endx ;
   uint32 starty ;
   uint32 endy ;
};
struct buffinfo {
   uint32 size ;
   unsigned char *buffer ;
};
struct zone {
   int position ;
   int total ;
};
struct pageseg {
   uint32 x1 ;
   uint32 x2 ;
   uint32 y1 ;
   uint32 y2 ;
   int position ;
   int total ;
   uint32 buffsize ;
};
struct coordpairs {
   double X1 ;
   double X2 ;
   double Y1 ;
   double Y2 ;
};
struct region {
   uint32 x1 ;
   uint32 x2 ;
   uint32 y1 ;
   uint32 y2 ;
   uint32 width ;
   uint32 length ;
   uint32 buffsize ;
   unsigned char *buffptr ;
};
struct crop_mask {
   double width ;
   double length ;
   double margins[4] ;
   float xres ;
   float yres ;
   uint32 combined_width ;
   uint32 combined_length ;
   uint32 bufftotal ;
   uint16 img_mode ;
   uint16 exp_mode ;
   uint16 crop_mode ;
   uint16 res_unit ;
   uint16 edge_ref ;
   uint16 rotation ;
   uint16 mirror ;
   uint16 invert ;
   uint16 photometric ;
   uint16 selections ;
   uint16 regions ;
   struct region regionlist[8] ;
   uint16 zones ;
   struct zone zonelist[8] ;
   struct coordpairs corners[8] ;
};
struct paperdef {
   char name[15] ;
   double width ;
   double length ;
   double asratio ;
};
struct image_data {
   float xres ;
   float yres ;
   uint32 width ;
   uint32 length ;
   uint16 res_unit ;
   uint16 bps ;
   uint16 spp ;
   uint16 planar ;
   uint16 photometric ;
   uint16 orientation ;
   uint16 compression ;
   uint16 adjustments ;
};
struct pagedef {
   char name[16] ;
   double width ;
   double length ;
   double hmargin ;
   double vmargin ;
   double hres ;
   double vres ;
   uint32 mode ;
   uint16 res_unit ;
   unsigned int rows ;
   unsigned int cols ;
   unsigned int orient ;
};
struct dump_opts {
   int debug ;
   int format ;
   int level ;
   char mode[4] ;
   char infilename[4097] ;
   char outfilename[4097] ;
   FILE *infile ;
   FILE *outfile ;
};
struct cpTag {
   uint16 tag ;
   uint16 count ;
   TIFFDataType type ;
};
static char tiffcrop_version_id[4]  = {      (char )'2',      (char )'.',      (char )'4',      (char )'\000'};
static char tiffcrop_rev_date[11]  = 
  {      (char )'1',      (char )'2',      (char )'-',      (char )'1', 
        (char )'3',      (char )'-',      (char )'2',      (char )'0', 
        (char )'1',      (char )'0',      (char )'\000'};
extern void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s , int __c ,
                                                                 size_t __n )  __attribute__((__nothrow__)) ;
extern char *( __attribute__((__nonnull__(1,2), __leaf__)) strcpy)(char * __restrict  __dest ,
                                                                   char const   * __restrict  __src )  __attribute__((__nothrow__)) ;
extern char *( __attribute__((__nonnull__(1,2), __leaf__)) strncpy)(char * __restrict  __dest ,
                                                                    char const   * __restrict  __src ,
                                                                    size_t __n )  __attribute__((__nothrow__)) ;
extern char *( __attribute__((__nonnull__(1,2), __leaf__)) strncat)(char * __restrict  __dest ,
                                                                    char const   * __restrict  __src ,
                                                                    size_t __n )  __attribute__((__nothrow__)) ;
extern int ( __attribute__((__nonnull__(1,2), __leaf__)) strcmp)(char const   *__s1 ,
                                                                 char const   *__s2 )  __attribute__((__pure__,
__nothrow__)) ;
extern int ( __attribute__((__nonnull__(1,2), __leaf__)) strncmp)(char const   *__s1 ,
                                                                  char const   *__s2 ,
                                                                  size_t __n )  __attribute__((__pure__,
__nothrow__)) ;
extern char *( __attribute__((__nonnull__(1), __leaf__)) strchr)(char const   *__s ,
                                                                 int __c )  __attribute__((__pure__,
__nothrow__)) ;
extern char *( __attribute__((__nonnull__(1,2), __leaf__)) strpbrk)(char const   *__s ,
                                                                    char const   *__accept )  __attribute__((__pure__,
__nothrow__)) ;
extern char *( __attribute__((__nonnull__(1,2), __leaf__)) strstr)(char const   *__haystack ,
                                                                   char const   *__needle )  __attribute__((__pure__,
__nothrow__)) ;
extern char *( __attribute__((__nonnull__(2), __leaf__)) strtok)(char * __restrict  __s ,
                                                                 char const   * __restrict  __delim )  __attribute__((__nothrow__)) ;
extern size_t ( __attribute__((__nonnull__(1), __leaf__)) strlen)(char const   *__s )  __attribute__((__pure__,
__nothrow__)) ;
extern struct _IO_FILE *stderr ;
extern int fclose(FILE *__stream ) ;
extern FILE *fopen(char const   * __restrict  __filename , char const   * __restrict  __modes ) ;
extern int fprintf(FILE * __restrict  __stream , char const   * __restrict  __format 
                   , ...) ;
extern int sprintf(char * __restrict  __s , char const   * __restrict  __format  , ...)  __attribute__((__nothrow__)) ;
extern int vfprintf(FILE * __restrict  __s , char const   * __restrict  __format ,
                    __gnuc_va_list __arg ) ;
extern int snprintf(char * __restrict  __s , size_t __maxlen , char const   * __restrict  __format 
                    , ...)  __attribute__((__nothrow__)) ;
extern int ( __attribute__((__leaf__)) sscanf)(char const   *__s , char const   *__format 
                                               , ...)  __asm__("__isoc99_sscanf") __attribute__((__nothrow__)) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size , size_t __n ,
                     FILE * __restrict  __s ) ;
extern char const   *TIFFGetVersion(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y , uint32 z ,
                             uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf , tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data , tmsize_t cc ) ;
extern double ( __attribute__((__nonnull__(1), __leaf__)) atof)(char const   *__nptr )  __attribute__((__pure__,
__nothrow__)) ;
extern int ( __attribute__((__nonnull__(1), __leaf__)) atoi)(char const   *__nptr )  __attribute__((__pure__,
__nothrow__)) ;
extern long ( __attribute__((__nonnull__(1), __leaf__)) atol)(char const   *__nptr )  __attribute__((__pure__,
__nothrow__)) ;
extern unsigned long ( __attribute__((__nonnull__(1), __leaf__)) strtoul)(char const   * __restrict  __nptr ,
                                                                          char ** __restrict  __endptr ,
                                                                          int __base )  __attribute__((__nothrow__)) ;
extern void ( __attribute__((__leaf__)) free)(void *__ptr )  __attribute__((__nothrow__)) ;
extern void ( __attribute__((__leaf__)) exit)(int __status )  __attribute__((__nothrow__,
__noreturn__)) ;
extern double ( __attribute__((__leaf__)) ceil)(double __x )  __attribute__((__nothrow__,
__const__)) ;
extern unsigned short const   **( __attribute__((__leaf__)) __ctype_b_loc)(void)  __attribute__((__nothrow__,
__const__)) ;
extern int ( __attribute__((__leaf__)) tolower)(int __c )  __attribute__((__nothrow__)) ;
extern char *optarg ;
extern int optind ;
extern int ( __attribute__((__nonnull__(2,3), __leaf__)) getopt)(int ___argc , char **___argv ,
                                                                 char const   *__shortopts )  __attribute__((__nothrow__)) ;
struct paperdef PaperTable[49]  = 
  {      {{(char )'d', (char )'e', (char )'f', (char )'a', (char )'u', (char )'l', (char )'t',
       (char )'\000'}, 8.500, 14.000, 0.607}, 
        {{(char )'p', (char )'a', (char )'4', (char )'\000'}, 8.264, 11.000, 0.751}, 
        {{(char )'l', (char )'e', (char )'t', (char )'t', (char )'e', (char )'r', (char )'\000'},
      8.500, 11.000, 0.773}, 
        {{(char )'l', (char )'e', (char )'g', (char )'a', (char )'l', (char )'\000'},
      8.500, 14.000, 0.607}, 
        {{(char )'h', (char )'a', (char )'l', (char )'f', (char )'-', (char )'l', (char )'e',
       (char )'t', (char )'t', (char )'e', (char )'r', (char )'\000'}, 8.500, 5.514,
      1.542}, 
        {{(char )'e', (char )'x', (char )'e', (char )'c', (char )'u', (char )'t', (char )'i',
       (char )'v', (char )'e', (char )'\000'}, 7.264, 10.528, 0.690}, 
        {{(char )'t', (char )'a', (char )'b', (char )'l', (char )'o', (char )'i', (char )'d',
       (char )'\000'}, 11.000, 17.000, 0.647}, 
        {{(char )'1', (char )'1', (char )'x', (char )'1', (char )'7', (char )'\000'},
      11.000, 17.000, 0.647}, 
        {{(char )'l', (char )'e', (char )'d', (char )'g', (char )'e', (char )'r', (char )'\000'},
      17.000, 11.000, 1.545}, 
        {{(char )'a', (char )'r', (char )'c', (char )'h', (char )'a', (char )'\000'},
      9.000, 12.000, 0.750}, 
        {{(char )'a', (char )'r', (char )'c', (char )'h', (char )'b', (char )'\000'},
      12.000, 18.000, 0.667}, 
        {{(char )'a', (char )'r', (char )'c', (char )'h', (char )'c', (char )'\000'},
      18.000, 24.000, 0.750}, 
        {{(char )'a', (char )'r', (char )'c', (char )'h', (char )'d', (char )'\000'},
      24.000, 36.000, 0.667}, 
        {{(char )'a', (char )'r', (char )'c', (char )'h', (char )'e', (char )'\000'},
      36.000, 48.000, 0.750}, 
        {{(char )'c', (char )'s', (char )'h', (char )'e', (char )'e', (char )'t', (char )'\000'},
      17.000, 22.000, 0.773}, 
        {{(char )'d', (char )'s', (char )'h', (char )'e', (char )'e', (char )'t', (char )'\000'},
      22.000, 34.000, 0.647}, 
        {{(char )'e', (char )'s', (char )'h', (char )'e', (char )'e', (char )'t', (char )'\000'},
      34.000, 44.000, 0.773}, 
        {{(char )'s', (char )'u', (char )'p', (char )'e', (char )'r', (char )'b', (char )'\000'},
      11.708, 17.042, 0.687}, 
        {{(char )'c', (char )'o', (char )'m', (char )'m', (char )'e', (char )'r', (char )'c',
       (char )'i', (char )'a', (char )'l', (char )'\000'}, 4.139, 9.528, 0.434}, 
        {{(char )'m', (char )'o', (char )'n', (char )'a', (char )'r', (char )'c', (char )'h',
       (char )'\000'}, 3.889, 7.528, 0.517}, 
        {{(char )'e', (char )'n', (char )'v', (char )'e', (char )'l', (char )'o', (char )'p',
       (char )'e', (char )'-', (char )'d', (char )'l', (char )'\000'}, 4.333, 8.681,
      0.499}, 
        {{(char )'e', (char )'n', (char )'v', (char )'e', (char )'l', (char )'o', (char )'p',
       (char )'e', (char )'-', (char )'c', (char )'5', (char )'\000'}, 6.389, 9.028,
      0.708}, 
        {{(char )'e', (char )'u', (char )'r', (char )'o', (char )'p', (char )'o', (char )'s',
       (char )'t', (char )'c', (char )'a', (char )'r', (char )'d', (char )'\000'},
      4.139, 5.833, 0.710}, 
        {{(char )'a', (char )'0', (char )'\000'}, 33.110, 46.811, 0.707}, 
        {{(char )'a', (char )'1', (char )'\000'}, 23.386, 33.110, 0.706}, 
        {{(char )'a', (char )'2', (char )'\000'}, 16.535, 23.386, 0.707}, 
        {{(char )'a', (char )'3', (char )'\000'}, 11.693, 16.535, 0.707}, 
        {{(char )'a', (char )'4', (char )'\000'}, 8.268, 11.693, 0.707}, 
        {{(char )'a', (char )'5', (char )'\000'}, 5.827, 8.268, 0.705}, 
        {{(char )'a', (char )'6', (char )'\000'}, 4.134, 5.827, 0.709}, 
        {{(char )'a', (char )'7', (char )'\000'}, 2.913, 4.134, 0.705}, 
        {{(char )'a', (char )'8', (char )'\000'}, 2.047, 2.913, 0.703}, 
        {{(char )'a', (char )'9', (char )'\000'}, 1.457, 2.047, 0.712}, 
        {{(char )'a', (char )'1', (char )'0', (char )'\000'}, 1.024, 1.457, 0.703}, 
        {{(char )'b', (char )'0', (char )'\000'}, 39.370, 55.669, 0.707}, 
        {{(char )'b', (char )'1', (char )'\000'}, 27.835, 39.370, 0.707}, 
        {{(char )'b', (char )'2', (char )'\000'}, 19.685, 27.835, 0.707}, 
        {{(char )'b', (char )'3', (char )'\000'}, 13.898, 19.685, 0.706}, 
        {{(char )'b', (char )'4', (char )'\000'}, 9.843, 13.898, 0.708}, 
        {{(char )'b', (char )'5', (char )'\000'}, 6.929, 9.843, 0.704}, 
        {{(char )'b', (char )'6', (char )'\000'}, 4.921, 6.929, 0.710}, 
        {{(char )'c', (char )'0', (char )'\000'}, 36.102, 51.063, 0.707}, 
        {{(char )'c', (char )'1', (char )'\000'}, 25.512, 36.102, 0.707}, 
        {{(char )'c', (char )'2', (char )'\000'}, 18.031, 25.512, 0.707}, 
        {{(char )'c', (char )'3', (char )'\000'}, 12.756, 18.031, 0.707}, 
        {{(char )'c', (char )'4', (char )'\000'}, 9.016, 12.756, 0.707}, 
        {{(char )'c', (char )'5', (char )'\000'}, 6.378, 9.016, 0.707}, 
        {{(char )'c', (char )'6', (char )'\000'}, 4.488, 6.378, 0.704}, 
        {{(char )'\000'}, 0.000, 0.000, 1.000}};
static int outtiled  =    -1;
static uint32 tilewidth  =    (uint32 )0;
static uint32 tilelength  =    (uint32 )0;
static uint16 config  =    (uint16 )0;
static uint16 compression  =    (uint16 )0;
static uint16 predictor  =    (uint16 )0;
static uint16 fillorder  =    (uint16 )0;
static uint32 rowsperstrip  =    (uint32 )0;
static uint32 g3opts  =    (uint32 )0;
static int ignore  =    0;
static uint32 defg3opts  =    (uint32 )-1;
static int quality  =    100;
static int jpegcolormode  =    0x0001;
static uint16 defcompression  =    (uint16 )-1;
static uint16 defpredictor  =    (uint16 )-1;
static int pageNum  =    0;
static int little_endian  =    1;
static int readContigStripsIntoBuffer(TIFF *in , uint8 *buf ) ;
static int readSeparateStripsIntoBuffer(TIFF *in , uint8 *obuf , uint32 length , uint32 width ,
                                        unsigned short spp , struct dump_opts *dump ) ;
static int readContigTilesIntoBuffer(TIFF *in , uint8 *buf , uint32 imagelength ,
                                     uint32 imagewidth , uint32 tw , uint32 tl , tsample_t spp ,
                                     uint16 bps ) ;
static int readSeparateTilesIntoBuffer(TIFF *in , uint8 *obuf , uint32 imagelength ,
                                       uint32 imagewidth , uint32 tw , uint32 tl ,
                                       unsigned short spp , uint16 bps ) ;
static int writeBufferToContigStrips(TIFF *out , uint8 *buf , uint32 imagelength ) ;
static int writeBufferToContigTiles(TIFF *out , uint8 *buf , uint32 imagelength ,
                                    uint32 imagewidth , tsample_t spp , struct dump_opts *dump ) ;
static int writeBufferToSeparateStrips(TIFF *out , uint8 *buf , uint32 length , uint32 width ,
                                       unsigned short spp , struct dump_opts *dump ) ;
static int writeBufferToSeparateTiles(TIFF *out , uint8 *buf , uint32 imagelength ,
                                      uint32 imagewidth , tsample_t spp , struct dump_opts *dump ) ;
static int extractContigSamplesToBuffer(uint8 *out , uint8 *in , uint32 rows , uint32 cols ,
                                        tsample_t sample , uint16 spp , uint16 bps ,
                                        struct dump_opts *dump ) ;
static int processCompressOptions(char *opt ) ;
static void usage(void) ;
static void initImageData(struct image_data *image ) ;
static void initCropMasks(struct crop_mask *cps ) ;
static void initPageSetup(struct pagedef *page , struct pageseg *pagelist , struct buffinfo *seg_buffs ) ;
static void initDumpOptions(struct dump_opts *dump ) ;
void process_command_opts(int argc , char **argv , char *mp , char *mode , uint32 *dirnum ,
                          uint16 *defconfig , uint16 *deffillorder , uint32 *deftilewidth ,
                          uint32 *deftilelength , uint32 *defrowsperstrip , struct crop_mask *crop_data ,
                          struct pagedef *page , struct dump_opts *dump , unsigned int *imagelist ,
                          unsigned int *image_count ) ;
static int update_output_file(TIFF **tiffout , char *mode , int autoindex , char *outname ,
                              unsigned int *page ) ;
static int get_page_geometry(char *name , struct pagedef *page ) ;
static int computeInputPixelOffsets(struct crop_mask *crop , struct image_data *image ,
                                    struct offset *off ) ;
static int computeOutputPixelOffsets(struct crop_mask *crop , struct image_data *image ,
                                     struct pagedef *page , struct pageseg *sections ,
                                     struct dump_opts *dump ) ;
static int loadImage(TIFF *in , struct image_data *image , struct dump_opts *dump ,
                     unsigned char **read_ptr ) ;
static int correct_orientation(struct image_data *image , unsigned char **work_buff_ptr ) ;
static int getCropOffsets(struct image_data *image , struct crop_mask *crop , struct dump_opts *dump ) ;
static int processCropSelections(struct image_data *image , struct crop_mask *crop ,
                                 unsigned char **read_buff_ptr , struct buffinfo *seg_buffs ) ;
static int writeSelections(TIFF *in , TIFF **out , struct crop_mask *crop , struct image_data *image ,
                           struct dump_opts *dump , struct buffinfo *seg_buffs , char *mp ,
                           char *filename , unsigned int *page , unsigned int total_pages ) ;
static int createImageSection(uint32 sectsize , unsigned char **sect_buff_ptr ) ;
static int extractImageSection(struct image_data *image , struct pageseg *section ,
                               unsigned char *src_buff , unsigned char *sect_buff ) ;
static int writeSingleSection(TIFF *in , TIFF *out , struct image_data *image , struct dump_opts *dump ,
                              uint32 width , uint32 length , double hres , double vres ,
                              unsigned char *sect_buff ) ;
static int writeImageSections(TIFF *in , TIFF *out , struct image_data *image , struct pagedef *page ,
                              struct pageseg *sections , struct dump_opts *dump ,
                              unsigned char *src_buff , unsigned char **sect_buff_ptr ) ;
static int createCroppedImage(struct image_data *image , struct crop_mask *crop ,
                              unsigned char **read_buff_ptr , unsigned char **crop_buff_ptr ) ;
static int writeCroppedImage(TIFF *in , TIFF *out , struct image_data *image , struct dump_opts *dump ,
                             uint32 width , uint32 length , unsigned char *crop_buff ,
                             int pagenum , int total_pages ) ;
static int rotateContigSamples8bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                    uint32 length , uint32 col , uint8 *src , uint8 *dst ) ;
static int rotateContigSamples16bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                     uint32 length , uint32 col , uint8 *src , uint8 *dst ) ;
static int rotateContigSamples24bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                     uint32 length , uint32 col , uint8 *src , uint8 *dst ) ;
static int rotateContigSamples32bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                     uint32 length , uint32 col , uint8 *src , uint8 *dst ) ;
static int rotateImage(uint16 rotation , struct image_data *image , uint32 *img_width ,
                       uint32 *img_length , unsigned char **ibuff_ptr ) ;
static int mirrorImage(uint16 spp , uint16 bps , uint16 mirror , uint32 width , uint32 length ,
                       unsigned char *ibuff ) ;
static int invertImage(uint16 photometric , uint16 spp , uint16 bps , uint32 width ,
                       uint32 length , unsigned char *work_buff ) ;
static int reverseSamples8bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                               uint8 *obuff ) ;
static int reverseSamples16bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                                uint8 *obuff ) ;
static int reverseSamples24bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                                uint8 *obuff ) ;
static int reverseSamples32bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                                uint8 *obuff ) ;
static int reverseSamplesBytes(uint16 spp , uint16 bps , uint32 width , uint8 *src ,
                               uint8 *dst ) ;
static int extractSeparateRegion(struct image_data *image , struct crop_mask *crop ,
                                 unsigned char *read_buff , unsigned char *crop_buff ,
                                 int region ) ;
static int extractCompositeRegions(struct image_data *image , struct crop_mask *crop ,
                                   unsigned char *read_buff , unsigned char *crop_buff ) ;
static int extractContigSamples8bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                     uint16 spp , uint16 bps , tsample_t count , uint32 start ,
                                     uint32 end ) ;
static int extractContigSamples16bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                      uint16 spp , uint16 bps , tsample_t count ,
                                      uint32 start , uint32 end ) ;
static int extractContigSamples24bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                      uint16 spp , uint16 bps , tsample_t count ,
                                      uint32 start , uint32 end ) ;
static int extractContigSamples32bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                      uint16 spp , uint16 bps , tsample_t count ,
                                      uint32 start , uint32 end ) ;
static int extractContigSamplesBytes(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                     uint16 spp , uint16 bps , tsample_t count , uint32 start ,
                                     uint32 end ) ;
static int extractContigSamplesShifted8bits(uint8 *in , uint8 *out , uint32 cols ,
                                            tsample_t sample , uint16 spp , uint16 bps ,
                                            tsample_t count , uint32 start , uint32 end ,
                                            int shift ) ;
static int extractContigSamplesShifted16bits(uint8 *in , uint8 *out , uint32 cols ,
                                             tsample_t sample , uint16 spp , uint16 bps ,
                                             tsample_t count , uint32 start , uint32 end ,
                                             int shift ) ;
static int extractContigSamplesShifted24bits(uint8 *in , uint8 *out , uint32 cols ,
                                             tsample_t sample , uint16 spp , uint16 bps ,
                                             tsample_t count , uint32 start , uint32 end ,
                                             int shift ) ;
static int extractContigSamplesShifted32bits(uint8 *in , uint8 *out , uint32 cols ,
                                             tsample_t sample , uint16 spp , uint16 bps ,
                                             tsample_t count , uint32 start , uint32 end ,
                                             int shift ) ;
static int extractContigSamplesToTileBuffer(uint8 *out , uint8 *in , uint32 rows ,
                                            uint32 cols , uint32 imagewidth , uint32 tilewidth___0 ,
                                            tsample_t sample , uint16 count , uint16 spp ,
                                            uint16 bps , struct dump_opts *dump ) ;
static int combineSeparateSamples8bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                       uint16 spp , uint16 bps , FILE *dumpfile ,
                                       int format , int level ) ;
static int combineSeparateSamples16bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                        uint16 spp , uint16 bps , FILE *dumpfile ,
                                        int format , int level ) ;
static int combineSeparateSamples24bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                        uint16 spp , uint16 bps , FILE *dumpfile ,
                                        int format , int level ) ;
static int combineSeparateSamples32bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                        uint16 spp , uint16 bps , FILE *dumpfile ,
                                        int format , int level ) ;
static int combineSeparateSamplesBytes(unsigned char **srcbuffs , unsigned char *out ,
                                       uint32 cols , uint32 rows , unsigned short spp ,
                                       uint16 bps , FILE *dumpfile , int format ,
                                       int level ) ;
static int combineSeparateTileSamples8bits(uint8 **in , uint8 *out , uint32 cols ,
                                           uint32 rows , uint32 imagewidth , uint32 tw ,
                                           uint16 spp , uint16 bps , FILE *dumpfile ,
                                           int format , int level ) ;
static int combineSeparateTileSamples16bits(uint8 **in , uint8 *out , uint32 cols ,
                                            uint32 rows , uint32 imagewidth , uint32 tw ,
                                            uint16 spp , uint16 bps , FILE *dumpfile ,
                                            int format , int level ) ;
static int combineSeparateTileSamples24bits(uint8 **in , uint8 *out , uint32 cols ,
                                            uint32 rows , uint32 imagewidth , uint32 tw ,
                                            uint16 spp , uint16 bps , FILE *dumpfile ,
                                            int format , int level ) ;
static int combineSeparateTileSamples32bits(uint8 **in , uint8 *out , uint32 cols ,
                                            uint32 rows , uint32 imagewidth , uint32 tw ,
                                            uint16 spp , uint16 bps , FILE *dumpfile ,
                                            int format , int level ) ;
static int combineSeparateTileSamplesBytes(unsigned char **srcbuffs , unsigned char *out ,
                                           uint32 cols , uint32 rows , uint32 imagewidth ,
                                           uint32 tw , unsigned short spp , uint16 bps ,
                                           FILE *dumpfile , int format , int level ) ;
static void dump_info(FILE *dumpfile , int format , char *prefix , char *msg  , ...) ;
static int dump_data(FILE *dumpfile , int format , char *dump_tag , unsigned char *data ,
                     uint32 count ) ;
static int dump_byte(FILE *dumpfile , int format , char *dump_tag , unsigned char data ) ;
static int dump_short(FILE *dumpfile , int format , char *dump_tag , uint16 data ) ;
static int dump_long(FILE *dumpfile , int format , char *dump_tag , uint32 data ) ;
static int dump_wide(FILE *dumpfile , int format , char *dump_tag , uint64 data ) ;
static int dump_buffer(FILE *dumpfile , int format , uint32 rows , uint32 width ,
                       uint32 row , unsigned char *buff ) ;
static char *usage_info[132]  = 
  {      "usage: tiffcrop [options] source1 ... sourceN  destination",      "where options are:",      " -h\t\tPrint this syntax listing",      " -v\t\tPrint tiffcrop version identifier and last revision date", 
        " ",      " -a\t\tAppend to output instead of overwriting",      " -d offset\tSet initial directory offset, counting first image as one, not zero",      " -p contig\tPack samples contiguously (e.g. RGBRGB...)", 
        " -p separate\tStore samples separately (e.g. RRR...GGG...BBB...)",      " -s\t\tWrite output in strips",      " -t\t\tWrite output in tiles",      " -i\t\tIgnore read errors", 
        " ",      " -r #\t\tMake each strip have no more than # rows",      " -w #\t\tSet output tile width (pixels)",      " -l #\t\tSet output tile length (pixels)", 
        " ",      " -f lsb2msb\tForce lsb-to-msb FillOrder for output",      " -f msb2lsb\tForce msb-to-lsb FillOrder for output",      "", 
        " -c lzw[:opts]\t Compress output with Lempel-Ziv & Welch encoding",      " -c zip[:opts]\t Compress output with deflate encoding",      " -c jpeg[:opts] Compress output with JPEG encoding",      " -c packbits\t Compress output with packbits encoding", 
        " -c g3[:opts]\t Compress output with CCITT Group 3 encoding",      " -c g4\t\t Compress output with CCITT Group 4 encoding",      " -c none\t Use no compression algorithm on output",      " ", 
        "Group 3 options:",      " 1d\t\tUse default CCITT Group 3 1D-encoding",      " 2d\t\tUse optional CCITT Group 3 2D-encoding",      " fill\t\tByte-align EOL codes", 
        "For example, -c g3:2d:fill to get G3-2D-encoded data with byte-aligned EOLs",      " ",      "JPEG options:",      " #\t\tSet compression quality level (0-100, default 100)", 
        " raw\t\tOutput color image as raw YCbCr",      " rgb\t\tOutput color image as RGB",      "For example, -c jpeg:rgb:50 to get JPEG-encoded RGB data with 50% comp. quality",      " ", 
        "LZW and deflate options:",      " #\t\tSet predictor value",      "For example, -c lzw:2 to get LZW-encoded data with horizontal differencing",      " ", 
        "Page and selection options:",      " -N odd|even|#,#-#,#|last         sequences and ranges of images within file to process",      "             The words odd or even may be used to specify all odd or even numbered images.",      "             The word last may be used in place of a number in the sequence to indicate.", 
        "             The final image in the file without knowing how many images there are.",      "             Numbers are counted from one even though TIFF IFDs are counted from zero.",      " ",      " -E t|l|r|b  edge to use as origin for width and length of crop region", 
        " -U units    [in, cm, px ] inches, centimeters or pixels",      " ",      " -m #,#,#,#  margins from edges for selection: top, left, bottom, right separated by commas",      " -X #        horizontal dimension of region to extract expressed in current units", 
        " -Y #        vertical dimension of region to extract expressed in current units",      " -Z #:#,#:#  zones of the image designated as position X of Y,",      "             eg 1:3 would be first of three equal portions measured from reference edge",      " -z x1,y1,x2,y2:...:xN,yN,xN+1,yN+1", 
        "             regions of the image designated by upper left and lower right coordinates",      "",      "Export grouping options:",      " -e c|d|i|m|s    export mode for images and selections from input images.", 
        "                 When exporting a composite image from multiple zones or regions",      "                 (combined and image modes), the selections must have equal sizes",      "                 for the axis perpendicular to the edge specified with -E.",      "    c|combined   All images and selections are written to a single file (default).", 
        "                 with multiple selections from one image combined into a single image.",      "    d|divided    All images and selections are written to a single file",      "                 with each selection from one image written to a new image.",      "    i|image      Each input image is written to a new file (numeric filename sequence)", 
        "                 with multiple selections from the image combined into one image.",      "    m|multiple   Each input image is written to a new file (numeric filename sequence)",      "                 with each selection from the image written to a new image.",      "    s|separated  Individual selections from each image are written to separate files.", 
        "",      "Output options:",      " -H #        Set horizontal resolution of output images to #",      " -V #        Set vertical resolution of output images to #", 
        " -J #        Set horizontal margin of output page to # expressed in current units",      "             when sectioning image into columns x rows using the -S cols:rows option",      " -K #        Set verticalal margin of output page to # expressed in current units",      "             when sectioning image into columns x rows using the -S cols:rows option", 
        " ",      " -O orient    orientation for output image, portrait, landscape, auto",      " -P page      page size for output image segments, eg letter, legal, tabloid, etc",      "              use #.#x#.# to specify a custom page size in the currently defined units", 
        "              where #.# represents the width and length",      " -S cols:rows Divide the image into equal sized segments using cols across and rows down.",      " ",      " -F hor|vert|both", 
        "             flip (mirror) image or region horizontally, vertically, or both",      " -R #        [90,180,or 270] degrees clockwise rotation of image or extracted region",      " -I [black|white|data|both]",      "             invert color space, eg dark to light for bilevel and grayscale images", 
        "             If argument is white or black, set the PHOTOMETRIC_INTERPRETATION ",      "             tag to MinIsBlack or MinIsWhite without altering the image data",      "             If the argument is data or both, the image data are modified:",      "             both inverts the data and the PHOTOMETRIC_INTERPRETATION tag,", 
        "             data inverts the data but not the PHOTOMETRIC_INTERPRETATION tag",      " ",      "-D opt1:value1,opt2:value2,opt3:value3:opt4:value4",      "             Debug/dump program progress and/or data to non-TIFF files.", 
        "             Options include the following and must be joined as a comma",      "             separate list. The use of this option is generally limited to",      "             program debugging and development of future options.",      " ", 
        "   debug:N   Display limited program progress indicators where larger N",      "             increase the level of detail. Note: Tiffcrop may be compiled with",      "             -DDEVELMODE to enable additional very low level debug reporting.",      "", 
        "   Format:txt|raw  Format any logged data as ASCII text or raw binary ",      "             values. ASCII text dumps include strings of ones and zeroes",      "             representing the binary values in the image data plus identifying headers.",      " ", 
        "   level:N   Specify the level of detail presented in the dump files.",      "             This can vary from dumps of the entire input or output image data to dumps",      "             of data processed by specific functions. Current range of levels is 1 to 3.",      " ", 
        "   input:full-path-to-directory/input-dumpname",      " ",      "   output:full-path-to-directory/output-dumpnaem",      " ", 
        "             When dump files are being written, each image will be written to a separate",      "             file with the name built by adding a numeric sequence value to the dumpname",      "             and an extension of .txt for ASCII dumps or .bin for binary dumps.",      " ", 
        "             The four debug/dump options are independent, though it makes little sense to",      "             specify a dump file without specifying a detail level.",      " ",      (char *)((void *)0)};
static int readContigTilesIntoBuffer(TIFF *in , uint8 *buf , uint32 imagelength ,
                                     uint32 imagewidth , uint32 tw , uint32 tl , tsample_t spp ,
                                     uint16 bps ) 
{ 
  int status ;
  tsample_t sample ;
  tsample_t count ;
  uint32 row ;
  uint32 col ;
  uint32 trow ;
  uint32 nrow ;
  uint32 ncol ;
  uint32 dst_rowsize ;
  uint32 shift_width ;
  uint32 bytes_per_sample ;
  uint32 bytes_per_pixel ;
  uint32 trailing_bits ;
  uint32 prev_trailing_bits ;
  uint32 tile_rowsize ;
  tmsize_t tmp ;
  uint32 src_offset ;
  uint32 dst_offset ;
  uint32 row_offset ;
  uint32 col_offset ;
  uint8 *bufp ;
  unsigned char *src ;
  unsigned char *dst ;
  tsize_t tbytes ;
  tsize_t tile_buffsize ;
  tsize_t tilesize ;
  tmsize_t tmp___0 ;
  unsigned char *tilebuf ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  uint32 tmp___3 ;
  int tmp___4 ;
  uint32 tmp___5 ;
  int tmp___6 ;
  uint32 tmp___7 ;
  int tmp___8 ;
  uint32 tmp___9 ;
  int tmp___10 ;
  uint32 tmp___11 ;
  int tmp___12 ;

  {
  status = 1;
  sample = (tsample_t )0;
  count = spp;
  tmp = TIFFTileRowSize(in);
  tile_rowsize = (uint32 )tmp;
  bufp = buf;
  src = (unsigned char *)((void *)0);
  dst = (unsigned char *)((void *)0);
  tbytes = (tsize_t )0;
  tile_buffsize = (tsize_t )0;
  tmp___0 = TIFFTileSize(in);
  tilesize = tmp___0;
  tilebuf = (unsigned char *)((void *)0);
  bytes_per_sample = (uint32 )(((int )bps + 7) / 8);
  bytes_per_pixel = (uint32 )(((int )bps * (int )spp + 7) / 8);
  if ((int )bps % 8 == 0) {
    shift_width = (uint32 )0;
  } else
  if (bytes_per_pixel < bytes_per_sample + 1U) {
    shift_width = bytes_per_pixel;
  } else {
    shift_width = bytes_per_sample + 1U;
  }
  tile_buffsize = tilesize;
  if (tilesize < (tsize_t )(tl * tile_rowsize)) {
    tile_buffsize = (tsize_t )(tl * tile_rowsize);
  }
  tmp___1 = _TIFFmalloc(tile_buffsize);
  tilebuf = (unsigned char *)tmp___1;
  if ((unsigned long )tilebuf == (unsigned long )((unsigned char *)0)) {
    return (0);
  }
  dst_rowsize = ((imagewidth * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < imagelength)) {
      goto while_break;
    }
    if (row + tl > imagelength) {
      nrow = imagelength - row;
    } else {
      nrow = tl;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < imagewidth)) {
        goto while_break___0;
      }
      tbytes = TIFFReadTile(in, (void *)tilebuf, col, row, (uint32 )0, (uint16 )0);
      if (tbytes < tilesize) {
        if (! ignore) {
          tmp___2 = TIFFFileName(in);
          TIFFError(tmp___2, (char const   *)"Error, can\'t read tile at row %lu col %lu, Read %lu bytes of %lu",
                    (unsigned long )col, (unsigned long )row, (unsigned long )tbytes,
                    (unsigned long )tilesize);
          status = 0;
          _TIFFfree((void *)tilebuf);
          return (status);
        }
      }
      row_offset = row * dst_rowsize;
      col_offset = ((col * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
      bufp = (buf + row_offset) + col_offset;
      if (col + tw > imagewidth) {
        ncol = imagewidth - col;
      } else {
        ncol = tw;
      }
      if ((int )bps % 8 == 0) {
        if ((int )count == (int )spp) {
          trow = (uint32 )0;
          {
          while (1) {
            while_continue___1: /* CIL Label */ ;

            if (! (trow < nrow)) {
              goto while_break___1;
            }
            src_offset = trow * tile_rowsize;
            _TIFFmemcpy((void *)bufp, (void const   *)(tilebuf + src_offset), (tmsize_t )(((ncol * (uint32 )spp) * (uint32 )bps) / 8U));
            bufp += ((imagewidth * (uint32 )bps) * (uint32 )spp) / 8U;
            trow ++;
          }
          while_break___5: /* CIL Label */ ;
          }
          while_break___1: ;
        } else {
          goto _L;
        }
      } else {
        _L: 
        trailing_bits = (uint32 )0;
        prev_trailing_bits = trailing_bits;
        trailing_bits = ((ncol * (uint32 )bps) * (uint32 )spp) % 8U;
        trow = (uint32 )0;
        {
        while (1) {
          while_continue___2: /* CIL Label */ ;

          if (! (trow < nrow)) {
            goto while_break___2;
          }
          src_offset = trow * tile_rowsize;
          src = tilebuf + src_offset;
          dst_offset = (row + trow) * dst_rowsize;
          dst = (buf + dst_offset) + col_offset;
          if (shift_width == 0U) {
            goto case_0;
          }
          if (shift_width == 1U) {
            goto case_1;
          }
          if (shift_width == 2U) {
            goto case_2;
          }
          if (shift_width == 5U) {
            goto case_5;
          }
          if (shift_width == 4U) {
            goto case_5;
          }
          if (shift_width == 3U) {
            goto case_5;
          }
          goto switch_default;
          case_0: 
          tmp___4 = extractContigSamplesBytes(src, dst, ncol, sample, spp, bps, count,
                                              (uint32 )0, ncol);
          if (tmp___4) {
            tmp___3 = TIFFCurrentTile(in);
            TIFFError((char const   *)"readContigTilesIntoBuffer", (char const   *)"Unable to extract row %d from tile %lu",
                      row, (unsigned long )tmp___3);
            return (1);
          }
          goto switch_break;
          case_1: 
          if ((int )bps == 1) {
            tmp___6 = extractContigSamplesShifted8bits(src, dst, ncol, sample, spp,
                                                       bps, count, (uint32 )0, ncol,
                                                       (int )prev_trailing_bits);
            if (tmp___6) {
              tmp___5 = TIFFCurrentTile(in);
              TIFFError((char const   *)"readContigTilesIntoBuffer", (char const   *)"Unable to extract row %d from tile %lu",
                        row, (unsigned long )tmp___5);
              return (1);
            }
            goto switch_break;
          } else {
            tmp___8 = extractContigSamplesShifted16bits(src, dst, ncol, sample, spp,
                                                        bps, count, (uint32 )0, ncol,
                                                        (int )prev_trailing_bits);
            if (tmp___8) {
              tmp___7 = TIFFCurrentTile(in);
              TIFFError((char const   *)"readContigTilesIntoBuffer", (char const   *)"Unable to extract row %d from tile %lu",
                        row, (unsigned long )tmp___7);
              return (1);
            }
          }
          goto switch_break;
          case_2: 
          tmp___10 = extractContigSamplesShifted24bits(src, dst, ncol, sample, spp,
                                                       bps, count, (uint32 )0, ncol,
                                                       (int )prev_trailing_bits);
          if (tmp___10) {
            tmp___9 = TIFFCurrentTile(in);
            TIFFError((char const   *)"readContigTilesIntoBuffer", (char const   *)"Unable to extract row %d from tile %lu",
                      row, (unsigned long )tmp___9);
            return (1);
          }
          goto switch_break;
          case_5: 
          tmp___12 = extractContigSamplesShifted32bits(src, dst, ncol, sample, spp,
                                                       bps, count, (uint32 )0, ncol,
                                                       (int )prev_trailing_bits);
          if (tmp___12) {
            tmp___11 = TIFFCurrentTile(in);
            TIFFError((char const   *)"readContigTilesIntoBuffer", (char const   *)"Unable to extract row %d from tile %lu",
                      row, (unsigned long )tmp___11);
            return (1);
          }
          goto switch_break;
          switch_default: 
          TIFFError((char const   *)"readContigTilesIntoBuffer", (char const   *)"Unsupported bit depth %d",
                    (int )bps);
          return (1);
          switch_break: 
          trow ++;
        }
        while_break___6: /* CIL Label */ ;
        }
        while_break___2: 
        prev_trailing_bits += trailing_bits;
      }
      col += tw;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___0: 
    row += tl;
  }
  while_break___3: /* CIL Label */ ;
  }
  while_break: 
  _TIFFfree((void *)tilebuf);
  return (status);
}
}
static int readSeparateTilesIntoBuffer(TIFF *in , uint8 *obuf , uint32 imagelength ,
                                       uint32 imagewidth , uint32 tw , uint32 tl ,
                                       unsigned short spp , uint16 bps ) 
{ 
  int i ;
  int status ;
  int sample ;
  int shift_width ;
  int bytes_per_pixel ;
  uint16 bytes_per_sample ;
  uint32 row ;
  uint32 col ;
  uint32 nrow ;
  uint32 ncol ;
  uint32 row_offset ;
  uint32 col_offset ;
  tsize_t tbytes ;
  tsize_t tilesize ;
  tmsize_t tmp ;
  tsample_t s ;
  uint8 *bufp ;
  unsigned char *srcbuffs[8] ;
  unsigned char *tbuff ;
  void *tmp___0 ;
  char const   *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;

  {
  status = 1;
  tbytes = (tsize_t )0;
  tmp = TIFFTileSize(in);
  tilesize = tmp;
  bufp = obuf;
  tbuff = (unsigned char *)((void *)0);
  bytes_per_sample = (uint16 )(((int )bps + 7) / 8);
  sample = 0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (sample < (int )spp) {
      if (! (sample < 8)) {
        goto while_break;
      }
    } else {
      goto while_break;
    }
    srcbuffs[sample] = (unsigned char *)((void *)0);
    tmp___0 = _TIFFmalloc(tilesize + 8L);
    tbuff = (unsigned char *)tmp___0;
    if (! tbuff) {
      TIFFError((char const   *)"readSeparateTilesIntoBuffer", (char const   *)"Unable to allocate tile read buffer for sample %d",
                sample);
      i = 0;
      {
      while (1) {
        while_continue___0: /* CIL Label */ ;

        if (! (i < sample)) {
          goto while_break___0;
        }
        _TIFFfree((void *)srcbuffs[i]);
        i ++;
      }
      while_break___7: /* CIL Label */ ;
      }
      while_break___0: ;
      return (0);
    }
    srcbuffs[sample] = tbuff;
    sample ++;
  }
  while_break___6: /* CIL Label */ ;
  }
  while_break: 
  row = (uint32 )0;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (row < imagelength)) {
      goto while_break___1;
    }
    if (row + tl > imagelength) {
      nrow = imagelength - row;
    } else {
      nrow = tl;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! (col < imagewidth)) {
        goto while_break___2;
      }
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___3: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___3;
        }
        s = s;
        tbytes = TIFFReadTile(in, (void *)srcbuffs[s], col, row, (uint32 )0, s);
        if (tbytes < 0L) {
          if (! ignore) {
            tmp___1 = TIFFFileName(in);
            TIFFError(tmp___1, (char const   *)"Error, can\'t read tile for row %lu col %lu, sample %lu",
                      (unsigned long )col, (unsigned long )row, (unsigned long )s);
            status = 0;
            sample = 0;
            {
            while (1) {
              while_continue___4: /* CIL Label */ ;

              if (sample < (int )spp) {
                if (! (sample < 8)) {
                  goto while_break___4;
                }
              } else {
                goto while_break___4;
              }
              tbuff = srcbuffs[sample];
              if ((unsigned long )tbuff != (unsigned long )((void *)0)) {
                _TIFFfree((void *)tbuff);
              }
              sample ++;
            }
            while_break___11: /* CIL Label */ ;
            }
            while_break___4: ;
            return (status);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___10: /* CIL Label */ ;
      }
      while_break___3: ;
      if (col + tw > imagewidth) {
        ncol = imagewidth - col;
      } else {
        ncol = tw;
      }
      row_offset = row * (((imagewidth * (uint32 )spp) * (uint32 )bps + 7U) / 8U);
      col_offset = ((col * (uint32 )spp) * (uint32 )bps + 7U) / 8U;
      bufp = (obuf + row_offset) + col_offset;
      if ((int )bps % 8 == 0) {
        tmp___2 = combineSeparateTileSamplesBytes(srcbuffs, bufp, ncol, nrow, imagewidth,
                                                  tw, spp, bps, (FILE *)((void *)0),
                                                  0, 0);
        if (tmp___2) {
          status = 0;
          goto while_break___2;
        }
      } else {
        bytes_per_pixel = ((int )bps * (int )spp + 7) / 8;
        if (bytes_per_pixel < (int )bytes_per_sample + 1) {
          shift_width = bytes_per_pixel;
        } else {
          shift_width = (int )bytes_per_sample + 1;
        }
        if (shift_width == 1) {
          goto case_1;
        }
        if (shift_width == 2) {
          goto case_2;
        }
        if (shift_width == 3) {
          goto case_3;
        }
        if (shift_width == 8) {
          goto case_8;
        }
        if (shift_width == 7) {
          goto case_8;
        }
        if (shift_width == 6) {
          goto case_8;
        }
        if (shift_width == 5) {
          goto case_8;
        }
        if (shift_width == 4) {
          goto case_8;
        }
        goto switch_default;
        case_1: 
        tmp___3 = combineSeparateTileSamples8bits(srcbuffs, bufp, ncol, nrow, imagewidth,
                                                  tw, spp, bps, (FILE *)((void *)0),
                                                  0, 0);
        if (tmp___3) {
          status = 0;
          goto switch_break;
        }
        goto switch_break;
        case_2: 
        tmp___4 = combineSeparateTileSamples16bits(srcbuffs, bufp, ncol, nrow, imagewidth,
                                                   tw, spp, bps, (FILE *)((void *)0),
                                                   0, 0);
        if (tmp___4) {
          status = 0;
          goto switch_break;
        }
        goto switch_break;
        case_3: 
        tmp___5 = combineSeparateTileSamples24bits(srcbuffs, bufp, ncol, nrow, imagewidth,
                                                   tw, spp, bps, (FILE *)((void *)0),
                                                   0, 0);
        if (tmp___5) {
          status = 0;
          goto switch_break;
        }
        goto switch_break;
        case_8: 
        tmp___6 = combineSeparateTileSamples32bits(srcbuffs, bufp, ncol, nrow, imagewidth,
                                                   tw, spp, bps, (FILE *)((void *)0),
                                                   0, 0);
        if (tmp___6) {
          status = 0;
          goto switch_break;
        }
        goto switch_break;
        switch_default: 
        TIFFError((char const   *)"readSeparateTilesIntoBuffer", (char const   *)"Unsupported bit depth: %d",
                  (int )bps);
        status = 0;
        goto switch_break;
        switch_break: ;
      }
      col += tw;
    }
    while_break___9: /* CIL Label */ ;
    }
    while_break___2: 
    row += tl;
  }
  while_break___8: /* CIL Label */ ;
  }
  while_break___1: 
  sample = 0;
  {
  while (1) {
    while_continue___5: /* CIL Label */ ;

    if (sample < (int )spp) {
      if (! (sample < 8)) {
        goto while_break___5;
      }
    } else {
      goto while_break___5;
    }
    tbuff = srcbuffs[sample];
    if ((unsigned long )tbuff != (unsigned long )((void *)0)) {
      _TIFFfree((void *)tbuff);
    }
    sample ++;
  }
  while_break___12: /* CIL Label */ ;
  }
  while_break___5: ;
  return (status);
}
}
static int writeBufferToContigStrips(TIFF *out , uint8 *buf , uint32 imagelength ) 
{ 
  uint32 row ;
  uint32 nrows ;
  uint32 rowsperstrip___0 ;
  tstrip_t strip ;
  tsize_t stripsize ;
  char const   *tmp ;
  tstrip_t tmp___0 ;
  tmsize_t tmp___1 ;

  {
  strip = (tstrip_t )0;
  TIFFGetFieldDefaulted(out, (uint32 )278, & rowsperstrip___0);
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < imagelength)) {
      goto while_break;
    }
    if (row + rowsperstrip___0 > imagelength) {
      nrows = imagelength - row;
    } else {
      nrows = rowsperstrip___0;
    }
    stripsize = TIFFVStripSize(out, nrows);
    tmp___0 = strip;
    strip ++;
    tmp___1 = TIFFWriteEncodedStrip(out, tmp___0, (void *)buf, stripsize);
    if (tmp___1 < 0L) {
      tmp = TIFFFileName(out);
      TIFFError(tmp, (char const   *)"Error, can\'t write strip %u", strip - 1U);
      return (1);
    }
    buf += stripsize;
    row += rowsperstrip___0;
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int writeBufferToSeparateStrips(TIFF *out , uint8 *buf , uint32 length , uint32 width ,
                                       unsigned short spp , struct dump_opts *dump ) 
{ 
  uint8 *src ;
  uint16 bps ;
  uint32 row ;
  uint32 nrows ;
  uint32 rowsize ;
  uint32 rowsperstrip___0 ;
  uint32 bytes_per_sample ;
  tsample_t s ;
  tstrip_t strip ;
  tsize_t stripsize ;
  tmsize_t tmp ;
  tsize_t rowstripsize ;
  tsize_t scanlinesize ;
  tmsize_t tmp___0 ;
  tsize_t total_bytes ;
  tdata_t obuf ;
  int tmp___1 ;
  char const   *tmp___2 ;
  tstrip_t tmp___3 ;
  tmsize_t tmp___4 ;

  {
  strip = (tstrip_t )0;
  tmp = TIFFStripSize(out);
  stripsize = tmp;
  tmp___0 = TIFFScanlineSize(out);
  scanlinesize = tmp___0;
  total_bytes = (tsize_t )0;
  TIFFGetFieldDefaulted(out, (uint32 )278, & rowsperstrip___0);
  TIFFGetField(out, (uint32 )258, & bps);
  bytes_per_sample = (uint32 )(((int )bps + 7) / 8);
  rowsize = ((uint32 )((int )bps * (int )spp) * width + 7U) / 8U;
  rowstripsize = (tsize_t )((rowsperstrip___0 * bytes_per_sample) * (width + 1U));
  obuf = _TIFFmalloc(rowstripsize);
  if ((unsigned long )obuf == (unsigned long )((void *)0)) {
    return (1);
  }
  s = (tsample_t )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! ((int )s < (int )spp)) {
      goto while_break;
    }
    row = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (row < length)) {
        goto while_break___0;
      }
      if (row + rowsperstrip___0 > length) {
        nrows = length - row;
      } else {
        nrows = rowsperstrip___0;
      }
      stripsize = TIFFVStripSize(out, nrows);
      src = buf + row * rowsize;
      total_bytes += stripsize;
      memset(obuf, '\000', (size_t )rowstripsize);
      tmp___1 = extractContigSamplesToBuffer((uint8 *)obuf, src, nrows, width, s,
                                             spp, bps, dump);
      if (tmp___1) {
        _TIFFfree(obuf);
        return (1);
      }
      if ((unsigned long )dump->outfile != (unsigned long )((void *)0)) {
        if (dump->level == 1) {
          dump_info(dump->outfile, dump->format, "", "Sample %2d, Strip: %2d, bytes: %4d, Row %4d, bytes: %4d, Input offset: %6d",
                    (int )s + 1, strip + 1U, stripsize, row + 1U, scanlinesize, src - buf);
          dump_buffer(dump->outfile, dump->format, nrows, (uint32 )scanlinesize, row,
                      (unsigned char *)obuf);
        }
      }
      tmp___3 = strip;
      strip ++;
      tmp___4 = TIFFWriteEncodedStrip(out, tmp___3, obuf, stripsize);
      if (tmp___4 < 0L) {
        tmp___2 = TIFFFileName(out);
        TIFFError(tmp___2, (char const   *)"Error, can\'t write strip %u", strip - 1U);
        _TIFFfree(obuf);
        return (1);
      }
      row += rowsperstrip___0;
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: 
    s = (tsample_t )((int )s + 1);
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: 
  _TIFFfree(obuf);
  return (0);
}
}
static int writeBufferToContigTiles(TIFF *out , uint8 *buf , uint32 imagelength ,
                                    uint32 imagewidth , tsample_t spp , struct dump_opts *dump ) 
{ 
  uint16 bps ;
  uint32 tl ;
  uint32 tw ;
  uint32 row ;
  uint32 col ;
  uint32 nrow ;
  uint32 ncol ;
  uint32 src_rowsize ;
  uint32 col_offset ;
  uint32 tile_rowsize ;
  tmsize_t tmp ;
  uint8 *bufp ;
  tsize_t tile_buffsize ;
  tsize_t tilesize ;
  tmsize_t tmp___0 ;
  unsigned char *tilebuf ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  void *tmp___4 ;
  int tmp___5 ;
  tmsize_t tmp___6 ;

  {
  tmp = TIFFTileRowSize(out);
  tile_rowsize = (uint32 )tmp;
  bufp = buf;
  tile_buffsize = (tsize_t )0;
  tmp___0 = TIFFTileSize(out);
  tilesize = tmp___0;
  tilebuf = (unsigned char *)((void *)0);
  tmp___1 = TIFFGetField(out, (uint32 )323, & tl);
  if (tmp___1) {
    tmp___2 = TIFFGetField(out, (uint32 )322, & tw);
    if (tmp___2) {
      tmp___3 = TIFFGetField(out, (uint32 )258, & bps);
      if (! tmp___3) {
        return (1);
      }
    } else {
      return (1);
    }
  } else {
    return (1);
  }
  tile_buffsize = tilesize;
  if (tilesize < (tsize_t )(tl * tile_rowsize)) {
    tile_buffsize = (tsize_t )(tl * tile_rowsize);
  }
  tmp___4 = _TIFFmalloc(tile_buffsize);
  tilebuf = (unsigned char *)tmp___4;
  if ((unsigned long )tilebuf == (unsigned long )((unsigned char *)0)) {
    return (1);
  }
  src_rowsize = ((imagewidth * (uint32 )spp) * (uint32 )bps + 7U) / 8U;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < imagelength)) {
      goto while_break;
    }
    if (row + tl > imagelength) {
      nrow = imagelength - row;
    } else {
      nrow = tl;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < imagewidth)) {
        goto while_break___0;
      }
      if (col + tw > imagewidth) {
        ncol = imagewidth - col;
      } else {
        ncol = tw;
      }
      col_offset = ((col * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
      bufp = (buf + row * src_rowsize) + col_offset;
      tmp___5 = extractContigSamplesToTileBuffer(tilebuf, bufp, nrow, ncol, imagewidth,
                                                 tw, (tsample_t )0, spp, spp, bps,
                                                 dump);
      if (tmp___5 > 0) {
        TIFFError((char const   *)"writeBufferToContigTiles", (char const   *)"Unable to extract data to tile for row %lu, col %lu",
                  (unsigned long )row, (unsigned long )col);
        _TIFFfree((void *)tilebuf);
        return (1);
      }
      tmp___6 = TIFFWriteTile(out, (void *)tilebuf, col, row, (uint32 )0, (uint16 )0);
      if (tmp___6 < 0L) {
        TIFFError((char const   *)"writeBufferToContigTiles", (char const   *)"Cannot write tile at %lu %lu",
                  (unsigned long )col, (unsigned long )row);
        _TIFFfree((void *)tilebuf);
        return (1);
      }
      col += tw;
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: 
    row += tl;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: 
  _TIFFfree((void *)tilebuf);
  return (0);
}
}
static int writeBufferToSeparateTiles(TIFF *out , uint8 *buf , uint32 imagelength ,
                                      uint32 imagewidth , tsample_t spp , struct dump_opts *dump ) 
{ 
  tdata_t obuf ;
  tmsize_t tmp ;
  void *tmp___0 ;
  uint32 tl ;
  uint32 tw ;
  uint32 row ;
  uint32 col ;
  uint32 nrow ;
  uint32 ncol ;
  uint32 src_rowsize ;
  uint32 col_offset ;
  uint16 bps ;
  tsample_t s ;
  uint8 *bufp ;
  int tmp___1 ;
  tmsize_t tmp___2 ;

  {
  tmp = TIFFTileSize(out);
  tmp___0 = _TIFFmalloc(tmp);
  obuf = tmp___0;
  bufp = buf;
  if ((unsigned long )obuf == (unsigned long )((void *)0)) {
    return (1);
  }
  TIFFGetField(out, (uint32 )323, & tl);
  TIFFGetField(out, (uint32 )322, & tw);
  TIFFGetField(out, (uint32 )258, & bps);
  src_rowsize = ((imagewidth * (uint32 )spp) * (uint32 )bps + 7U) / 8U;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < imagelength)) {
      goto while_break;
    }
    if (row + tl > imagelength) {
      nrow = imagelength - row;
    } else {
      nrow = tl;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < imagewidth)) {
        goto while_break___0;
      }
      if (col + tw > imagewidth) {
        ncol = imagewidth - col;
      } else {
        ncol = tw;
      }
      col_offset = ((col * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
      bufp = (buf + row * src_rowsize) + col_offset;
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        tmp___1 = extractContigSamplesToTileBuffer((uint8 *)obuf, bufp, nrow, ncol,
                                                   imagewidth, tw, s, (uint16 )1,
                                                   spp, bps, dump);
        if (tmp___1 > 0) {
          TIFFError((char const   *)"writeBufferToSeparateTiles", (char const   *)"Unable to extract data to tile for row %lu, col %lu sample %d",
                    (unsigned long )row, (unsigned long )col, (int )s);
          _TIFFfree(obuf);
          return (1);
        }
        tmp___2 = TIFFWriteTile(out, obuf, col, row, (uint32 )0, s);
        if (tmp___2 < 0L) {
          TIFFError((char const   *)"writeBufferToseparateTiles", (char const   *)"Cannot write tile at %lu %lu sample %lu",
                    (unsigned long )col, (unsigned long )row, (unsigned long )s);
          _TIFFfree(obuf);
          return (1);
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___4: /* CIL Label */ ;
      }
      while_break___1: 
      col += tw;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    row += tl;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: 
  _TIFFfree(obuf);
  return (0);
}
}
static void processG3Options(char *cp ) 
{ 
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  cp = strchr((char const   *)cp, ':');
  if (cp) {
    if (defg3opts == 4294967295U) {
      defg3opts = (uint32 )0;
    }
    {
    while (1) {
      while_continue: /* CIL Label */ ;
      cp ++;
      tmp___1 = strncmp((char const   *)cp, (char const   *)"1d", (size_t )2);
      if (tmp___1 == 0) {
        defg3opts &= 4294967294U;
      } else {
        tmp___0 = strncmp((char const   *)cp, (char const   *)"2d", (size_t )2);
        if (tmp___0 == 0) {
          defg3opts |= 1U;
        } else {
          tmp = strncmp((char const   *)cp, (char const   *)"fill", (size_t )4);
          if (tmp == 0) {
            defg3opts |= 4U;
          } else {
            usage();
          }
        }
      }
      cp = strchr((char const   *)cp, ':');
      if (! cp) {
        goto while_break;
      }
    }
    while_break___0: /* CIL Label */ ;
    }
    while_break: ;
  }
  return;
}
}
static int processCompressOptions(char *opt ) 
{ 
  char *cp ;
  int tmp ;
  int tmp___0 ;
  unsigned short const   **tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;

  {
  cp = (char *)((void *)0);
  tmp___10 = strncmp((char const   *)opt, (char const   *)"none", (size_t )4);
  if (tmp___10 == 0) {
    defcompression = (uint16 )1;
  } else {
    tmp___9 = strcmp((char const   *)opt, (char const   *)"packbits");
    if (tmp___9 == 0) {
      defcompression = (uint16 )32773;
    } else {
      tmp___8 = strncmp((char const   *)opt, (char const   *)"jpeg", (size_t )4);
      if (tmp___8 == 0) {
        cp = strchr((char const   *)opt, ':');
        defcompression = (uint16 )7;
        {
        while (1) {
          while_continue: /* CIL Label */ ;

          if (! cp) {
            goto while_break;
          }
          tmp___1 = __ctype_b_loc();
          if ((int const   )*(*tmp___1 + (int )*(cp + 1)) & 2048) {
            quality = atoi((char const   *)(cp + 1));
          } else {
            tmp___0 = strncmp((char const   *)(cp + 1), (char const   *)"raw", (size_t )3);
            if (tmp___0 == 0) {
              jpegcolormode = 0x0000;
            } else {
              tmp = strncmp((char const   *)(cp + 1), (char const   *)"rgb", (size_t )3);
              if (tmp == 0) {
                jpegcolormode = 0x0001;
              } else {
                usage();
              }
            }
          }
          cp = strchr((char const   *)(cp + 1), ':');
        }
        while_break___0: /* CIL Label */ ;
        }
        while_break: ;
      } else {
        tmp___7 = strncmp((char const   *)opt, (char const   *)"g3", (size_t )2);
        if (tmp___7 == 0) {
          processG3Options(opt);
          defcompression = (uint16 )3;
        } else {
          tmp___6 = strcmp((char const   *)opt, (char const   *)"g4");
          if (tmp___6 == 0) {
            defcompression = (uint16 )4;
          } else {
            tmp___5 = strncmp((char const   *)opt, (char const   *)"lzw", (size_t )3);
            if (tmp___5 == 0) {
              cp = strchr((char const   *)opt, ':');
              if (cp) {
                tmp___2 = atoi((char const   *)(cp + 1));
                defpredictor = (uint16 )tmp___2;
              }
              defcompression = (uint16 )5;
            } else {
              tmp___4 = strncmp((char const   *)opt, (char const   *)"zip", (size_t )3);
              if (tmp___4 == 0) {
                cp = strchr((char const   *)opt, ':');
                if (cp) {
                  tmp___3 = atoi((char const   *)(cp + 1));
                  defpredictor = (uint16 )tmp___3;
                }
                defcompression = (uint16 )8;
              } else {
                return (0);
              }
            }
          }
        }
      }
    }
  }
  return (1);
}
}
static void usage(void) 
{ 
  int i ;
  char const   *tmp ;

  {
  tmp = TIFFGetVersion();
  fprintf((FILE */* __restrict  */)stderr, (char const   */* __restrict  */)"\n%s\n",
          tmp);
  i = 0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! ((unsigned long )usage_info[i] != (unsigned long )((void *)0))) {
      goto while_break;
    }
    fprintf((FILE */* __restrict  */)stderr, (char const   */* __restrict  */)"%s\n",
            usage_info[i]);
    i ++;
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: 
  exit(-1);
}
}
static void cpTag(TIFF *in , TIFF *out , uint16 tag , uint16 count , TIFFDataType type ) 
{ 
  uint16 shortv ;
  int tmp ;
  uint16 shortv1 ;
  uint16 shortv2 ;
  int tmp___0 ;
  uint16 *tr ;
  uint16 *tg ;
  uint16 *tb ;
  uint16 *ta ;
  int tmp___1 ;
  uint16 shortv1___0 ;
  uint16 *shortav ;
  int tmp___2 ;
  uint32 longv ;
  int tmp___3 ;
  float floatv ;
  int tmp___4 ;
  float *floatav ;
  int tmp___5 ;
  char *stringv ;
  int tmp___6 ;
  double doublev ;
  int tmp___7 ;
  double *doubleav ;
  int tmp___8 ;
  char const   *tmp___9 ;

  {
  if ((unsigned int )type == 3U) {
    goto case_3;
  }
  if ((unsigned int )type == 4U) {
    goto case_4;
  }
  if ((unsigned int )type == 5U) {
    goto case_5;
  }
  if ((unsigned int )type == 2U) {
    goto case_2;
  }
  if ((unsigned int )type == 12U) {
    goto case_12;
  }
  goto switch_default;
  case_3: 
  if ((int )count == 1) {
    tmp = TIFFGetField(in, (uint32 )tag, & shortv);
    if (tmp) {
      TIFFSetField(out, (uint32 )tag, (int )shortv);
    }
  } else
  if ((int )count == 2) {
    tmp___0 = TIFFGetField(in, (uint32 )tag, & shortv1, & shortv2);
    if (tmp___0) {
      TIFFSetField(out, (uint32 )tag, (int )shortv1, (int )shortv2);
    }
  } else
  if ((int )count == 4) {
    tmp___1 = TIFFGetField(in, (uint32 )tag, & tr, & tg, & tb, & ta);
    if (tmp___1) {
      TIFFSetField(out, (uint32 )tag, tr, tg, tb, ta);
    }
  } else
  if ((int )count == 65535) {
    tmp___2 = TIFFGetField(in, (uint32 )tag, & shortv1___0, & shortav);
    if (tmp___2) {
      TIFFSetField(out, (uint32 )tag, (int )shortv1___0, shortav);
    }
  }
  goto switch_break;
  case_4: 
  tmp___3 = TIFFGetField(in, (uint32 )tag, & longv);
  if (tmp___3) {
    TIFFSetField(out, (uint32 )tag, longv);
  }
  goto switch_break;
  case_5: 
  if ((int )count == 1) {
    tmp___4 = TIFFGetField(in, (uint32 )tag, & floatv);
    if (tmp___4) {
      TIFFSetField(out, (uint32 )tag, (double )floatv);
    }
  } else
  if ((int )count == 65535) {
    tmp___5 = TIFFGetField(in, (uint32 )tag, & floatav);
    if (tmp___5) {
      TIFFSetField(out, (uint32 )tag, floatav);
    }
  }
  goto switch_break;
  case_2: 
  tmp___6 = TIFFGetField(in, (uint32 )tag, & stringv);
  if (tmp___6) {
    TIFFSetField(out, (uint32 )tag, stringv);
  }
  goto switch_break;
  case_12: 
  if ((int )count == 1) {
    tmp___7 = TIFFGetField(in, (uint32 )tag, & doublev);
    if (tmp___7) {
      TIFFSetField(out, (uint32 )tag, doublev);
    }
  } else
  if ((int )count == 65535) {
    tmp___8 = TIFFGetField(in, (uint32 )tag, & doubleav);
    if (tmp___8) {
      TIFFSetField(out, (uint32 )tag, doubleav);
    }
  }
  goto switch_break;
  switch_default: 
  tmp___9 = TIFFFileName(in);
  TIFFError(tmp___9, (char const   *)"Data type %d is not supported, tag %d skipped",
            (int )tag, (unsigned int )type);
  switch_break: ;
  return;
}
}
static struct cpTag tags[33]  = 
  {      {(uint16 )254, (uint16 )1, (TIFFDataType )4}, 
        {(uint16 )263, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )269, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )270, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )271, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )272, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )280, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )281, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )282, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )283, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )285, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )286, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )287, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )296, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )305, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )306, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )315, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )316, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )318, (uint16 )-1, (TIFFDataType )5}, 
        {(uint16 )319, (uint16 )-1, (TIFFDataType )5}, 
        {(uint16 )321, (uint16 )2, (TIFFDataType )3}, 
        {(uint16 )332, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )336, (uint16 )2, (TIFFDataType )3}, 
        {(uint16 )337, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )339, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )529, (uint16 )-1, (TIFFDataType )5}, 
        {(uint16 )530, (uint16 )2, (TIFFDataType )3}, 
        {(uint16 )531, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )532, (uint16 )-1, (TIFFDataType )5}, 
        {(uint16 )338, (uint16 )-1, (TIFFDataType )3}, 
        {(uint16 )340, (uint16 )1, (TIFFDataType )12}, 
        {(uint16 )341, (uint16 )1, (TIFFDataType )12}, 
        {(uint16 )37439, (uint16 )1, (TIFFDataType )12}};
void process_command_opts(int argc , char **argv , char *mp , char *mode , uint32 *dirnum ,
                          uint16 *defconfig , uint16 *deffillorder , uint32 *deftilewidth ,
                          uint32 *deftilelength , uint32 *defrowsperstrip , struct crop_mask *crop_data ,
                          struct pagedef *page , struct dump_opts *dump , unsigned int *imagelist ,
                          unsigned int *image_count ) 
{ 
  int c ;
  int good_args ;
  char *opt_offset ;
  char *opt_ptr ;
  char *sep ;
  unsigned int i ;
  unsigned int j ;
  unsigned int start ;
  unsigned int end ;
  char *tmp ;
  int tmp___0 ;
  unsigned long tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  long tmp___8 ;
  char const   *tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  char *tmp___12 ;
  char *tmp___13 ;
  char *tmp___14 ;
  char *tmp___15 ;
  size_t tmp___16 ;
  int tmp___17 ;
  size_t tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  size_t tmp___27 ;
  size_t tmp___28 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  unsigned int tmp___35 ;
  unsigned int tmp___36 ;
  unsigned int tmp___37 ;
  unsigned int tmp___38 ;
  int tmp___39 ;
  int tmp___40 ;
  int tmp___41 ;
  int tmp___42 ;
  unsigned int tmp___43 ;
  int tmp___44 ;
  int tmp___45 ;
  int tmp___46 ;
  int tmp___47 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  unsigned long tmp___51 ;
  int tmp___52 ;
  int tmp___53 ;
  int tmp___54 ;
  int tmp___55 ;
  int tmp___56 ;
  int tmp___57 ;
  int tmp___58 ;

  {
  good_args = 0;
  opt_offset = (char *)((void *)0);
  opt_ptr = (char *)((void *)0);
  sep = (char *)((void *)0);
  tmp = mp;
  mp ++;
  *tmp = (char )'w';
  *mp = (char )'\000';
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;
    while_continue: 
    c = getopt(argc, argv, (char const   *)"ac:d:e:f:hil:m:p:r:stvw:z:BCD:E:F:H:I:J:K:LMN:O:P:R:S:U:V:X:Y:Z:");
    if (! (c != -1)) {
      goto while_break;
    }
    good_args ++;
    if (c == 97) {
      goto case_97;
    }
    if (c == 99) {
      goto case_99;
    }
    if (c == 100) {
      goto case_100;
    }
    if (c == 101) {
      goto case_101;
    }
    if (c == 102) {
      goto case_102;
    }
    if (c == 104) {
      goto case_104;
    }
    if (c == 105) {
      goto case_105___0;
    }
    if (c == 108) {
      goto case_108;
    }
    if (c == 112) {
      goto case_112;
    }
    if (c == 114) {
      goto case_114;
    }
    if (c == 115) {
      goto case_115___0;
    }
    if (c == 116) {
      goto case_116;
    }
    if (c == 118) {
      goto case_118;
    }
    if (c == 119) {
      goto case_119;
    }
    if (c == 122) {
      goto case_122;
    }
    if (c == 66) {
      goto case_66;
    }
    if (c == 76) {
      goto case_76;
    }
    if (c == 77) {
      goto case_77;
    }
    if (c == 67) {
      goto case_67;
    }
    if (c == 68) {
      goto case_68;
    }
    if (c == 109) {
      goto case_109___0;
    }
    if (c == 69) {
      goto case_69;
    }
    if (c == 70) {
      goto case_70;
    }
    if (c == 72) {
      goto case_72;
    }
    if (c == 73) {
      goto case_73;
    }
    if (c == 74) {
      goto case_74;
    }
    if (c == 75) {
      goto case_75;
    }
    if (c == 78) {
      goto case_78;
    }
    if (c == 79) {
      goto case_79;
    }
    if (c == 80) {
      goto case_80;
    }
    if (c == 82) {
      goto case_82;
    }
    if (c == 83) {
      goto case_83;
    }
    if (c == 85) {
      goto case_85;
    }
    if (c == 86) {
      goto case_86;
    }
    if (c == 88) {
      goto case_88;
    }
    if (c == 89) {
      goto case_89;
    }
    if (c == 90) {
      goto case_90___0;
    }
    if (c == 63) {
      goto case_63;
    }
    goto switch_break;
    case_97: 
    *(mode + 0) = (char )'a';
    goto switch_break;
    case_99: 
    tmp___0 = processCompressOptions(optarg);
    if (! tmp___0) {
      TIFFError((char const   *)"Unknown compression option", (char const   *)"%s",
                optarg);
      TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
      exit(-1);
    }
    goto switch_break;
    case_100: 
    tmp___1 = strtoul((char const   */* __restrict  */)optarg, (char **/* __restrict  */)((void *)0),
                      0);
    start = (unsigned int )tmp___1;
    if (start == 0U) {
      TIFFError((char const   *)"", (char const   *)"Directory offset must be greater than zero");
      TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
      exit(-1);
    }
    *dirnum = start - 1U;
    goto switch_break;
    case_101: 
    tmp___2 = tolower((int )*(optarg + 0));
    if (tmp___2 == 99) {
      goto case_99___0;
    }
    if (tmp___2 == 100) {
      goto case_100___0;
    }
    if (tmp___2 == 105) {
      goto case_105;
    }
    if (tmp___2 == 109) {
      goto case_109;
    }
    if (tmp___2 == 115) {
      goto case_115;
    }
    goto switch_default;
    case_99___0: 
    crop_data->exp_mode = (uint16 )0;
    crop_data->img_mode = (uint16 )0;
    goto switch_break___0;
    case_100___0: 
    crop_data->exp_mode = (uint16 )1;
    crop_data->img_mode = (uint16 )1;
    goto switch_break___0;
    case_105: 
    crop_data->exp_mode = (uint16 )2;
    crop_data->img_mode = (uint16 )0;
    goto switch_break___0;
    case_109: 
    crop_data->exp_mode = (uint16 )3;
    crop_data->img_mode = (uint16 )1;
    goto switch_break___0;
    case_115: 
    crop_data->exp_mode = (uint16 )4;
    crop_data->img_mode = (uint16 )1;
    goto switch_break___0;
    switch_default: 
    TIFFError((char const   *)"Unknown export mode", (char const   *)"%s", optarg);
    TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
    exit(-1);
    switch_break___0: ;
    goto switch_break;
    case_102: 
    tmp___4 = strcmp((char const   *)optarg, (char const   *)"lsb2msb");
    if (tmp___4 == 0) {
      *deffillorder = (uint16 )2;
    } else {
      tmp___3 = strcmp((char const   *)optarg, (char const   *)"msb2lsb");
      if (tmp___3 == 0) {
        *deffillorder = (uint16 )1;
      } else {
        TIFFError((char const   *)"Unknown fill order", (char const   *)"%s", optarg);
        TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
        exit(-1);
      }
    }
    goto switch_break;
    case_104: 
    usage();
    goto switch_break;
    case_105___0: 
    ignore = 1;
    goto switch_break;
    case_108: 
    outtiled = 1;
    tmp___5 = atoi((char const   *)optarg);
    *deftilelength = (uint32 )tmp___5;
    goto switch_break;
    case_112: 
    tmp___7 = strcmp((char const   *)optarg, (char const   *)"separate");
    if (tmp___7 == 0) {
      *defconfig = (uint16 )2;
    } else {
      tmp___6 = strcmp((char const   *)optarg, (char const   *)"contig");
      if (tmp___6 == 0) {
        *defconfig = (uint16 )1;
      } else {
        TIFFError((char const   *)"Unkown planar configuration", (char const   *)"%s",
                  optarg);
        TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
        exit(-1);
      }
    }
    goto switch_break;
    case_114: 
    tmp___8 = atol((char const   *)optarg);
    *defrowsperstrip = (uint32 )tmp___8;
    goto switch_break;
    case_115___0: 
    outtiled = 0;
    goto switch_break;
    case_116: 
    outtiled = 1;
    goto switch_break;
    case_118: 
    tmp___9 = TIFFGetVersion();
    TIFFError((char const   *)"Library Release", (char const   *)"%s", tmp___9);
    TIFFError((char const   *)"Tiffcrop version", (char const   *)"%s, last updated: %s",
              tiffcrop_version_id, tiffcrop_rev_date);
    TIFFError((char const   *)"Tiffcp code", (char const   *)"Copyright (c) 1988-1997 Sam Leffler");
    TIFFError((char const   *)"           ", (char const   *)"Copyright (c) 1991-1997 Silicon Graphics, Inc");
    TIFFError((char const   *)"Tiffcrop additions", (char const   *)"Copyright (c) 2007-2010 Richard Nolde");
    exit(0);
    goto switch_break;
    case_119: 
    outtiled = 1;
    tmp___10 = atoi((char const   *)optarg);
    *deftilewidth = (uint32 )tmp___10;
    goto switch_break;
    case_122: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 16);
    i = 0U;
    opt_ptr = strtok((char */* __restrict  */)optarg, (char const   */* __restrict  */)":");
    {
    while (1) {
      while_continue___1: /* CIL Label */ ;

      if ((unsigned long )opt_ptr != (unsigned long )((void *)0)) {
        if (! (i < 8U)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      crop_data->regions = (uint16 )((int )crop_data->regions + 1);
      tmp___11 = sscanf((char const   *)opt_ptr, (char const   *)"%lf,%lf,%lf,%lf",
                        & crop_data->corners[i].X1, & crop_data->corners[i].Y1, & crop_data->corners[i].X2,
                        & crop_data->corners[i].Y2);
      if (tmp___11 != 4) {
        TIFFError((char const   *)"Unable to parse coordinates for region", (char const   *)"%d %s",
                  i, optarg);
        TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
        exit(-1);
      }
      opt_ptr = strtok((char */* __restrict  */)((void *)0), (char const   */* __restrict  */)":");
      i ++;
    }
    while_break___13: /* CIL Label */ ;
    }
    while_break___0: ;
    if ((unsigned long )opt_ptr != (unsigned long )((void *)0)) {
      if (i >= 8U) {
        TIFFError((char const   *)"Region list exceeds limit of", (char const   *)"%d regions %s",
                  8, optarg);
        TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
        exit(-1);
      }
    }
    goto switch_break;
    case_66: 
    tmp___12 = mp;
    mp ++;
    *tmp___12 = (char )'b';
    *mp = (char )'\000';
    goto switch_break;
    case_76: 
    tmp___13 = mp;
    mp ++;
    *tmp___13 = (char )'l';
    *mp = (char )'\000';
    goto switch_break;
    case_77: 
    tmp___14 = mp;
    mp ++;
    *tmp___14 = (char )'m';
    *mp = (char )'\000';
    goto switch_break;
    case_67: 
    tmp___15 = mp;
    mp ++;
    *tmp___15 = (char )'c';
    *mp = (char )'\000';
    goto switch_break;
    case_68: 
    i = 0U;
    opt_ptr = strtok((char */* __restrict  */)optarg, (char const   */* __restrict  */)",");
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! ((unsigned long )opt_ptr != (unsigned long )((void *)0))) {
        goto while_break___1;
      }
      opt_offset = strpbrk((char const   *)opt_ptr, (char const   *)":=");
      if ((unsigned long )opt_offset == (unsigned long )((void *)0)) {
        TIFFError((char const   *)"Invalid dump option", (char const   *)"%s", optarg);
        TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
        exit(-1);
      }
      *opt_offset = (char )'\000';
      tmp___16 = strlen((char const   *)opt_ptr);
      end = (unsigned int )tmp___16;
      i = 0U;
      {
      while (1) {
        while_continue___3: /* CIL Label */ ;

        if (! (i < end)) {
          goto while_break___2;
        }
        tmp___17 = tolower((int )*(opt_ptr + i));
        *(opt_ptr + i) = (char )tmp___17;
        i ++;
      }
      while_break___15: /* CIL Label */ ;
      }
      while_break___2: 
      tmp___26 = strncmp((char const   *)opt_ptr, (char const   *)"for", (size_t )3);
      if (tmp___26 == 0) {
        tmp___18 = strlen((char const   *)(opt_offset + 1));
        end = (unsigned int )tmp___18;
        i = 1U;
        {
        while (1) {
          while_continue___4: /* CIL Label */ ;

          if (! (i <= end)) {
            goto while_break___3;
          }
          tmp___19 = tolower((int )*(opt_offset + i));
          *(opt_offset + i) = (char )tmp___19;
          i ++;
        }
        while_break___16: /* CIL Label */ ;
        }
        while_break___3: 
        tmp___21 = strncmp((char const   *)(opt_offset + 1), (char const   *)"txt",
                           (size_t )3);
        if (tmp___21 == 0) {
          dump->format = 1;
          strcpy((char */* __restrict  */)(dump->mode), (char const   */* __restrict  */)"w");
        } else {
          tmp___20 = strncmp((char const   *)(opt_offset + 1), (char const   *)"raw",
                             (size_t )3);
          if (tmp___20 == 0) {
            dump->format = 2;
            strcpy((char */* __restrict  */)(dump->mode), (char const   */* __restrict  */)"wb");
          } else {
            TIFFError((char const   *)"parse_command_opts", (char const   *)"Unknown dump format %s",
                      opt_offset + 1);
            TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
            exit(-1);
          }
        }
      } else {
        tmp___22 = strncmp((char const   *)opt_ptr, (char const   *)"lev", (size_t )3);
        if (tmp___22 == 0) {
          dump->level = atoi((char const   *)(opt_offset + 1));
        }
        tmp___23 = strncmp((char const   *)opt_ptr, (char const   *)"in", (size_t )2);
        if (tmp___23 == 0) {
          strncpy((char */* __restrict  */)(dump->infilename), (char const   */* __restrict  */)(opt_offset + 1),
                  (size_t )4076);
          dump->infilename[4076] = (char )'\000';
        }
        tmp___24 = strncmp((char const   *)opt_ptr, (char const   *)"out", (size_t )3);
        if (tmp___24 == 0) {
          strncpy((char */* __restrict  */)(dump->outfilename), (char const   */* __restrict  */)(opt_offset + 1),
                  (size_t )4076);
          dump->outfilename[4076] = (char )'\000';
        }
        tmp___25 = strncmp((char const   *)opt_ptr, (char const   *)"deb", (size_t )3);
        if (tmp___25 == 0) {
          dump->debug = atoi((char const   *)(opt_offset + 1));
        }
      }
      opt_ptr = strtok((char */* __restrict  */)((void *)0), (char const   */* __restrict  */)",");
      i ++;
    }
    while_break___14: /* CIL Label */ ;
    }
    while_break___1: 
    tmp___27 = strlen((char const   *)(dump->infilename));
    if (tmp___27) {
      goto _L;
    } else {
      tmp___28 = strlen((char const   *)(dump->outfilename));
      if (tmp___28) {
        _L: 
        if (dump->level == 1) {
          TIFFError((char const   *)"", (char const   *)"Defaulting to dump level 1, no data.");
        }
        if (dump->format == 0) {
          TIFFError((char const   *)"", (char const   *)"You must specify a dump format for dump files");
          TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
          exit(-1);
        }
      }
    }
    goto switch_break;
    case_109___0: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 1);
    i = 0U;
    opt_ptr = strtok((char */* __restrict  */)optarg, (char const   */* __restrict  */)",:");
    {
    while (1) {
      while_continue___5: /* CIL Label */ ;

      if ((unsigned long )opt_ptr != (unsigned long )((void *)0)) {
        if (! (i < 4U)) {
          goto while_break___4;
        }
      } else {
        goto while_break___4;
      }
      crop_data->margins[i] = atof((char const   *)opt_ptr);
      opt_ptr = strtok((char */* __restrict  */)((void *)0), (char const   */* __restrict  */)",:");
      i ++;
    }
    while_break___17: /* CIL Label */ ;
    }
    while_break___4: ;
    goto switch_break;
    case_69: 
    tmp___29 = tolower((int )*(optarg + 0));
    if (tmp___29 == 116) {
      goto case_116___0;
    }
    if (tmp___29 == 98) {
      goto case_98;
    }
    if (tmp___29 == 108) {
      goto case_108___0;
    }
    if (tmp___29 == 114) {
      goto case_114___0;
    }
    goto switch_default___0;
    case_116___0: 
    crop_data->edge_ref = (uint16 )1;
    goto switch_break___1;
    case_98: 
    crop_data->edge_ref = (uint16 )3;
    goto switch_break___1;
    case_108___0: 
    crop_data->edge_ref = (uint16 )2;
    goto switch_break___1;
    case_114___0: 
    crop_data->edge_ref = (uint16 )4;
    goto switch_break___1;
    switch_default___0: 
    TIFFError((char const   *)"Edge reference must be top, bottom, left, or right",
              (char const   *)"%s", optarg);
    TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
    exit(-1);
    switch_break___1: ;
    goto switch_break;
    case_70: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 64);
    tmp___30 = tolower((int )*(optarg + 0));
    if (tmp___30 == 104) {
      goto case_104___0;
    }
    if (tmp___30 == 118) {
      goto case_118___0;
    }
    if (tmp___30 == 98) {
      goto case_98___0;
    }
    goto switch_default___1;
    case_104___0: 
    crop_data->mirror = (uint16 )1;
    goto switch_break___2;
    case_118___0: 
    crop_data->mirror = (uint16 )2;
    goto switch_break___2;
    case_98___0: 
    crop_data->mirror = (uint16 )3;
    goto switch_break___2;
    switch_default___1: 
    TIFFError((char const   *)"Flip mode must be horiz, vert, or both", (char const   *)"%s",
              optarg);
    TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
    exit(-1);
    switch_break___2: ;
    goto switch_break;
    case_72: 
    page->hres = atof((char const   *)optarg);
    page->mode |= 1U;
    goto switch_break;
    case_73: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 128);
    tmp___31 = strcmp((char const   *)optarg, (char const   *)"black");
    if (tmp___31 == 0) {
      crop_data->photometric = (uint16 )1;
      goto while_continue;
    }
    tmp___32 = strcmp((char const   *)optarg, (char const   *)"white");
    if (tmp___32 == 0) {
      crop_data->photometric = (uint16 )0;
      goto while_continue;
    }
    tmp___33 = strcmp((char const   *)optarg, (char const   *)"data");
    if (tmp___33 == 0) {
      crop_data->photometric = (uint16 )10;
      goto while_continue;
    }
    tmp___34 = strcmp((char const   *)optarg, (char const   *)"both");
    if (tmp___34 == 0) {
      crop_data->photometric = (uint16 )11;
      goto while_continue;
    }
    TIFFError((char const   *)"Missing or unknown option for inverting PHOTOMETRIC_INTERPRETATION",
              (char const   *)"%s", optarg);
    TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
    exit(-1);
    goto switch_break;
    case_74: 
    page->hmargin = atof((char const   *)optarg);
    page->mode |= 4U;
    goto switch_break;
    case_75: 
    page->vmargin = atof((char const   *)optarg);
    page->mode |= 4U;
    goto switch_break;
    case_78: 
    i = 0U;
    opt_ptr = strtok((char */* __restrict  */)optarg, (char const   */* __restrict  */)",");
    {
    while (1) {
      while_continue___6: /* CIL Label */ ;

      if ((unsigned long )opt_ptr != (unsigned long )((void *)0)) {
        if (! (i < 2048U)) {
          goto while_break___5;
        }
      } else {
        goto while_break___5;
      }
      tmp___46 = strcmp((char const   *)opt_ptr, (char const   *)"odd");
      if (tmp___46 == 0) {
        j = 1U;
        {
        while (1) {
          while_continue___7: /* CIL Label */ ;

          if (! (j <= 2048U)) {
            goto while_break___6;
          }
          tmp___35 = i;
          i ++;
          *(imagelist + tmp___35) = j;
          j += 2U;
        }
        while_break___19: /* CIL Label */ ;
        }
        while_break___6: 
        *image_count = 1023U;
        goto while_break___5;
      } else {
        tmp___45 = strcmp((char const   *)opt_ptr, (char const   *)"even");
        if (tmp___45 == 0) {
          j = 2U;
          {
          while (1) {
            while_continue___8: /* CIL Label */ ;

            if (! (j <= 2048U)) {
              goto while_break___7;
            }
            tmp___36 = i;
            i ++;
            *(imagelist + tmp___36) = j;
            j += 2U;
          }
          while_break___20: /* CIL Label */ ;
          }
          while_break___7: 
          *image_count = 1024U;
          goto while_break___5;
        } else {
          tmp___44 = strcmp((char const   *)opt_ptr, (char const   *)"last");
          if (tmp___44 == 0) {
            tmp___37 = i;
            i ++;
            *(imagelist + tmp___37) = 2048U;
          } else {
            sep = strpbrk((char const   *)opt_ptr, (char const   *)":-");
            if (! sep) {
              tmp___38 = i;
              i ++;
              tmp___39 = atoi((char const   *)opt_ptr);
              *(imagelist + tmp___38) = (unsigned int )tmp___39;
            } else {
              *sep = (char )'\000';
              tmp___40 = atoi((char const   *)opt_ptr);
              start = (unsigned int )tmp___40;
              tmp___42 = strcmp((char const   *)(sep + 1), (char const   *)"last");
              if (tmp___42) {
                tmp___41 = atoi((char const   *)(sep + 1));
                end = (unsigned int )tmp___41;
              } else {
                end = 2048U;
              }
              j = start;
              {
              while (1) {
                while_continue___9: /* CIL Label */ ;

                if (j <= end) {
                  if (! ((j - start) + i < 2048U)) {
                    goto while_break___8;
                  }
                } else {
                  goto while_break___8;
                }
                tmp___43 = i;
                i ++;
                *(imagelist + tmp___43) = j;
                j ++;
              }
              while_break___21: /* CIL Label */ ;
              }
              while_break___8: ;
            }
          }
        }
      }
      opt_ptr = strtok((char */* __restrict  */)((void *)0), (char const   */* __restrict  */)",");
    }
    while_break___18: /* CIL Label */ ;
    }
    while_break___5: 
    *image_count = i;
    goto switch_break;
    case_79: 
    tmp___47 = tolower((int )*(optarg + 0));
    if (tmp___47 == 97) {
      goto case_97___0;
    }
    if (tmp___47 == 112) {
      goto case_112___0;
    }
    if (tmp___47 == 108) {
      goto case_108___1;
    }
    goto switch_default___2;
    case_97___0: 
    page->orient = 16U;
    goto switch_break___3;
    case_112___0: 
    page->orient = 1U;
    goto switch_break___3;
    case_108___1: 
    page->orient = 2U;
    goto switch_break___3;
    switch_default___2: 
    TIFFError((char const   *)"Orientation must be portrait, landscape, or auto.",
              (char const   *)"%s", optarg);
    TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
    exit(-1);
    switch_break___3: ;
    goto switch_break;
    case_80: 
    tmp___48 = sscanf((char const   *)optarg, (char const   *)"%lfx%lf", & page->width,
                      & page->length);
    if (tmp___48 == 2) {
      strcpy((char */* __restrict  */)(page->name), (char const   */* __restrict  */)"Custom");
      page->mode |= 2U;
      goto switch_break;
    }
    tmp___50 = get_page_geometry(optarg, page);
    if (tmp___50) {
      tmp___49 = strcmp((char const   *)optarg, (char const   *)"list");
      if (! tmp___49) {
        TIFFError((char const   *)"", (char const   *)"Name            Width   Length (in inches)");
        i = 0U;
        {
        while (1) {
          while_continue___10: /* CIL Label */ ;

          if (! (i < 48U)) {
            goto while_break___9;
          }
          TIFFError((char const   *)"", (char const   *)"%-15.15s %5.2f   %5.2f",
                    PaperTable[i].name, PaperTable[i].width, PaperTable[i].length);
          i ++;
        }
        while_break___22: /* CIL Label */ ;
        }
        while_break___9: 
        exit(-1);
      }
      TIFFError((char const   *)"Invalid paper size", (char const   *)"%s", optarg);
      TIFFError((char const   *)"", (char const   *)"Select one of:");
      TIFFError((char const   *)"", (char const   *)"Name            Width   Length (in inches)");
      i = 0U;
      {
      while (1) {
        while_continue___11: /* CIL Label */ ;

        if (! (i < 48U)) {
          goto while_break___10;
        }
        TIFFError((char const   *)"", (char const   *)"%-15.15s %5.2f   %5.2f", PaperTable[i].name,
                  PaperTable[i].width, PaperTable[i].length);
        i ++;
      }
      while_break___23: /* CIL Label */ ;
      }
      while_break___10: 
      exit(-1);
    } else {
      page->mode |= 2U;
    }
    goto switch_break;
    case_82: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 32);
    tmp___51 = strtoul((char const   */* __restrict  */)optarg, (char **/* __restrict  */)((void *)0),
                       0);
    if (tmp___51 == 90UL) {
      goto case_90;
    }
    if (tmp___51 == 180UL) {
      goto case_180;
    }
    if (tmp___51 == 270UL) {
      goto case_270;
    }
    goto switch_default___3;
    case_90: 
    crop_data->rotation = (uint16 )90;
    goto switch_break___4;
    case_180: 
    crop_data->rotation = (uint16 )180;
    goto switch_break___4;
    case_270: 
    crop_data->rotation = (uint16 )270;
    goto switch_break___4;
    switch_default___3: 
    TIFFError((char const   *)"Rotation must be 90, 180, or 270 degrees clockwise",
              (char const   *)"%s", optarg);
    TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
    exit(-1);
    switch_break___4: ;
    goto switch_break;
    case_83: 
    sep = strpbrk((char const   *)optarg, (char const   *)",:");
    if (sep) {
      *sep = (char )'\000';
      tmp___52 = atoi((char const   *)optarg);
      page->cols = (unsigned int )tmp___52;
      tmp___53 = atoi((char const   *)(sep + 1));
      page->rows = (unsigned int )tmp___53;
    } else {
      tmp___54 = atoi((char const   *)optarg);
      page->cols = (unsigned int )tmp___54;
      tmp___55 = atoi((char const   *)optarg);
      page->rows = (unsigned int )tmp___55;
    }
    if (page->cols * page->rows > 32U) {
      TIFFError((char const   *)"Limit for subdivisions, ie rows x columns, exceeded",
                (char const   *)"%d", 32);
      exit(-1);
    }
    page->mode |= 8U;
    goto switch_break;
    case_85: 
    tmp___58 = strcmp((char const   *)optarg, (char const   *)"in");
    if (tmp___58 == 0) {
      crop_data->res_unit = (uint16 )2;
      page->res_unit = (uint16 )2;
    } else {
      tmp___57 = strcmp((char const   *)optarg, (char const   *)"cm");
      if (tmp___57 == 0) {
        crop_data->res_unit = (uint16 )3;
        page->res_unit = (uint16 )3;
      } else {
        tmp___56 = strcmp((char const   *)optarg, (char const   *)"px");
        if (tmp___56 == 0) {
          crop_data->res_unit = (uint16 )1;
          page->res_unit = (uint16 )1;
        } else {
          TIFFError((char const   *)"Illegal unit of measure", (char const   *)"%s",
                    optarg);
          TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
          exit(-1);
        }
      }
    }
    goto switch_break;
    case_86: 
    page->vres = atof((char const   *)optarg);
    page->mode |= 1U;
    goto switch_break;
    case_88: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 2);
    crop_data->width = atof((char const   *)optarg);
    goto switch_break;
    case_89: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 4);
    crop_data->length = atof((char const   *)optarg);
    goto switch_break;
    case_90___0: 
    crop_data->crop_mode = (uint16 )((int )crop_data->crop_mode | 8);
    i = 0U;
    opt_ptr = strtok((char */* __restrict  */)optarg, (char const   */* __restrict  */)",");
    {
    while (1) {
      while_continue___12: /* CIL Label */ ;

      if ((unsigned long )opt_ptr != (unsigned long )((void *)0)) {
        if (! (i < 8U)) {
          goto while_break___11;
        }
      } else {
        goto while_break___11;
      }
      crop_data->zones = (uint16 )((int )crop_data->zones + 1);
      opt_offset = strchr((char const   *)opt_ptr, ':');
      if (! opt_offset) {
        TIFFError((char const   *)"Wrong parameter syntax for -Z", (char const   *)"tiffcrop -h");
        exit(-1);
      }
      *opt_offset = (char )'\000';
      crop_data->zonelist[i].position = atoi((char const   *)opt_ptr);
      crop_data->zonelist[i].total = atoi((char const   *)(opt_offset + 1));
      opt_ptr = strtok((char */* __restrict  */)((void *)0), (char const   */* __restrict  */)",");
      i ++;
    }
    while_break___24: /* CIL Label */ ;
    }
    while_break___11: ;
    if ((unsigned long )opt_ptr != (unsigned long )((void *)0)) {
      if (i >= 8U) {
        TIFFError((char const   *)"Zone list exceeds region limit", (char const   *)"%d",
                  8);
        exit(-1);
      }
    }
    goto switch_break;
    case_63: 
    TIFFError((char const   *)"For valid options type", (char const   *)"tiffcrop -h");
    exit(-1);
    switch_break: ;
  }
  while_break___12: /* CIL Label */ ;
  }
  while_break: ;
  return;
}
}
static int findex  =    0;
static int update_output_file(TIFF **tiffout , char *mode , int autoindex , char *outname ,
                              unsigned int *page ) 
{ 
  char *sep ;
  char filenum[16] ;
  char export_ext[16] ;
  char exportname[4096] ;

  {
  if (autoindex) {
    if ((unsigned long )*tiffout != (unsigned long )((void *)0)) {
      TIFFClose(*tiffout);
      *tiffout = (TIFF *)((void *)0);
    }
  }
  strcpy((char */* __restrict  */)(export_ext), (char const   */* __restrict  */)".tiff");
  memset((void *)(exportname), '\000', (size_t )4096);
  strncpy((char */* __restrict  */)(exportname), (char const   */* __restrict  */)outname,
          (size_t )4080);
  if ((unsigned long )*tiffout == (unsigned long )((void *)0)) {
    if (autoindex) {
      findex ++;
      sep = strstr((char const   *)(exportname), (char const   *)".tif");
      if (sep) {
        strncpy((char */* __restrict  */)(export_ext), (char const   */* __restrict  */)sep,
                (size_t )5);
        *sep = (char )'\000';
      } else {
        sep = strstr((char const   *)(exportname), (char const   *)".TIF");
        if (sep) {
          strncpy((char */* __restrict  */)(export_ext), (char const   */* __restrict  */)sep,
                  (size_t )5);
          *sep = (char )'\000';
        } else {
          strncpy((char */* __restrict  */)(export_ext), (char const   */* __restrict  */)".tiff",
                  (size_t )5);
        }
      }
      export_ext[5] = (char )'\000';
      if (findex > 999999) {
        TIFFError((char const   *)"update_output_file", (char const   *)"Maximum of %d pages per file exceeded",
                  999999);
        return (1);
      }
      snprintf((char */* __restrict  */)(filenum), sizeof(filenum), (char const   */* __restrict  */)"-%03d%s",
               findex, export_ext);
      filenum[14] = (char )'\000';
      strncat((char */* __restrict  */)(exportname), (char const   */* __restrict  */)(filenum),
              (size_t )15);
    }
    exportname[4095] = (char )'\000';
    *tiffout = TIFFOpen((char const   *)(exportname), (char const   *)mode);
    if ((unsigned long )*tiffout == (unsigned long )((void *)0)) {
      TIFFError((char const   *)"update_output_file", (char const   *)"Unable to open output file %s",
                exportname);
      return (1);
    }
    *page = 0U;
    return (0);
  } else {
    (*page) ++;
  }
  return (0);
}
}
int main(int argc , char **argv ) 
{ 
  uint16 defconfig ;
  uint16 deffillorder ;
  uint32 deftilewidth ;
  uint32 deftilelength ;
  uint32 defrowsperstrip ;
  uint32 dirnum ;
  TIFF *in ;
  TIFF *out ;
  char mode[10] ;
  char *mp ;
  struct image_data image ;
  struct crop_mask crop ;
  struct pagedef page ;
  struct pageseg sections[32] ;
  struct buffinfo seg_buffs[32] ;
  struct dump_opts dump ;
  unsigned char *read_buff ;
  unsigned char *crop_buff ;
  unsigned char *sect_buff ;
  unsigned char *sect_src ;
  unsigned int imagelist[2049] ;
  unsigned int image_count ;
  unsigned int dump_images ;
  unsigned int next_image ;
  unsigned int next_page ;
  unsigned int total_pages ;
  unsigned int total_images ;
  unsigned int end_of_input ;
  int seg ;
  int length ;
  char temp_filename[4097] ;
  uint16 tmp ;
  char const   *tmp___0 ;
  char const   *tmp___1 ;
  int tmp___2 ;
  size_t tmp___3 ;
  char *tmp___4 ;
  char const   *tmp___5 ;
  size_t tmp___6 ;
  char *tmp___7 ;
  char const   *tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  uint16 tmp___19 ;
  int tmp___20 ;
  char const   *tmp___21 ;

  {
  defconfig = (uint16 )-1;
  deffillorder = (uint16 )0;
  deftilewidth = (uint32 )0;
  deftilelength = (uint32 )0;
  defrowsperstrip = (uint32 )0;
  dirnum = (uint32 )0;
  in = (TIFF *)((void *)0);
  out = (TIFF *)((void *)0);
  mp = mode;
  read_buff = (unsigned char *)((void *)0);
  crop_buff = (unsigned char *)((void *)0);
  sect_buff = (unsigned char *)((void *)0);
  sect_src = (unsigned char *)((void *)0);
  image_count = 0U;
  dump_images = 0U;
  next_image = 0U;
  next_page = 0U;
  total_pages = 0U;
  total_images = 0U;
  end_of_input = 0U;
  little_endian = (int )*((unsigned char *)(& little_endian)) & 49;
  initImageData(& image);
  initCropMasks(& crop);
  initPageSetup(& page, sections, seg_buffs);
  initDumpOptions(& dump);
  process_command_opts(argc, argv, mp, mode, & dirnum, & defconfig, & deffillorder,
                       & deftilewidth, & deftilelength, & defrowsperstrip, & crop,
                       & page, & dump, imagelist, & image_count);
  if (argc - optind < 2) {
    usage();
  }
  if (argc - optind == 2) {
    pageNum = -1;
  } else {
    total_images = 0U;
  }
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (optind < argc - 1)) {
      goto while_break;
    }
    in = TIFFOpen((char const   *)*(argv + optind), (char const   *)"r");
    if ((unsigned long )in == (unsigned long )((void *)0)) {
      return (-3);
    }
    tmp = TIFFNumberOfDirectories(in);
    total_images = (unsigned int )tmp;
    if (image_count == 0U) {
      dirnum = (uint32 )0;
      total_pages = total_images;
    } else {
      dirnum = (uint32 )((tdir_t )(imagelist[next_image] - 1U));
      next_image ++;
      if (image_count > total_images) {
        image_count = total_images;
      }
      total_pages = image_count;
    }
    if (dirnum == 2047U) {
      dirnum = total_images - 1U;
    }
    if (dirnum > total_images) {
      tmp___0 = TIFFFileName(in);
      TIFFError(tmp___0, (char const   *)"Invalid image number %d, File contains only %d images",
                (int )dirnum + 1, total_images);
      if ((unsigned long )out != (unsigned long )((void *)0)) {
        TIFFClose(out);
      }
      return (1);
    }
    if (dirnum != 0U) {
      tmp___2 = TIFFSetDirectory(in, (tdir_t )dirnum);
      if (! tmp___2) {
        tmp___1 = TIFFFileName(in);
        TIFFError(tmp___1, (char const   *)"Error, setting subdirectory at %d", dirnum);
        if ((unsigned long )out != (unsigned long )((void *)0)) {
          TIFFClose(out);
        }
        return (1);
      }
    }
    end_of_input = 0U;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (end_of_input == 0U)) {
        goto while_break___0;
      }
      config = defconfig;
      compression = defcompression;
      predictor = defpredictor;
      fillorder = deffillorder;
      rowsperstrip = defrowsperstrip;
      tilewidth = deftilewidth;
      tilelength = deftilelength;
      g3opts = defg3opts;
      if (dump.format != 0) {
        dump_images ++;
        tmp___3 = strlen((char const   *)(dump.infilename));
        length = (int )tmp___3;
        if (length > 0) {
          if ((unsigned long )dump.infile != (unsigned long )((void *)0)) {
            fclose(dump.infile);
          }
          if (dump.format == 1) {
            tmp___4 = "txt";
          } else {
            tmp___4 = "raw";
          }
          snprintf((char */* __restrict  */)(temp_filename), sizeof(temp_filename),
                   (char const   */* __restrict  */)"%s-read-%03d.%s", dump.infilename,
                   dump_images, tmp___4);
          dump.infile = fopen((char const   */* __restrict  */)(temp_filename), (char const   */* __restrict  */)(dump.mode));
          if ((unsigned long )dump.infile == (unsigned long )((void *)0)) {
            TIFFError((char const   *)"Unable to open dump file for writing", (char const   *)"%s",
                      temp_filename);
            exit(-1);
          }
          tmp___5 = TIFFFileName(in);
          dump_info(dump.infile, dump.format, "Reading image", "%d from %s", dump_images,
                    tmp___5);
        }
        tmp___6 = strlen((char const   *)(dump.outfilename));
        length = (int )tmp___6;
        if (length > 0) {
          if ((unsigned long )dump.outfile != (unsigned long )((void *)0)) {
            fclose(dump.outfile);
          }
          if (dump.format == 1) {
            tmp___7 = "txt";
          } else {
            tmp___7 = "raw";
          }
          snprintf((char */* __restrict  */)(temp_filename), sizeof(temp_filename),
                   (char const   */* __restrict  */)"%s-write-%03d.%s", dump.outfilename,
                   dump_images, tmp___7);
          dump.outfile = fopen((char const   */* __restrict  */)(temp_filename), (char const   */* __restrict  */)(dump.mode));
          if ((unsigned long )dump.outfile == (unsigned long )((void *)0)) {
            TIFFError((char const   *)"Unable to open dump file for writing", (char const   *)"%s",
                      temp_filename);
            exit(-1);
          }
          tmp___8 = TIFFFileName(in);
          dump_info(dump.outfile, dump.format, "Writing image", "%d from %s", dump_images,
                    tmp___8);
        }
      }
      if (dump.debug) {
        TIFFError((char const   *)"main", (char const   *)"Reading image %4d of %4d total pages.",
                  dirnum + 1U, total_pages);
      }
      tmp___9 = loadImage(in, & image, & dump, & read_buff);
      if (tmp___9) {
        TIFFError((char const   *)"main", (char const   *)"Unable to load source image");
        exit(-1);
      }
      if ((int )image.adjustments != 0) {
        tmp___10 = correct_orientation(& image, & read_buff);
        if (tmp___10) {
          TIFFError((char const   *)"main", (char const   *)"Unable to correct image orientation");
        }
      }
      tmp___11 = getCropOffsets(& image, & crop, & dump);
      if (tmp___11) {
        TIFFError((char const   *)"main", (char const   *)"Unable to define crop regions");
        exit(-1);
      }
      if ((int )crop.selections > 0) {
        tmp___12 = processCropSelections(& image, & crop, & read_buff, seg_buffs);
        if (tmp___12) {
          TIFFError((char const   *)"main", (char const   *)"Unable to process image selections");
          exit(-1);
        }
      } else {
        tmp___13 = createCroppedImage(& image, & crop, & read_buff, & crop_buff);
        if (tmp___13) {
          TIFFError((char const   *)"main", (char const   *)"Unable to create output image");
          exit(-1);
        }
      }
      if (page.mode == 0U) {
        if ((int )crop.selections > 0) {
          writeSelections(in, & out, & crop, & image, & dump, seg_buffs, mp, *(argv + (argc - 1)),
                          & next_page, total_pages);
        } else {
          tmp___14 = update_output_file(& out, mp, (int )crop.exp_mode, *(argv + (argc - 1)),
                                        & next_page);
          if (tmp___14) {
            exit(1);
          }
          tmp___15 = writeCroppedImage(in, out, & image, & dump, crop.combined_width,
                                       crop.combined_length, crop_buff, (int )next_page,
                                       (int )total_pages);
          if (tmp___15) {
            TIFFError((char const   *)"main", (char const   *)"Unable to write new image");
            exit(-1);
          }
        }
      } else {
        if ((unsigned long )crop_buff != (unsigned long )((void *)0)) {
          sect_src = crop_buff;
        } else {
          sect_src = read_buff;
        }
        tmp___16 = computeOutputPixelOffsets(& crop, & image, & page, sections, & dump);
        if (tmp___16) {
          TIFFError((char const   *)"main", (char const   *)"Unable to compute output section data");
          exit(-1);
        }
        tmp___17 = update_output_file(& out, mp, (int )crop.exp_mode, *(argv + (argc - 1)),
                                      & next_page);
        if (tmp___17) {
          exit(1);
        }
        tmp___18 = writeImageSections(in, out, & image, & page, sections, & dump,
                                      sect_src, & sect_buff);
        if (tmp___18) {
          TIFFError((char const   *)"main", (char const   *)"Unable to write image sections");
          exit(-1);
        }
      }
      if (image_count == 0U) {
        dirnum ++;
      } else {
        dirnum = (uint32 )((tdir_t )(imagelist[next_image] - 1U));
        next_image ++;
      }
      if (dirnum == 2047U) {
        tmp___19 = TIFFNumberOfDirectories(in);
        dirnum = (uint32 )((int )tmp___19 - 1);
      }
      tmp___20 = TIFFSetDirectory(in, (tdir_t )dirnum);
      if (! tmp___20) {
        end_of_input = 1U;
      }
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    TIFFClose(in);
    optind ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  if (read_buff) {
    _TIFFfree((void *)read_buff);
  }
  if (crop_buff) {
    _TIFFfree((void *)crop_buff);
  }
  if (sect_buff) {
    _TIFFfree((void *)sect_buff);
  }
  seg = 0;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (seg < (int )crop.selections)) {
      goto while_break___1;
    }
    _TIFFfree((void *)seg_buffs[seg].buffer);
    seg ++;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  if (dump.format != 0) {
    if ((unsigned long )dump.infile != (unsigned long )((void *)0)) {
      fclose(dump.infile);
    }
    if ((unsigned long )dump.outfile != (unsigned long )((void *)0)) {
      tmp___21 = TIFFFileName(out);
      dump_info(dump.outfile, dump.format, "", "Completed run for %s", tmp___21);
      fclose(dump.outfile);
    }
  }
  TIFFClose(out);
  return (0);
}
}
static int dump_data(FILE *dumpfile , int format , char *dump_tag , unsigned char *data ,
                     uint32 count ) 
{ 
  int j ;
  int k ;
  uint32 i ;
  char dump_array[10] ;
  unsigned char bitset ;
  char *tmp ;
  size_t tmp___0 ;

  {
  if ((unsigned long )dumpfile == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"", (char const   *)"Invalid FILE pointer for dump file");
    return (1);
  }
  if (format == 1) {
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s  ",
            dump_tag);
    i = (uint32 )0;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (i < count)) {
        goto while_break;
      }
      j = 0;
      k = 7;
      {
      while (1) {
        while_continue___0: /* CIL Label */ ;

        if (! (j < 8)) {
          goto while_break___0;
        }
        if ((int )*(data + i) & (1 << k)) {
          bitset = (unsigned char)1;
        } else {
          bitset = (unsigned char)0;
        }
        if (bitset) {
          tmp = "1";
        } else {
          tmp = "0";
        }
        sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)tmp);
        j ++;
        k --;
      }
      while_break___2: /* CIL Label */ ;
      }
      while_break___0: 
      dump_array[8] = (char )'\000';
      fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s",
              dump_array);
      i ++;
    }
    while_break___1: /* CIL Label */ ;
    }
    while_break: 
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)"\n");
  } else {
    tmp___0 = fwrite((void const   */* __restrict  */)data, (size_t )1, (size_t )count,
                     (FILE */* __restrict  */)dumpfile);
    if (tmp___0 != (size_t )count) {
      TIFFError((char const   *)"", (char const   *)"Unable to write binary data to dump file");
      return (1);
    }
  }
  return (0);
}
}
static int dump_byte(FILE *dumpfile , int format , char *dump_tag , unsigned char data ) 
{ 
  int j ;
  int k ;
  char dump_array[10] ;
  unsigned char bitset ;
  char *tmp ;
  size_t tmp___0 ;

  {
  if ((unsigned long )dumpfile == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"", (char const   *)"Invalid FILE pointer for dump file");
    return (1);
  }
  if (format == 1) {
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s  ",
            dump_tag);
    j = 0;
    k = 7;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (j < 8)) {
        goto while_break;
      }
      if ((int )data & (1 << k)) {
        bitset = (unsigned char)1;
      } else {
        bitset = (unsigned char)0;
      }
      if (bitset) {
        tmp = "1";
      } else {
        tmp = "0";
      }
      sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)tmp);
      j ++;
      k --;
    }
    while_break___0: /* CIL Label */ ;
    }
    while_break: 
    dump_array[8] = (char )'\000';
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s\n",
            dump_array);
  } else {
    tmp___0 = fwrite((void const   */* __restrict  */)(& data), (size_t )1, (size_t )1,
                     (FILE */* __restrict  */)dumpfile);
    if (tmp___0 != 1UL) {
      TIFFError((char const   *)"", (char const   *)"Unable to write binary data to dump file");
      return (1);
    }
  }
  return (0);
}
}
static int dump_short(FILE *dumpfile , int format , char *dump_tag , uint16 data ) 
{ 
  int j ;
  int k ;
  char dump_array[20] ;
  unsigned char bitset ;
  char *tmp ;
  size_t tmp___0 ;

  {
  if ((unsigned long )dumpfile == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"", (char const   *)"Invalid FILE pointer for dump file");
    return (1);
  }
  if (format == 1) {
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s  ",
            dump_tag);
    j = 0;
    k = 15;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (k >= 0)) {
        goto while_break;
      }
      if ((int )data & (1 << k)) {
        bitset = (unsigned char)1;
      } else {
        bitset = (unsigned char)0;
      }
      if (bitset) {
        tmp = "1";
      } else {
        tmp = "0";
      }
      sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)tmp);
      if (k % 8 == 0) {
        j ++;
        sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)" ");
      }
      j ++;
      k --;
    }
    while_break___0: /* CIL Label */ ;
    }
    while_break: 
    dump_array[17] = (char )'\000';
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s\n",
            dump_array);
  } else {
    tmp___0 = fwrite((void const   */* __restrict  */)(& data), (size_t )2, (size_t )1,
                     (FILE */* __restrict  */)dumpfile);
    if (tmp___0 != 2UL) {
      TIFFError((char const   *)"", (char const   *)"Unable to write binary data to dump file");
      return (1);
    }
  }
  return (0);
}
}
static int dump_long(FILE *dumpfile , int format , char *dump_tag , uint32 data ) 
{ 
  int j ;
  int k ;
  char dump_array[40] ;
  unsigned char bitset ;
  char *tmp ;
  size_t tmp___0 ;

  {
  if ((unsigned long )dumpfile == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"", (char const   *)"Invalid FILE pointer for dump file");
    return (1);
  }
  if (format == 1) {
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s  ",
            dump_tag);
    j = 0;
    k = 31;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (k >= 0)) {
        goto while_break;
      }
      if (data & (1U << k)) {
        bitset = (unsigned char)1;
      } else {
        bitset = (unsigned char)0;
      }
      if (bitset) {
        tmp = "1";
      } else {
        tmp = "0";
      }
      sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)tmp);
      if (k % 8 == 0) {
        j ++;
        sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)" ");
      }
      j ++;
      k --;
    }
    while_break___0: /* CIL Label */ ;
    }
    while_break: 
    dump_array[35] = (char )'\000';
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s\n",
            dump_array);
  } else {
    tmp___0 = fwrite((void const   */* __restrict  */)(& data), (size_t )4, (size_t )1,
                     (FILE */* __restrict  */)dumpfile);
    if (tmp___0 != 4UL) {
      TIFFError((char const   *)"", (char const   *)"Unable to write binary data to dump file");
      return (1);
    }
  }
  return (0);
}
}
static int dump_wide(FILE *dumpfile , int format , char *dump_tag , uint64 data ) 
{ 
  int j ;
  int k ;
  char dump_array[80] ;
  unsigned char bitset ;
  char *tmp ;
  size_t tmp___0 ;

  {
  if ((unsigned long )dumpfile == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"", (char const   *)"Invalid FILE pointer for dump file");
    return (1);
  }
  if (format == 1) {
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s  ",
            dump_tag);
    j = 0;
    k = 63;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (k >= 0)) {
        goto while_break;
      }
      if (data & (1UL << k)) {
        bitset = (unsigned char)1;
      } else {
        bitset = (unsigned char)0;
      }
      if (bitset) {
        tmp = "1";
      } else {
        tmp = "0";
      }
      sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)tmp);
      if (k % 8 == 0) {
        j ++;
        sprintf((char */* __restrict  */)(& dump_array[j]), (char const   */* __restrict  */)" ");
      }
      j ++;
      k --;
    }
    while_break___0: /* CIL Label */ ;
    }
    while_break: 
    dump_array[71] = (char )'\000';
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)" %s\n",
            dump_array);
  } else {
    tmp___0 = fwrite((void const   */* __restrict  */)(& data), (size_t )8, (size_t )1,
                     (FILE */* __restrict  */)dumpfile);
    if (tmp___0 != 8UL) {
      TIFFError((char const   *)"", (char const   *)"Unable to write binary data to dump file");
      return (1);
    }
  }
  return (0);
}
}
static void dump_info(FILE *dumpfile , int format , char *prefix , char *msg  , ...) 
{ 
  va_list ap ;

  {
  if (format == 1) {
    __builtin_va_start(ap, msg);
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)"%s ",
            prefix);
    vfprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)msg,
             ap);
    fprintf((FILE */* __restrict  */)dumpfile, (char const   */* __restrict  */)"\n");
    __builtin_va_end(ap);
  }
  return;
}
}
static int dump_buffer(FILE *dumpfile , int format , uint32 rows , uint32 width ,
                       uint32 row , unsigned char *buff ) 
{ 
  int j ;
  int k ;
  uint32 i ;
  unsigned char *dump_ptr ;

  {
  if ((unsigned long )dumpfile == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"", (char const   *)"Invalid FILE pointer for dump file");
    return (1);
  }
  i = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < rows)) {
      goto while_break;
    }
    dump_ptr = buff + i * width;
    if (format == 1) {
      dump_info(dumpfile, format, "", "Row %4d, %d bytes at offset %d", (row + i) + 1U,
                width, row * width);
    }
    j = 0;
    k = (int )width;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (k >= 10)) {
        goto while_break___0;
      }
      dump_data(dumpfile, format, "", dump_ptr, (uint32 )10);
      j += 10;
      k -= 10;
      dump_ptr += 10;
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: ;
    if (k > 0) {
      dump_data(dumpfile, format, "", dump_ptr, (uint32 )k);
    }
    i ++;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int extractContigSamplesBytes(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                     uint16 spp , uint16 bps , tsample_t count , uint32 start ,
                                     uint32 end ) 
{ 
  int i ;
  int bytes_per_sample ;
  int sindex ;
  uint32 col ;
  uint32 dst_rowsize ;
  uint32 bit_offset ;
  uint32 src_byte ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;

  {
  src = in;
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesBytes", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesBytes", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamplesBytes", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamplesBytes", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamplesBytes", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamplesBytes", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  dst_rowsize = (((uint32 )bps * (end - start)) * (uint32 )count) / 8U;
  bytes_per_sample = ((int )bps + 7) / 8;
  if ((int )count == (int )spp) {
    src = in + (start * (uint32 )spp) * (uint32 )bytes_per_sample;
    _TIFFmemcpy((void *)dst, (void const   *)src, (tmsize_t )dst_rowsize);
  } else {
    col = start;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (col < end)) {
        goto while_break;
      }
      sindex = (int )sample;
      {
      while (1) {
        while_continue___0: /* CIL Label */ ;

        if (sindex < (int )spp) {
          if (! (sindex < (int )sample + (int )count)) {
            goto while_break___0;
          }
        } else {
          goto while_break___0;
        }
        bit_offset = (col * (uint32 )bps) * (uint32 )spp;
        if (sindex == 0) {
          src_byte = bit_offset / 8U;
        } else {
          src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        }
        src = in + src_byte;
        i = 0;
        {
        while (1) {
          while_continue___1: /* CIL Label */ ;

          if (! (i < bytes_per_sample)) {
            goto while_break___1;
          }
          tmp = dst;
          dst ++;
          tmp___0 = src;
          src ++;
          *tmp = *tmp___0;
          i ++;
        }
        while_break___4: /* CIL Label */ ;
        }
        while_break___1: 
        sindex ++;
      }
      while_break___3: /* CIL Label */ ;
      }
      while_break___0: 
      col ++;
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break: ;
  }
  return (0);
}
}
static int extractContigSamples8bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                     uint16 spp , uint16 bps , tsample_t count , uint32 start ,
                                     uint32 end ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint8 maskbits ;
  uint8 matchbits ;
  uint8 buff1 ;
  uint8 buff2 ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;

  {
  ready_bits = 0;
  sindex = 0;
  maskbits = (uint8 )0;
  matchbits = (uint8 )0;
  buff1 = (uint8 )0;
  buff2 = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamples8bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamples8bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamples8bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamples8bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = 0;
  maskbits = (uint8 )(255 >> (8 - (int )bps));
  buff2 = (uint8 )0;
  buff1 = buff2;
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = (uint8 )((int )maskbits << ((8U - src_bit) - (uint32 )bps));
      buff1 = (uint8 )(((int )*src & (int )matchbits) << src_bit);
      if (ready_bits >= 8) {
        tmp = dst;
        dst ++;
        *tmp = buff2;
        buff2 = buff1;
        ready_bits -= 8;
      } else {
        buff2 = (uint8 )((int )buff2 | ((int )buff1 >> ready_bits));
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    buff1 = (uint8 )((unsigned int )buff2 & (255U << (8 - ready_bits)));
    tmp___0 = dst;
    dst ++;
    *tmp___0 = buff1;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamples16bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                      uint16 spp , uint16 bps , tsample_t count ,
                                      uint32 start , uint32 end ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint16 maskbits ;
  uint16 matchbits ;
  uint16 buff1 ;
  uint16 buff2 ;
  uint8 bytebuff ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;

  {
  ready_bits = 0;
  sindex = 0;
  maskbits = (uint16 )0;
  matchbits = (uint16 )0;
  buff1 = (uint16 )0;
  buff2 = (uint16 )0;
  bytebuff = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamples16bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamples16bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamples16bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamples16bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = 0;
  maskbits = (uint16 )(65535 >> (16 - (int )bps));
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = (uint16 )((int )maskbits << ((16U - src_bit) - (uint32 )bps));
      if (little_endian) {
        buff1 = (uint16 )(((int )*(src + 0) << 8) | (int )*(src + 1));
      } else {
        buff1 = (uint16 )(((int )*(src + 1) << 8) | (int )*(src + 0));
      }
      buff1 = (uint16 )(((int )buff1 & (int )matchbits) << src_bit);
      if (ready_bits < 8) {
        bytebuff = (uint8 )0;
        buff2 = (uint16 )((int )buff2 | ((int )buff1 >> ready_bits));
      } else {
        bytebuff = (uint8 )((int )buff2 >> 8);
        tmp = dst;
        dst ++;
        *tmp = bytebuff;
        ready_bits -= 8;
        buff2 = (uint16 )(((int )buff2 << 8) | ((int )buff1 >> ready_bits));
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff = (uint8 )((int )buff2 >> 8);
    tmp___0 = dst;
    dst ++;
    *tmp___0 = bytebuff;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamples24bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                      uint16 spp , uint16 bps , tsample_t count ,
                                      uint32 start , uint32 end ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint32 maskbits ;
  uint32 matchbits ;
  uint32 buff1 ;
  uint32 buff2 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  uint8 *tmp___1 ;

  {
  ready_bits = 0;
  sindex = 0;
  maskbits = (uint32 )0;
  matchbits = (uint32 )0;
  buff1 = (uint32 )0;
  buff2 = (uint32 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )in == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )out == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamples24bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamples24bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamples24bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamples24bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = 0;
  maskbits = 4294967295U >> (32 - (int )bps);
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = maskbits << ((32U - src_bit) - (uint32 )bps);
      if (little_endian) {
        buff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
      } else {
        buff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
      }
      buff1 = (buff1 & matchbits) << src_bit;
      if (ready_bits < 16) {
        bytebuff2 = (uint8 )0;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      } else {
        bytebuff1 = (uint8 )(buff2 >> 24);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 16);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        ready_bits -= 16;
        buff2 = (buff2 << 16) | (buff1 >> ready_bits);
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 24);
    tmp___1 = dst;
    dst ++;
    *tmp___1 = bytebuff1;
    buff2 <<= 8;
    bytebuff2 = bytebuff1;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamples32bits(uint8 *in , uint8 *out , uint32 cols , tsample_t sample ,
                                      uint16 spp , uint16 bps , tsample_t count ,
                                      uint32 start , uint32 end ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint32 longbuff1 ;
  uint32 longbuff2 ;
  uint64 maskbits ;
  uint64 matchbits ;
  uint64 buff1 ;
  uint64 buff2 ;
  uint64 buff3 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 bytebuff3 ;
  uint8 bytebuff4 ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  uint8 *tmp___1 ;
  uint8 *tmp___2 ;
  uint8 *tmp___3 ;

  {
  ready_bits = 0;
  sindex = 0;
  longbuff1 = (uint32 )0;
  longbuff2 = (uint32 )0;
  maskbits = (uint64 )0;
  matchbits = (uint64 )0;
  buff1 = (uint64 )0;
  buff2 = (uint64 )0;
  buff3 = (uint64 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  bytebuff3 = (uint8 )0;
  bytebuff4 = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )in == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )out == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamples32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamples32bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamples32bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamples32bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamples32bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = 0;
  maskbits = 18446744073709551615UL >> (64 - (int )bps);
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = maskbits << ((64U - src_bit) - (uint32 )bps);
      if (little_endian) {
        longbuff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
        longbuff2 = longbuff1;
      } else {
        longbuff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
        longbuff2 = longbuff1;
      }
      buff3 = ((uint64 )longbuff1 << 32) | (unsigned long )longbuff2;
      buff1 = (buff3 & matchbits) << src_bit;
      if (ready_bits >= 32) {
        bytebuff1 = (uint8 )(buff2 >> 56);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 48);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        bytebuff3 = (uint8 )(buff2 >> 40);
        tmp___1 = dst;
        dst ++;
        *tmp___1 = bytebuff3;
        bytebuff4 = (uint8 )(buff2 >> 32);
        tmp___2 = dst;
        dst ++;
        *tmp___2 = bytebuff4;
        ready_bits -= 32;
        buff2 = (buff2 << 32) | (buff1 >> ready_bits);
      } else {
        bytebuff4 = (uint8 )0;
        bytebuff3 = bytebuff4;
        bytebuff2 = bytebuff3;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 56);
    tmp___3 = dst;
    dst ++;
    *tmp___3 = bytebuff1;
    buff2 <<= 8;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamplesShifted8bits(uint8 *in , uint8 *out , uint32 cols ,
                                            tsample_t sample , uint16 spp , uint16 bps ,
                                            tsample_t count , uint32 start , uint32 end ,
                                            int shift ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint8 maskbits ;
  uint8 matchbits ;
  uint8 buff1 ;
  uint8 buff2 ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;

  {
  ready_bits = 0;
  sindex = 0;
  maskbits = (uint8 )0;
  matchbits = (uint8 )0;
  buff1 = (uint8 )0;
  buff2 = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamplesShifted8bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted8bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamplesShifted8bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted8bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = shift;
  maskbits = (uint8 )(255 >> (8 - (int )bps));
  buff2 = (uint8 )0;
  buff1 = buff2;
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = (uint8 )((int )maskbits << ((8U - src_bit) - (uint32 )bps));
      buff1 = (uint8 )(((int )*src & (int )matchbits) << src_bit);
      if (col == start) {
        if (sindex == (int )sample) {
          buff2 = (uint8 )((int )*src & (255 << shift));
        }
      }
      if (ready_bits >= 8) {
        tmp = dst;
        dst ++;
        *tmp = (uint8 )((int )*tmp | (int )buff2);
        buff2 = buff1;
        ready_bits -= 8;
      } else {
        buff2 = (uint8 )((int )buff2 | ((int )buff1 >> ready_bits));
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    buff1 = (uint8 )((unsigned int )buff2 & (255U << (8 - ready_bits)));
    tmp___0 = dst;
    dst ++;
    *tmp___0 = buff1;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamplesShifted16bits(uint8 *in , uint8 *out , uint32 cols ,
                                             tsample_t sample , uint16 spp , uint16 bps ,
                                             tsample_t count , uint32 start , uint32 end ,
                                             int shift ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint16 maskbits ;
  uint16 matchbits ;
  uint16 buff1 ;
  uint16 buff2 ;
  uint8 bytebuff ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;

  {
  ready_bits = 0;
  sindex = 0;
  maskbits = (uint16 )0;
  matchbits = (uint16 )0;
  buff1 = (uint16 )0;
  buff2 = (uint16 )0;
  bytebuff = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamplesShifted16bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted16bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamplesShifted16bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted16bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = shift;
  maskbits = (uint16 )(65535 >> (16 - (int )bps));
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = (uint16 )((int )maskbits << ((16U - src_bit) - (uint32 )bps));
      if (little_endian) {
        buff1 = (uint16 )(((int )*(src + 0) << 8) | (int )*(src + 1));
      } else {
        buff1 = (uint16 )(((int )*(src + 1) << 8) | (int )*(src + 0));
      }
      if (col == start) {
        if (sindex == (int )sample) {
          buff2 = (uint16 )((int )buff1 & (65535 << (8 - shift)));
        }
      }
      buff1 = (uint16 )(((int )buff1 & (int )matchbits) << src_bit);
      if (ready_bits < 8) {
        buff2 = (uint16 )((int )buff2 | ((int )buff1 >> ready_bits));
      } else {
        bytebuff = (uint8 )((int )buff2 >> 8);
        tmp = dst;
        dst ++;
        *tmp = bytebuff;
        ready_bits -= 8;
        buff2 = (uint16 )(((int )buff2 << 8) | ((int )buff1 >> ready_bits));
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff = (uint8 )((int )buff2 >> 8);
    tmp___0 = dst;
    dst ++;
    *tmp___0 = bytebuff;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamplesShifted24bits(uint8 *in , uint8 *out , uint32 cols ,
                                             tsample_t sample , uint16 spp , uint16 bps ,
                                             tsample_t count , uint32 start , uint32 end ,
                                             int shift ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint32 maskbits ;
  uint32 matchbits ;
  uint32 buff1 ;
  uint32 buff2 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  uint8 *tmp___1 ;

  {
  ready_bits = 0;
  sindex = 0;
  maskbits = (uint32 )0;
  matchbits = (uint32 )0;
  buff1 = (uint32 )0;
  buff2 = (uint32 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )in == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )out == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamplesShifted24bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted24bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamplesShifted24bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted24bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = shift;
  maskbits = 4294967295U >> (32 - (int )bps);
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = maskbits << ((32U - src_bit) - (uint32 )bps);
      if (little_endian) {
        buff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
      } else {
        buff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
      }
      if (col == start) {
        if (sindex == (int )sample) {
          buff2 = buff1 & (4294967295U << (16 - shift));
        }
      }
      buff1 = (buff1 & matchbits) << src_bit;
      if (ready_bits < 16) {
        bytebuff2 = (uint8 )0;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      } else {
        bytebuff1 = (uint8 )(buff2 >> 24);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 16);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        ready_bits -= 16;
        buff2 = (buff2 << 16) | (buff1 >> ready_bits);
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 24);
    tmp___1 = dst;
    dst ++;
    *tmp___1 = bytebuff1;
    buff2 <<= 8;
    bytebuff2 = bytebuff1;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamplesShifted32bits(uint8 *in , uint8 *out , uint32 cols ,
                                             tsample_t sample , uint16 spp , uint16 bps ,
                                             tsample_t count , uint32 start , uint32 end ,
                                             int shift ) 
{ 
  int ready_bits ;
  int sindex ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint32 longbuff1 ;
  uint32 longbuff2 ;
  uint64 maskbits ;
  uint64 matchbits ;
  uint64 buff1 ;
  uint64 buff2 ;
  uint64 buff3 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 bytebuff3 ;
  uint8 bytebuff4 ;
  uint8 *src ;
  uint8 *dst ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  uint8 *tmp___1 ;
  uint8 *tmp___2 ;
  uint8 *tmp___3 ;

  {
  ready_bits = 0;
  sindex = 0;
  longbuff1 = (uint32 )0;
  longbuff2 = (uint32 )0;
  maskbits = (uint64 )0;
  matchbits = (uint64 )0;
  buff1 = (uint64 )0;
  buff2 = (uint64 )0;
  buff3 = (uint64 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  bytebuff3 = (uint8 )0;
  bytebuff4 = (uint8 )0;
  src = in;
  dst = out;
  if ((unsigned long )in == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )out == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"extractContigSamplesShifted32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  if (start > end) {
    TIFFError((char const   *)"extractContigSamplesShifted32bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  } else
  if (start > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted32bits", (char const   *)"Invalid start column value %d ignored",
              start);
    start = (uint32 )0;
  }
  if (end == 0U) {
    TIFFError((char const   *)"extractContigSamplesShifted32bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  } else
  if (end > cols) {
    TIFFError((char const   *)"extractContigSamplesShifted32bits", (char const   *)"Invalid end column value %d ignored",
              end);
    end = cols;
  }
  ready_bits = shift;
  maskbits = 18446744073709551615UL >> (64 - (int )bps);
  col = start;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < end)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sindex = (int )sample;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (sindex < (int )spp) {
        if (! (sindex < (int )sample + (int )count)) {
          goto while_break___0;
        }
      } else {
        goto while_break___0;
      }
      if (sindex == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )(sindex * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )(sindex * (int )bps)) % 8U;
      }
      src = in + src_byte;
      matchbits = maskbits << ((64U - src_bit) - (uint32 )bps);
      if (little_endian) {
        longbuff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
        longbuff2 = longbuff1;
      } else {
        longbuff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
        longbuff2 = longbuff1;
      }
      buff3 = ((uint64 )longbuff1 << 32) | (unsigned long )longbuff2;
      if (col == start) {
        if (sindex == (int )sample) {
          buff2 = buff3 & (18446744073709551615UL << (32 - shift));
        }
      }
      buff1 = (buff3 & matchbits) << src_bit;
      if (ready_bits < 32) {
        bytebuff4 = (uint8 )0;
        bytebuff3 = bytebuff4;
        bytebuff2 = bytebuff3;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      } else {
        bytebuff1 = (uint8 )(buff2 >> 56);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 48);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        bytebuff3 = (uint8 )(buff2 >> 40);
        tmp___1 = dst;
        dst ++;
        *tmp___1 = bytebuff3;
        bytebuff4 = (uint8 )(buff2 >> 32);
        tmp___2 = dst;
        dst ++;
        *tmp___2 = bytebuff4;
        ready_bits -= 32;
        buff2 = (buff2 << 32) | (buff1 >> ready_bits);
      }
      ready_bits += (int )bps;
      sindex ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 56);
    tmp___3 = dst;
    dst ++;
    *tmp___3 = bytebuff1;
    buff2 <<= 8;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int extractContigSamplesToBuffer(uint8 *out , uint8 *in , uint32 rows , uint32 cols ,
                                        tsample_t sample , uint16 spp , uint16 bps ,
                                        struct dump_opts *dump ) 
{ 
  int shift_width ;
  int bytes_per_sample ;
  int bytes_per_pixel ;
  uint32 src_rowsize ;
  uint32 src_offset ;
  uint32 row ;
  uint32 first_col ;
  uint32 dst_rowsize ;
  uint32 dst_offset ;
  tsample_t count ;
  uint8 *src ;
  uint8 *dst ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;

  {
  first_col = (uint32 )0;
  count = (tsample_t )1;
  bytes_per_sample = ((int )bps + 7) / 8;
  bytes_per_pixel = ((int )bps * (int )spp + 7) / 8;
  if ((int )bps % 8 == 0) {
    shift_width = 0;
  } else
  if (bytes_per_pixel < bytes_per_sample + 1) {
    shift_width = bytes_per_pixel;
  } else {
    shift_width = bytes_per_sample + 1;
  }
  src_rowsize = ((uint32 )((int )bps * (int )spp) * cols + 7U) / 8U;
  dst_rowsize = ((uint32 )bps * cols + 7U) / 8U;
  if ((unsigned long )dump->outfile != (unsigned long )((void *)0)) {
    if (dump->level == 4) {
      dump_info(dump->outfile, dump->format, "extractContigSamplesToBuffer", "Sample %d, %d rows",
                (int )sample + 1, rows + 1U);
    }
  }
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    src_offset = row * src_rowsize;
    dst_offset = row * dst_rowsize;
    src = in + src_offset;
    dst = out + dst_offset;
    if (shift_width == 0) {
      goto case_0;
    }
    if (shift_width == 1) {
      goto case_1;
    }
    if (shift_width == 2) {
      goto case_2;
    }
    if (shift_width == 5) {
      goto case_5;
    }
    if (shift_width == 4) {
      goto case_5;
    }
    if (shift_width == 3) {
      goto case_5;
    }
    goto switch_default;
    case_0: 
    tmp = extractContigSamplesBytes(src, dst, cols, sample, spp, bps, count, first_col,
                                    cols);
    if (tmp) {
      return (1);
    }
    goto switch_break;
    case_1: 
    if ((int )bps == 1) {
      tmp___0 = extractContigSamples8bits(src, dst, cols, sample, spp, bps, count,
                                          first_col, cols);
      if (tmp___0) {
        return (1);
      }
      goto switch_break;
    } else {
      tmp___1 = extractContigSamples16bits(src, dst, cols, sample, spp, bps, count,
                                           first_col, cols);
      if (tmp___1) {
        return (1);
      }
    }
    goto switch_break;
    case_2: 
    tmp___2 = extractContigSamples24bits(src, dst, cols, sample, spp, bps, count,
                                         first_col, cols);
    if (tmp___2) {
      return (1);
    }
    goto switch_break;
    case_5: 
    tmp___3 = extractContigSamples32bits(src, dst, cols, sample, spp, bps, count,
                                         first_col, cols);
    if (tmp___3) {
      return (1);
    }
    goto switch_break;
    switch_default: 
    TIFFError((char const   *)"extractContigSamplesToBuffer", (char const   *)"Unsupported bit depth: %d",
              (int )bps);
    return (1);
    switch_break: ;
    if ((unsigned long )dump->outfile != (unsigned long )((void *)0)) {
      if (dump->level == 4) {
        dump_buffer(dump->outfile, dump->format, (uint32 )1, dst_rowsize, row, dst);
      }
    }
    row ++;
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int extractContigSamplesToTileBuffer(uint8 *out , uint8 *in , uint32 rows ,
                                            uint32 cols , uint32 imagewidth , uint32 tilewidth___0 ,
                                            tsample_t sample , uint16 count , uint16 spp ,
                                            uint16 bps , struct dump_opts *dump ) 
{ 
  int shift_width ;
  int bytes_per_sample ;
  int bytes_per_pixel ;
  uint32 src_rowsize ;
  uint32 src_offset ;
  uint32 row ;
  uint32 dst_rowsize ;
  uint32 dst_offset ;
  uint8 *src ;
  uint8 *dst ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;

  {
  bytes_per_sample = ((int )bps + 7) / 8;
  bytes_per_pixel = ((int )bps * (int )spp + 7) / 8;
  if ((int )bps % 8 == 0) {
    shift_width = 0;
  } else
  if (bytes_per_pixel < bytes_per_sample + 1) {
    shift_width = bytes_per_pixel;
  } else {
    shift_width = bytes_per_sample + 1;
  }
  if ((unsigned long )dump->outfile != (unsigned long )((void *)0)) {
    if (dump->level == 4) {
      dump_info(dump->outfile, dump->format, "extractContigSamplesToTileBuffer", "Sample %d, %d rows",
                (int )sample + 1, rows + 1U);
    }
  }
  src_rowsize = ((uint32 )((int )bps * (int )spp) * imagewidth + 7U) / 8U;
  dst_rowsize = (((uint32 )bps * tilewidth___0) * (uint32 )count + 7U) / 8U;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    src_offset = row * src_rowsize;
    dst_offset = row * dst_rowsize;
    src = in + src_offset;
    dst = out + dst_offset;
    if (shift_width == 0) {
      goto case_0;
    }
    if (shift_width == 1) {
      goto case_1;
    }
    if (shift_width == 2) {
      goto case_2;
    }
    if (shift_width == 5) {
      goto case_5;
    }
    if (shift_width == 4) {
      goto case_5;
    }
    if (shift_width == 3) {
      goto case_5;
    }
    goto switch_default;
    case_0: 
    tmp = extractContigSamplesBytes(src, dst, cols, sample, spp, bps, count, (uint32 )0,
                                    cols);
    if (tmp) {
      return (1);
    }
    goto switch_break;
    case_1: 
    if ((int )bps == 1) {
      tmp___0 = extractContigSamples8bits(src, dst, cols, sample, spp, bps, count,
                                          (uint32 )0, cols);
      if (tmp___0) {
        return (1);
      }
      goto switch_break;
    } else {
      tmp___1 = extractContigSamples16bits(src, dst, cols, sample, spp, bps, count,
                                           (uint32 )0, cols);
      if (tmp___1) {
        return (1);
      }
    }
    goto switch_break;
    case_2: 
    tmp___2 = extractContigSamples24bits(src, dst, cols, sample, spp, bps, count,
                                         (uint32 )0, cols);
    if (tmp___2) {
      return (1);
    }
    goto switch_break;
    case_5: 
    tmp___3 = extractContigSamples32bits(src, dst, cols, sample, spp, bps, count,
                                         (uint32 )0, cols);
    if (tmp___3) {
      return (1);
    }
    goto switch_break;
    switch_default: 
    TIFFError((char const   *)"extractContigSamplesToTileBuffer", (char const   *)"Unsupported bit depth: %d",
              (int )bps);
    return (1);
    switch_break: ;
    if ((unsigned long )dump->outfile != (unsigned long )((void *)0)) {
      if (dump->level == 4) {
        dump_buffer(dump->outfile, dump->format, (uint32 )1, dst_rowsize, row, dst);
      }
    }
    row ++;
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int readContigStripsIntoBuffer(TIFF *in , uint8 *buf ) 
{ 
  uint8 *bufp ;
  int32 bytes_read ;
  uint16 strip ;
  uint16 nstrips ;
  uint32 tmp ;
  uint32 stripsize ;
  tmsize_t tmp___0 ;
  uint32 rows ;
  uint32 rps ;
  int tmp___1 ;
  tsize_t scanline_size ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;

  {
  bufp = buf;
  bytes_read = 0;
  tmp = TIFFNumberOfStrips(in);
  nstrips = (uint16 )tmp;
  tmp___0 = TIFFStripSize(in);
  stripsize = (uint32 )tmp___0;
  rows = (uint32 )0;
  tmp___1 = TIFFGetFieldDefaulted(in, (uint32 )278, & rps);
  rps = (uint32 )tmp___1;
  tmp___2 = TIFFScanlineSize(in);
  scanline_size = tmp___2;
  if (scanline_size == 0L) {
    TIFFError((char const   *)"", (char const   *)"TIFF scanline size is zero!");
    return (0);
  }
  strip = (uint16 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! ((int )strip < (int )nstrips)) {
      goto while_break;
    }
    tmp___3 = TIFFReadEncodedStrip(in, (uint32 )strip, (void *)bufp, (tmsize_t )-1);
    bytes_read = (int32 )tmp___3;
    rows = (uint32 )((tsize_t )bytes_read / scanline_size);
    if ((int )strip < (int )nstrips - 1) {
      if (bytes_read != (int32 )stripsize) {
        TIFFError((char const   *)"", (char const   *)"Strip %d: read %lu bytes, strip size %lu",
                  (int )strip + 1, (unsigned long )bytes_read, (unsigned long )stripsize);
      }
    }
    if (bytes_read < 0) {
      if (! ignore) {
        TIFFError((char const   *)"", (char const   *)"Error reading strip %lu after %lu rows",
                  (unsigned long )strip, (unsigned long )rows);
        return (0);
      }
    }
    bufp += bytes_read;
    strip = (uint16 )((int )strip + 1);
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: ;
  return (1);
}
}
static int combineSeparateSamplesBytes(unsigned char **srcbuffs , unsigned char *out ,
                                       uint32 cols , uint32 rows , unsigned short spp ,
                                       uint16 bps , FILE *dumpfile , int format ,
                                       int level ) 
{ 
  int i ;
  int bytes_per_sample ;
  uint32 row ;
  uint32 col ;
  uint32 col_offset ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 row_offset ;
  unsigned char *src ;
  unsigned char *dst ;
  tsample_t s ;

  {
  src = *(srcbuffs + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamplesBytes", (char const   *)"Invalid buffer address");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamplesBytes", (char const   *)"Invalid buffer address");
    return (1);
  }
  bytes_per_sample = ((int )bps + 7) / 8;
  src_rowsize = ((uint32 )bps * cols + 7U) / 8U;
  dst_rowsize = ((uint32 )((int )bps * (int )spp) * cols + 7U) / 8U;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        s = (tsample_t )0;
        {
        while (1) {
          while_continue___0: /* CIL Label */ ;

          if (! ((int )s < (int )spp)) {
            goto while_break___0;
          }
          dump_info(dumpfile, format, "combineSeparateSamplesBytes", "Input data, Sample %d",
                    (int )s);
          dump_buffer(dumpfile, format, (uint32 )1, cols, row, *(srcbuffs + (int )s) + row * src_rowsize);
          s = (tsample_t )((int )s + 1);
        }
        while_break___5: /* CIL Label */ ;
        }
        while_break___0: ;
      }
    }
    dst = out + row * dst_rowsize;
    row_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___1: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___1;
      }
      col_offset = row_offset + col * (uint32 )((int )bps / 8);
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___2: /* CIL Label */ ;

        if ((int )s < (int )spp) {
          if (! ((int )s < 8)) {
            goto while_break___2;
          }
        } else {
          goto while_break___2;
        }
        src = *(srcbuffs + (int )s) + col_offset;
        i = 0;
        {
        while (1) {
          while_continue___3: /* CIL Label */ ;

          if (! (i < bytes_per_sample)) {
            goto while_break___3;
          }
          *(dst + i) = *(src + i);
          i ++;
        }
        while_break___8: /* CIL Label */ ;
        }
        while_break___3: 
        src += bytes_per_sample;
        dst += bytes_per_sample;
        s = (tsample_t )((int )s + 1);
      }
      while_break___7: /* CIL Label */ ;
      }
      while_break___2: 
      col ++;
    }
    while_break___6: /* CIL Label */ ;
    }
    while_break___1: ;
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateSamplesBytes", "Output data, combined samples");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateSamples8bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                       uint16 spp , uint16 bps , FILE *dumpfile ,
                                       int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 src_offset ;
  uint32 bit_offset ;
  uint32 row ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint8 maskbits ;
  uint8 matchbits ;
  uint8 buff1 ;
  uint8 buff2 ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[32] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  maskbits = (uint8 )0;
  matchbits = (uint8 )0;
  buff1 = (uint8 )0;
  buff2 = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * cols + 7U) / 8U;
  dst_rowsize = (((uint32 )bps * cols) * (uint32 )spp + 7U) / 8U;
  maskbits = (uint8 )(255 >> (8 - (int )bps));
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint8 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = (uint8 )((int )maskbits << ((8U - src_bit) - (uint32 )bps));
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        buff1 = (uint8 )(((int )*src & (int )matchbits) << src_bit);
        if (ready_bits >= 8) {
          tmp = dst;
          dst ++;
          *tmp = buff2;
          buff2 = buff1;
          ready_bits -= 8;
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          buff2 = (uint8 )((int )buff2 | ((int )buff1 >> ready_bits));
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Samples %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_byte(dumpfile, format, "Match bits", matchbits);
            dump_byte(dumpfile, format, "Src   bits", *src);
            dump_byte(dumpfile, format, "Buff1 bits", buff1);
            dump_byte(dumpfile, format, "Buff2 bits", buff2);
            dump_info(dumpfile, format, "", "%s", action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___4: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: ;
    if (ready_bits > 0) {
      buff1 = (uint8 )((unsigned int )buff2 & (255U << (8 - ready_bits)));
      tmp___0 = dst;
      dst ++;
      *tmp___0 = buff1;
      if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
        if (level == 3) {
          dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                    row + 1U, col + 1U, src_byte, src_bit, dst - out);
          dump_byte(dumpfile, format, "Final bits", buff1);
        }
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level >= 2) {
        dump_info(dumpfile, format, "combineSeparateSamples8bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateSamples16bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                        uint16 spp , uint16 bps , FILE *dumpfile ,
                                        int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 bit_offset ;
  uint32 src_offset ;
  uint32 row ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint16 maskbits ;
  uint16 matchbits ;
  uint16 buff1 ;
  uint16 buff2 ;
  uint8 bytebuff ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[8] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  maskbits = (uint16 )0;
  matchbits = (uint16 )0;
  buff1 = (uint16 )0;
  buff2 = (uint16 )0;
  bytebuff = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * cols + 7U) / 8U;
  dst_rowsize = (((uint32 )bps * cols) * (uint32 )spp + 7U) / 8U;
  maskbits = (uint16 )(65535 >> (16 - (int )bps));
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint16 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = (uint16 )((int )maskbits << ((16U - src_bit) - (uint32 )bps));
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        if (little_endian) {
          buff1 = (uint16 )(((int )*(src + 0) << 8) | (int )*(src + 1));
        } else {
          buff1 = (uint16 )(((int )*(src + 1) << 8) | (int )*(src + 0));
        }
        buff1 = (uint16 )(((int )buff1 & (int )matchbits) << src_bit);
        if (ready_bits >= 8) {
          bytebuff = (uint8 )((int )buff2 >> 8);
          tmp = dst;
          dst ++;
          *tmp = bytebuff;
          ready_bits -= 8;
          buff2 = (uint16 )(((int )buff2 << 8) | ((int )buff1 >> ready_bits));
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          bytebuff = (uint8 )0;
          buff2 = (uint16 )((int )buff2 | ((int )buff1 >> ready_bits));
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Samples %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_short(dumpfile, format, "Match bits", matchbits);
            dump_data(dumpfile, format, "Src   bits", src, (uint32 )2);
            dump_short(dumpfile, format, "Buff1 bits", buff1);
            dump_short(dumpfile, format, "Buff2 bits", buff2);
            dump_byte(dumpfile, format, "Write byte", bytebuff);
            dump_info(dumpfile, format, "", "Ready bits:  %d, %s", ready_bits, action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___4: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: ;
    if (ready_bits > 0) {
      bytebuff = (uint8 )((int )buff2 >> 8);
      tmp___0 = dst;
      dst ++;
      *tmp___0 = bytebuff;
      if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
        if (level == 3) {
          dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                    row + 1U, col + 1U, src_byte, src_bit, dst - out);
          dump_byte(dumpfile, format, "Final bits", bytebuff);
        }
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateSamples16bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateSamples24bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                        uint16 spp , uint16 bps , FILE *dumpfile ,
                                        int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 bit_offset ;
  uint32 src_offset ;
  uint32 row ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 maskbits ;
  uint32 matchbits ;
  uint32 buff1 ;
  uint32 buff2 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[8] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;
  unsigned char *tmp___1 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  maskbits = (uint32 )0;
  matchbits = (uint32 )0;
  buff1 = (uint32 )0;
  buff2 = (uint32 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * cols + 7U) / 8U;
  dst_rowsize = (((uint32 )bps * cols) * (uint32 )spp + 7U) / 8U;
  maskbits = 4294967295U >> (32 - (int )bps);
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint32 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = maskbits << ((32U - src_bit) - (uint32 )bps);
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        if (little_endian) {
          buff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
        } else {
          buff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
        }
        buff1 = (buff1 & matchbits) << src_bit;
        if (ready_bits >= 16) {
          bytebuff1 = (uint8 )(buff2 >> 24);
          tmp = dst;
          dst ++;
          *tmp = bytebuff1;
          bytebuff2 = (uint8 )(buff2 >> 16);
          tmp___0 = dst;
          dst ++;
          *tmp___0 = bytebuff2;
          ready_bits -= 16;
          buff2 = (buff2 << 16) | (buff1 >> ready_bits);
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          bytebuff2 = (uint8 )0;
          bytebuff1 = bytebuff2;
          buff2 |= buff1 >> ready_bits;
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Samples %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_long(dumpfile, format, "Match bits ", matchbits);
            dump_data(dumpfile, format, "Src   bits ", src, (uint32 )4);
            dump_long(dumpfile, format, "Buff1 bits ", buff1);
            dump_long(dumpfile, format, "Buff2 bits ", buff2);
            dump_byte(dumpfile, format, "Write bits1", bytebuff1);
            dump_byte(dumpfile, format, "Write bits2", bytebuff2);
            dump_info(dumpfile, format, "", "Ready bits:   %d, %s", ready_bits, action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___5: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___0: ;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! (ready_bits > 0)) {
        goto while_break___2;
      }
      bytebuff1 = (uint8 )(buff2 >> 24);
      tmp___1 = dst;
      dst ++;
      *tmp___1 = bytebuff1;
      buff2 <<= 8;
      bytebuff2 = bytebuff1;
      ready_bits -= 8;
    }
    while_break___6: /* CIL Label */ ;
    }
    while_break___2: ;
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 3) {
        dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                  row + 1U, col + 1U, src_byte, src_bit, dst - out);
        dump_long(dumpfile, format, "Match bits ", matchbits);
        dump_data(dumpfile, format, "Src   bits ", src, (uint32 )4);
        dump_long(dumpfile, format, "Buff1 bits ", buff1);
        dump_long(dumpfile, format, "Buff2 bits ", buff2);
        dump_byte(dumpfile, format, "Write bits1", bytebuff1);
        dump_byte(dumpfile, format, "Write bits2", bytebuff2);
        dump_info(dumpfile, format, "", "Ready bits:  %2d", ready_bits);
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateSamples24bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___3: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateSamples32bits(uint8 **in , uint8 *out , uint32 cols , uint32 rows ,
                                        uint16 spp , uint16 bps , FILE *dumpfile ,
                                        int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 bit_offset ;
  uint32 src_offset ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 row ;
  uint32 col ;
  uint32 longbuff1 ;
  uint32 longbuff2 ;
  uint64 maskbits ;
  uint64 matchbits ;
  uint64 buff1 ;
  uint64 buff2 ;
  uint64 buff3 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 bytebuff3 ;
  uint8 bytebuff4 ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[8] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;
  unsigned char *tmp___1 ;
  unsigned char *tmp___2 ;
  unsigned char *tmp___3 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  longbuff1 = (uint32 )0;
  longbuff2 = (uint32 )0;
  maskbits = (uint64 )0;
  matchbits = (uint64 )0;
  buff1 = (uint64 )0;
  buff2 = (uint64 )0;
  buff3 = (uint64 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  bytebuff3 = (uint8 )0;
  bytebuff4 = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateSamples32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * cols + 7U) / 8U;
  dst_rowsize = (((uint32 )bps * cols) * (uint32 )spp + 7U) / 8U;
  maskbits = 18446744073709551615UL >> (64 - (int )bps);
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint64 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = maskbits << ((64U - src_bit) - (uint32 )bps);
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        if (little_endian) {
          longbuff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
          longbuff2 = longbuff1;
        } else {
          longbuff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
          longbuff2 = longbuff1;
        }
        buff3 = ((uint64 )longbuff1 << 32) | (unsigned long )longbuff2;
        buff1 = (buff3 & matchbits) << src_bit;
        if (ready_bits >= 32) {
          bytebuff1 = (uint8 )(buff2 >> 56);
          tmp = dst;
          dst ++;
          *tmp = bytebuff1;
          bytebuff2 = (uint8 )(buff2 >> 48);
          tmp___0 = dst;
          dst ++;
          *tmp___0 = bytebuff2;
          bytebuff3 = (uint8 )(buff2 >> 40);
          tmp___1 = dst;
          dst ++;
          *tmp___1 = bytebuff3;
          bytebuff4 = (uint8 )(buff2 >> 32);
          tmp___2 = dst;
          dst ++;
          *tmp___2 = bytebuff4;
          ready_bits -= 32;
          buff2 = (buff2 << 32) | (buff1 >> ready_bits);
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          bytebuff4 = (uint8 )0;
          bytebuff3 = bytebuff4;
          bytebuff2 = bytebuff3;
          bytebuff1 = bytebuff2;
          buff2 |= buff1 >> ready_bits;
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Sample %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_wide(dumpfile, format, "Match bits ", matchbits);
            dump_data(dumpfile, format, "Src   bits ", src, (uint32 )8);
            dump_wide(dumpfile, format, "Buff1 bits ", buff1);
            dump_wide(dumpfile, format, "Buff2 bits ", buff2);
            dump_info(dumpfile, format, "", "Ready bits:   %d, %s", ready_bits, action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___5: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___0: ;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! (ready_bits > 0)) {
        goto while_break___2;
      }
      bytebuff1 = (uint8 )(buff2 >> 56);
      tmp___3 = dst;
      dst ++;
      *tmp___3 = bytebuff1;
      buff2 <<= 8;
      ready_bits -= 8;
    }
    while_break___6: /* CIL Label */ ;
    }
    while_break___2: ;
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 3) {
        dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                  row + 1U, col + 1U, src_byte, src_bit, dst - out);
        dump_long(dumpfile, format, "Match bits ", (uint32 )matchbits);
        dump_data(dumpfile, format, "Src   bits ", src, (uint32 )4);
        dump_long(dumpfile, format, "Buff1 bits ", (uint32 )buff1);
        dump_long(dumpfile, format, "Buff2 bits ", (uint32 )buff2);
        dump_byte(dumpfile, format, "Write bits1", bytebuff1);
        dump_byte(dumpfile, format, "Write bits2", bytebuff2);
        dump_info(dumpfile, format, "", "Ready bits:  %2d", ready_bits);
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateSamples32bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out);
      }
    }
    row ++;
  }
  while_break___3: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateTileSamplesBytes(unsigned char **srcbuffs , unsigned char *out ,
                                           uint32 cols , uint32 rows , uint32 imagewidth ,
                                           uint32 tw , unsigned short spp , uint16 bps ,
                                           FILE *dumpfile , int format , int level ) 
{ 
  int i ;
  int bytes_per_sample ;
  uint32 row ;
  uint32 col ;
  uint32 col_offset ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 src_offset ;
  unsigned char *src ;
  unsigned char *dst ;
  tsample_t s ;

  {
  src = *(srcbuffs + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamplesBytes", (char const   *)"Invalid buffer address");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamplesBytes", (char const   *)"Invalid buffer address");
    return (1);
  }
  bytes_per_sample = ((int )bps + 7) / 8;
  src_rowsize = ((uint32 )bps * tw + 7U) / 8U;
  dst_rowsize = (imagewidth * (uint32 )bytes_per_sample) * (uint32 )spp;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        s = (tsample_t )0;
        {
        while (1) {
          while_continue___0: /* CIL Label */ ;

          if (! ((int )s < (int )spp)) {
            goto while_break___0;
          }
          dump_info(dumpfile, format, "combineSeparateTileSamplesBytes", "Input data, Sample %d",
                    (int )s);
          dump_buffer(dumpfile, format, (uint32 )1, cols, row, *(srcbuffs + (int )s) + row * src_rowsize);
          s = (tsample_t )((int )s + 1);
        }
        while_break___5: /* CIL Label */ ;
        }
        while_break___0: ;
      }
    }
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___1: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___1;
      }
      col_offset = src_offset + col * (uint32 )((int )bps / 8);
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___2: /* CIL Label */ ;

        if ((int )s < (int )spp) {
          if (! ((int )s < 8)) {
            goto while_break___2;
          }
        } else {
          goto while_break___2;
        }
        src = *(srcbuffs + (int )s) + col_offset;
        i = 0;
        {
        while (1) {
          while_continue___3: /* CIL Label */ ;

          if (! (i < bytes_per_sample)) {
            goto while_break___3;
          }
          *(dst + i) = *(src + i);
          i ++;
        }
        while_break___8: /* CIL Label */ ;
        }
        while_break___3: 
        dst += bytes_per_sample;
        s = (tsample_t )((int )s + 1);
      }
      while_break___7: /* CIL Label */ ;
      }
      while_break___2: 
      col ++;
    }
    while_break___6: /* CIL Label */ ;
    }
    while_break___1: ;
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateTileSamplesBytes", "Output data, combined samples");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateTileSamples8bits(uint8 **in , uint8 *out , uint32 cols ,
                                           uint32 rows , uint32 imagewidth , uint32 tw ,
                                           uint16 spp , uint16 bps , FILE *dumpfile ,
                                           int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 src_offset ;
  uint32 bit_offset ;
  uint32 row ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint8 maskbits ;
  uint8 matchbits ;
  uint8 buff1 ;
  uint8 buff2 ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[32] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  maskbits = (uint8 )0;
  matchbits = (uint8 )0;
  buff1 = (uint8 )0;
  buff2 = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples8bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * tw + 7U) / 8U;
  dst_rowsize = ((imagewidth * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  maskbits = (uint8 )(255 >> (8 - (int )bps));
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint8 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = (uint8 )((int )maskbits << ((8U - src_bit) - (uint32 )bps));
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        buff1 = (uint8 )(((int )*src & (int )matchbits) << src_bit);
        if (ready_bits >= 8) {
          tmp = dst;
          dst ++;
          *tmp = buff2;
          buff2 = buff1;
          ready_bits -= 8;
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          buff2 = (uint8 )((int )buff2 | ((int )buff1 >> ready_bits));
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Samples %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_byte(dumpfile, format, "Match bits", matchbits);
            dump_byte(dumpfile, format, "Src   bits", *src);
            dump_byte(dumpfile, format, "Buff1 bits", buff1);
            dump_byte(dumpfile, format, "Buff2 bits", buff2);
            dump_info(dumpfile, format, "", "%s", action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___4: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: ;
    if (ready_bits > 0) {
      buff1 = (uint8 )((unsigned int )buff2 & (255U << (8 - ready_bits)));
      tmp___0 = dst;
      dst ++;
      *tmp___0 = buff1;
      if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
        if (level == 3) {
          dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                    row + 1U, col + 1U, src_byte, src_bit, dst - out);
          dump_byte(dumpfile, format, "Final bits", buff1);
        }
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level >= 2) {
        dump_info(dumpfile, format, "combineSeparateTileSamples8bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateTileSamples16bits(uint8 **in , uint8 *out , uint32 cols ,
                                            uint32 rows , uint32 imagewidth , uint32 tw ,
                                            uint16 spp , uint16 bps , FILE *dumpfile ,
                                            int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 bit_offset ;
  uint32 src_offset ;
  uint32 row ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint16 maskbits ;
  uint16 matchbits ;
  uint16 buff1 ;
  uint16 buff2 ;
  uint8 bytebuff ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[8] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  maskbits = (uint16 )0;
  matchbits = (uint16 )0;
  buff1 = (uint16 )0;
  buff2 = (uint16 )0;
  bytebuff = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples16bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * tw + 7U) / 8U;
  dst_rowsize = ((imagewidth * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  maskbits = (uint16 )(65535 >> (16 - (int )bps));
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint16 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = (uint16 )((int )maskbits << ((16U - src_bit) - (uint32 )bps));
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        if (little_endian) {
          buff1 = (uint16 )(((int )*(src + 0) << 8) | (int )*(src + 1));
        } else {
          buff1 = (uint16 )(((int )*(src + 1) << 8) | (int )*(src + 0));
        }
        buff1 = (uint16 )(((int )buff1 & (int )matchbits) << src_bit);
        if (ready_bits >= 8) {
          bytebuff = (uint8 )((int )buff2 >> 8);
          tmp = dst;
          dst ++;
          *tmp = bytebuff;
          ready_bits -= 8;
          buff2 = (uint16 )(((int )buff2 << 8) | ((int )buff1 >> ready_bits));
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          bytebuff = (uint8 )0;
          buff2 = (uint16 )((int )buff2 | ((int )buff1 >> ready_bits));
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Samples %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_short(dumpfile, format, "Match bits", matchbits);
            dump_data(dumpfile, format, "Src   bits", src, (uint32 )2);
            dump_short(dumpfile, format, "Buff1 bits", buff1);
            dump_short(dumpfile, format, "Buff2 bits", buff2);
            dump_byte(dumpfile, format, "Write byte", bytebuff);
            dump_info(dumpfile, format, "", "Ready bits:  %d, %s", ready_bits, action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___4: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: ;
    if (ready_bits > 0) {
      bytebuff = (uint8 )((int )buff2 >> 8);
      tmp___0 = dst;
      dst ++;
      *tmp___0 = bytebuff;
      if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
        if (level == 3) {
          dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                    row + 1U, col + 1U, src_byte, src_bit, dst - out);
          dump_byte(dumpfile, format, "Final bits", bytebuff);
        }
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateTileSamples16bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateTileSamples24bits(uint8 **in , uint8 *out , uint32 cols ,
                                            uint32 rows , uint32 imagewidth , uint32 tw ,
                                            uint16 spp , uint16 bps , FILE *dumpfile ,
                                            int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 bit_offset ;
  uint32 src_offset ;
  uint32 row ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 maskbits ;
  uint32 matchbits ;
  uint32 buff1 ;
  uint32 buff2 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[8] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;
  unsigned char *tmp___1 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  maskbits = (uint32 )0;
  matchbits = (uint32 )0;
  buff1 = (uint32 )0;
  buff2 = (uint32 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples24bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * tw + 7U) / 8U;
  dst_rowsize = ((imagewidth * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  maskbits = 4294967295U >> (32 - (int )bps);
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint32 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = maskbits << ((32U - src_bit) - (uint32 )bps);
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        if (little_endian) {
          buff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
        } else {
          buff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
        }
        buff1 = (buff1 & matchbits) << src_bit;
        if (ready_bits >= 16) {
          bytebuff1 = (uint8 )(buff2 >> 24);
          tmp = dst;
          dst ++;
          *tmp = bytebuff1;
          bytebuff2 = (uint8 )(buff2 >> 16);
          tmp___0 = dst;
          dst ++;
          *tmp___0 = bytebuff2;
          ready_bits -= 16;
          buff2 = (buff2 << 16) | (buff1 >> ready_bits);
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          bytebuff2 = (uint8 )0;
          bytebuff1 = bytebuff2;
          buff2 |= buff1 >> ready_bits;
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Samples %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_long(dumpfile, format, "Match bits ", matchbits);
            dump_data(dumpfile, format, "Src   bits ", src, (uint32 )4);
            dump_long(dumpfile, format, "Buff1 bits ", buff1);
            dump_long(dumpfile, format, "Buff2 bits ", buff2);
            dump_byte(dumpfile, format, "Write bits1", bytebuff1);
            dump_byte(dumpfile, format, "Write bits2", bytebuff2);
            dump_info(dumpfile, format, "", "Ready bits:   %d, %s", ready_bits, action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___5: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___0: ;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! (ready_bits > 0)) {
        goto while_break___2;
      }
      bytebuff1 = (uint8 )(buff2 >> 24);
      tmp___1 = dst;
      dst ++;
      *tmp___1 = bytebuff1;
      buff2 <<= 8;
      bytebuff2 = bytebuff1;
      ready_bits -= 8;
    }
    while_break___6: /* CIL Label */ ;
    }
    while_break___2: ;
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 3) {
        dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                  row + 1U, col + 1U, src_byte, src_bit, dst - out);
        dump_long(dumpfile, format, "Match bits ", matchbits);
        dump_data(dumpfile, format, "Src   bits ", src, (uint32 )4);
        dump_long(dumpfile, format, "Buff1 bits ", buff1);
        dump_long(dumpfile, format, "Buff2 bits ", buff2);
        dump_byte(dumpfile, format, "Write bits1", bytebuff1);
        dump_byte(dumpfile, format, "Write bits2", bytebuff2);
        dump_info(dumpfile, format, "", "Ready bits:  %2d", ready_bits);
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateTileSamples24bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out + row * dst_rowsize);
      }
    }
    row ++;
  }
  while_break___3: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int combineSeparateTileSamples32bits(uint8 **in , uint8 *out , uint32 cols ,
                                            uint32 rows , uint32 imagewidth , uint32 tw ,
                                            uint16 spp , uint16 bps , FILE *dumpfile ,
                                            int format , int level ) 
{ 
  int ready_bits ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 bit_offset ;
  uint32 src_offset ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 row ;
  uint32 col ;
  uint32 longbuff1 ;
  uint32 longbuff2 ;
  uint64 maskbits ;
  uint64 matchbits ;
  uint64 buff1 ;
  uint64 buff2 ;
  uint64 buff3 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 bytebuff3 ;
  uint8 bytebuff4 ;
  tsample_t s ;
  unsigned char *src ;
  unsigned char *dst ;
  char action[8] ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;
  unsigned char *tmp___1 ;
  unsigned char *tmp___2 ;
  unsigned char *tmp___3 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  longbuff1 = (uint32 )0;
  longbuff2 = (uint32 )0;
  maskbits = (uint64 )0;
  matchbits = (uint64 )0;
  buff1 = (uint64 )0;
  buff2 = (uint64 )0;
  buff3 = (uint64 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  bytebuff3 = (uint8 )0;
  bytebuff4 = (uint8 )0;
  src = *(in + 0);
  dst = out;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"combineSeparateTileSamples32bits", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  src_rowsize = ((uint32 )bps * tw + 7U) / 8U;
  dst_rowsize = ((imagewidth * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  maskbits = 18446744073709551615UL >> (64 - (int )bps);
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < rows)) {
      goto while_break;
    }
    ready_bits = 0;
    buff2 = (uint64 )0;
    buff1 = buff2;
    dst = out + row * dst_rowsize;
    src_offset = row * src_rowsize;
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < cols)) {
        goto while_break___0;
      }
      bit_offset = col * (uint32 )bps;
      src_byte = bit_offset / 8U;
      src_bit = bit_offset % 8U;
      matchbits = maskbits << ((64U - src_bit) - (uint32 )bps);
      s = (tsample_t )0;
      {
      while (1) {
        while_continue___1: /* CIL Label */ ;

        if (! ((int )s < (int )spp)) {
          goto while_break___1;
        }
        src = (*(in + (int )s) + src_offset) + src_byte;
        if (little_endian) {
          longbuff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
          longbuff2 = longbuff1;
        } else {
          longbuff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
          longbuff2 = longbuff1;
        }
        buff3 = ((uint64 )longbuff1 << 32) | (unsigned long )longbuff2;
        buff1 = (buff3 & matchbits) << src_bit;
        if (ready_bits >= 32) {
          bytebuff1 = (uint8 )(buff2 >> 56);
          tmp = dst;
          dst ++;
          *tmp = bytebuff1;
          bytebuff2 = (uint8 )(buff2 >> 48);
          tmp___0 = dst;
          dst ++;
          *tmp___0 = bytebuff2;
          bytebuff3 = (uint8 )(buff2 >> 40);
          tmp___1 = dst;
          dst ++;
          *tmp___1 = bytebuff3;
          bytebuff4 = (uint8 )(buff2 >> 32);
          tmp___2 = dst;
          dst ++;
          *tmp___2 = bytebuff4;
          ready_bits -= 32;
          buff2 = (buff2 << 32) | (buff1 >> ready_bits);
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Flush");
        } else {
          bytebuff4 = (uint8 )0;
          bytebuff3 = bytebuff4;
          bytebuff2 = bytebuff3;
          bytebuff1 = bytebuff2;
          buff2 |= buff1 >> ready_bits;
          strcpy((char */* __restrict  */)(action), (char const   */* __restrict  */)"Update");
        }
        ready_bits += (int )bps;
        if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
          if (level == 3) {
            dump_info(dumpfile, format, "", "Row %3d, Col %3d, Sample %d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                      row + 1U, col + 1U, (int )s, src_byte, src_bit, dst - out);
            dump_wide(dumpfile, format, "Match bits ", matchbits);
            dump_data(dumpfile, format, "Src   bits ", src, (uint32 )8);
            dump_wide(dumpfile, format, "Buff1 bits ", buff1);
            dump_wide(dumpfile, format, "Buff2 bits ", buff2);
            dump_info(dumpfile, format, "", "Ready bits:   %d, %s", ready_bits, action);
          }
        }
        s = (tsample_t )((int )s + 1);
      }
      while_break___5: /* CIL Label */ ;
      }
      while_break___1: 
      col ++;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___0: ;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! (ready_bits > 0)) {
        goto while_break___2;
      }
      bytebuff1 = (uint8 )(buff2 >> 56);
      tmp___3 = dst;
      dst ++;
      *tmp___3 = bytebuff1;
      buff2 <<= 8;
      ready_bits -= 8;
    }
    while_break___6: /* CIL Label */ ;
    }
    while_break___2: ;
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 3) {
        dump_info(dumpfile, format, "", "Row %3d, Col %3d, Src byte offset %3d  bit offset %2d  Dst offset %3d",
                  row + 1U, col + 1U, src_byte, src_bit, dst - out);
        dump_long(dumpfile, format, "Match bits ", (uint32 )matchbits);
        dump_data(dumpfile, format, "Src   bits ", src, (uint32 )4);
        dump_long(dumpfile, format, "Buff1 bits ", (uint32 )buff1);
        dump_long(dumpfile, format, "Buff2 bits ", (uint32 )buff2);
        dump_byte(dumpfile, format, "Write bits1", bytebuff1);
        dump_byte(dumpfile, format, "Write bits2", bytebuff2);
        dump_info(dumpfile, format, "", "Ready bits:  %2d", ready_bits);
      }
    }
    if ((unsigned long )dumpfile != (unsigned long )((void *)0)) {
      if (level == 2) {
        dump_info(dumpfile, format, "combineSeparateTileSamples32bits", "Output data");
        dump_buffer(dumpfile, format, (uint32 )1, dst_rowsize, row, out);
      }
    }
    row ++;
  }
  while_break___3: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int readSeparateStripsIntoBuffer(TIFF *in , uint8 *obuf , uint32 length , uint32 width ,
                                        unsigned short spp , struct dump_opts *dump ) 
{ 
  int i ;
  int j ;
  int bytes_per_sample ;
  int bytes_per_pixel ;
  int shift_width ;
  int result ;
  int32 bytes_read ;
  uint16 bps ;
  uint16 nstrips ;
  uint16 planar ;
  uint16 strips_per_sample ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 rows_processed ;
  uint32 rps ;
  uint32 rows_this_strip ;
  tsample_t s ;
  tstrip_t strip ;
  tsize_t scanlinesize ;
  tmsize_t tmp ;
  tsize_t stripsize ;
  tmsize_t tmp___0 ;
  unsigned char *srcbuffs[8] ;
  unsigned char *buff ;
  unsigned char *dst ;
  uint32 tmp___1 ;
  void *tmp___2 ;
  tmsize_t tmp___3 ;
  char const   *tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;

  {
  result = 1;
  bytes_read = 0;
  rows_this_strip = (uint32 )0;
  tmp = TIFFScanlineSize(in);
  scanlinesize = tmp;
  tmp___0 = TIFFStripSize(in);
  stripsize = tmp___0;
  buff = (unsigned char *)((void *)0);
  dst = (unsigned char *)((void *)0);
  if ((unsigned long )obuf == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"readSeparateStripsIntoBuffer", (char const   *)"Invalid buffer argument");
    return (0);
  }
  memset((void *)(srcbuffs), '\000', sizeof(srcbuffs));
  TIFFGetField(in, (uint32 )258, & bps);
  TIFFGetFieldDefaulted(in, (uint32 )284, & planar);
  TIFFGetFieldDefaulted(in, (uint32 )278, & rps);
  if (rps > length) {
    rps = length;
  }
  bytes_per_sample = ((int )bps + 7) / 8;
  bytes_per_pixel = ((int )bps * (int )spp + 7) / 8;
  if (bytes_per_pixel < bytes_per_sample + 1) {
    shift_width = bytes_per_pixel;
  } else {
    shift_width = bytes_per_sample + 1;
  }
  src_rowsize = ((uint32 )bps * width + 7U) / 8U;
  dst_rowsize = (((uint32 )bps * width) * (uint32 )spp + 7U) / 8U;
  dst = obuf;
  if ((unsigned long )dump->infile != (unsigned long )((void *)0)) {
    if (dump->level == 3) {
      dump_info(dump->infile, dump->format, "", "Image width %d, length %d, Scanline size, %4d bytes",
                width, length, scanlinesize);
      dump_info(dump->infile, dump->format, "", "Bits per sample %d, Samples per pixel %d, Shift width %d",
                (int )bps, (int )spp, shift_width);
    }
  }
  tmp___1 = TIFFNumberOfStrips(in);
  nstrips = (uint16 )tmp___1;
  strips_per_sample = (uint16 )((int )nstrips / (int )spp);
  s = (tsample_t )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if ((int )s < (int )spp) {
      if (! ((int )s < 8)) {
        goto while_break;
      }
    } else {
      goto while_break;
    }
    srcbuffs[s] = (unsigned char *)((void *)0);
    tmp___2 = _TIFFmalloc(stripsize);
    buff = (unsigned char *)tmp___2;
    if (! buff) {
      TIFFError((char const   *)"readSeparateStripsIntoBuffer", (char const   *)"Unable to allocate strip read buffer for sample %d",
                (int )s);
      i = 0;
      {
      while (1) {
        while_continue___0: /* CIL Label */ ;

        if (! (i < (int )s)) {
          goto while_break___0;
        }
        _TIFFfree((void *)srcbuffs[i]);
        i ++;
      }
      while_break___5: /* CIL Label */ ;
      }
      while_break___0: ;
      return (0);
    }
    srcbuffs[s] = buff;
    s = (tsample_t )((int )s + 1);
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break: 
  rows_processed = (uint32 )0;
  j = 0;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (j < (int )strips_per_sample) {
      if (! (result == 1)) {
        goto while_break___1;
      }
    } else {
      goto while_break___1;
    }
    s = (tsample_t )0;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if ((int )s < (int )spp) {
        if (! ((int )s < 8)) {
          goto while_break___2;
        }
      } else {
        goto while_break___2;
      }
      buff = srcbuffs[s];
      strip = (tstrip_t )((int )s * (int )strips_per_sample + j);
      tmp___3 = TIFFReadEncodedStrip(in, strip, (void *)buff, stripsize);
      bytes_read = (int32 )tmp___3;
      rows_this_strip = (uint32 )bytes_read / src_rowsize;
      if (bytes_read < 0) {
        if (! ignore) {
          tmp___4 = TIFFFileName(in);
          TIFFError(tmp___4, (char const   *)"Error, can\'t read strip %lu for sample %d",
                    (unsigned long )strip, (int )s + 1);
          result = 0;
          goto while_break___2;
        }
      }
      s = (tsample_t )((int )s + 1);
    }
    while_break___7: /* CIL Label */ ;
    }
    while_break___2: ;
    if (rps > rows_this_strip) {
      rps = rows_this_strip;
    }
    dst = obuf + dst_rowsize * rows_processed;
    if ((int )bps % 8 == 0) {
      tmp___5 = combineSeparateSamplesBytes(srcbuffs, dst, width, rps, spp, bps, dump->infile,
                                            dump->format, dump->level);
      if (tmp___5) {
        result = 0;
        goto while_break___1;
      }
    } else {
      if (shift_width == 1) {
        goto case_1;
      }
      if (shift_width == 2) {
        goto case_2;
      }
      if (shift_width == 3) {
        goto case_3;
      }
      if (shift_width == 8) {
        goto case_8;
      }
      if (shift_width == 7) {
        goto case_8;
      }
      if (shift_width == 6) {
        goto case_8;
      }
      if (shift_width == 5) {
        goto case_8;
      }
      if (shift_width == 4) {
        goto case_8;
      }
      goto switch_default;
      case_1: 
      tmp___6 = combineSeparateSamples8bits(srcbuffs, dst, width, rps, spp, bps, dump->infile,
                                            dump->format, dump->level);
      if (tmp___6) {
        result = 0;
        goto switch_break;
      }
      goto switch_break;
      case_2: 
      tmp___7 = combineSeparateSamples16bits(srcbuffs, dst, width, rps, spp, bps,
                                             dump->infile, dump->format, dump->level);
      if (tmp___7) {
        result = 0;
        goto switch_break;
      }
      goto switch_break;
      case_3: 
      tmp___8 = combineSeparateSamples24bits(srcbuffs, dst, width, rps, spp, bps,
                                             dump->infile, dump->format, dump->level);
      if (tmp___8) {
        result = 0;
        goto switch_break;
      }
      goto switch_break;
      case_8: 
      tmp___9 = combineSeparateSamples32bits(srcbuffs, dst, width, rps, spp, bps,
                                             dump->infile, dump->format, dump->level);
      if (tmp___9) {
        result = 0;
        goto switch_break;
      }
      goto switch_break;
      switch_default: 
      TIFFError((char const   *)"readSeparateStripsIntoBuffer", (char const   *)"Unsupported bit depth: %d",
                (int )bps);
      result = 0;
      goto switch_break;
      switch_break: ;
    }
    if (rows_processed + rps > length) {
      rows_processed = length;
      rps = length - rows_processed;
    } else {
      rows_processed += rps;
    }
    j ++;
  }
  while_break___6: /* CIL Label */ ;
  }
  while_break___1: 
  s = (tsample_t )0;
  {
  while (1) {
    while_continue___3: /* CIL Label */ ;

    if ((int )s < (int )spp) {
      if (! ((int )s < 8)) {
        goto while_break___3;
      }
    } else {
      goto while_break___3;
    }
    buff = srcbuffs[s];
    if ((unsigned long )buff != (unsigned long )((void *)0)) {
      _TIFFfree((void *)buff);
    }
    s = (tsample_t )((int )s + 1);
  }
  while_break___8: /* CIL Label */ ;
  }
  while_break___3: ;
  return (result);
}
}
static int get_page_geometry(char *name , struct pagedef *page ) 
{ 
  char *ptr ;
  int n ;
  int tmp ;
  int tmp___0 ;

  {
  ptr = name;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! *ptr) {
      goto while_break;
    }
    tmp = tolower((int )*ptr);
    *ptr = (char )tmp;
    ptr ++;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: 
  n = 0;
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;

    if (! (n < 49)) {
      goto while_break___0;
    }
    tmp___0 = strcmp((char const   *)name, (char const   *)(PaperTable[n].name));
    if (tmp___0 == 0) {
      page->width = PaperTable[n].width;
      page->length = PaperTable[n].length;
      strncpy((char */* __restrict  */)(page->name), (char const   */* __restrict  */)(PaperTable[n].name),
              (size_t )15);
      page->name[15] = (char )'\000';
      return (0);
    }
    n ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break___0: ;
  return (1);
}
}
static void initPageSetup(struct pagedef *page , struct pageseg *pagelist , struct buffinfo *seg_buffs ) 
{ 
  int i ;

  {
  strcpy((char */* __restrict  */)(page->name), (char const   */* __restrict  */)"");
  page->mode = (uint32 )0;
  page->res_unit = (uint16 )1;
  page->hres = 0.0;
  page->vres = 0.0;
  page->width = 0.0;
  page->length = 0.0;
  page->hmargin = 0.0;
  page->vmargin = 0.0;
  page->rows = 0U;
  page->cols = 0U;
  page->orient = 0U;
  i = 0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < 32)) {
      goto while_break;
    }
    (pagelist + i)->x1 = (uint32 )0;
    (pagelist + i)->x2 = (uint32 )0;
    (pagelist + i)->y1 = (uint32 )0;
    (pagelist + i)->y2 = (uint32 )0;
    (pagelist + i)->buffsize = (uint32 )0;
    (pagelist + i)->position = 0;
    (pagelist + i)->total = 0;
    i ++;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: 
  i = 0;
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;

    if (! (i < 8)) {
      goto while_break___0;
    }
    (seg_buffs + i)->size = (uint32 )0;
    (seg_buffs + i)->buffer = (unsigned char *)((void *)0);
    i ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break___0: ;
  return;
}
}
static void initImageData(struct image_data *image ) 
{ 


  {
  image->xres = (float )0.0;
  image->yres = (float )0.0;
  image->width = (uint32 )0;
  image->length = (uint32 )0;
  image->res_unit = (uint16 )1;
  image->bps = (uint16 )0;
  image->spp = (uint16 )0;
  image->planar = (uint16 )0;
  image->photometric = (uint16 )0;
  image->orientation = (uint16 )0;
  image->compression = (uint16 )1;
  image->adjustments = (uint16 )0;
  return;
}
}
static void initCropMasks(struct crop_mask *cps ) 
{ 
  int i ;

  {
  cps->crop_mode = (uint16 )0;
  cps->res_unit = (uint16 )1;
  cps->edge_ref = (uint16 )1;
  cps->width = (double )0;
  cps->length = (double )0;
  i = 0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < 4)) {
      goto while_break;
    }
    cps->margins[i] = 0.0;
    i ++;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: 
  cps->bufftotal = (uint32 )0;
  cps->combined_width = (uint32 )0;
  cps->combined_length = (uint32 )0;
  cps->rotation = (uint16 )0;
  cps->photometric = (uint16 )11;
  cps->mirror = (uint16 )0;
  cps->invert = (uint16 )0;
  cps->zones = (uint16 )((uint32 )0);
  cps->regions = (uint16 )((uint32 )0);
  i = 0;
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;

    if (! (i < 8)) {
      goto while_break___0;
    }
    cps->corners[i].X1 = 0.0;
    cps->corners[i].X2 = 0.0;
    cps->corners[i].Y1 = 0.0;
    cps->corners[i].Y2 = 0.0;
    cps->regionlist[i].x1 = (uint32 )0;
    cps->regionlist[i].x2 = (uint32 )0;
    cps->regionlist[i].y1 = (uint32 )0;
    cps->regionlist[i].y2 = (uint32 )0;
    cps->regionlist[i].width = (uint32 )0;
    cps->regionlist[i].length = (uint32 )0;
    cps->regionlist[i].buffsize = (uint32 )0;
    cps->regionlist[i].buffptr = (unsigned char *)((void *)0);
    cps->zonelist[i].position = 0;
    cps->zonelist[i].total = 0;
    i ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break___0: 
  cps->exp_mode = (uint16 )0;
  cps->img_mode = (uint16 )0;
  return;
}
}
static void initDumpOptions(struct dump_opts *dump ) 
{ 


  {
  dump->debug = 0;
  dump->format = 0;
  dump->level = 1;
  sprintf((char */* __restrict  */)(dump->mode), (char const   */* __restrict  */)"w");
  memset((void *)(dump->infilename), '\000', (size_t )4097);
  memset((void *)(dump->outfilename), '\000', (size_t )4097);
  dump->infile = (FILE *)((void *)0);
  dump->outfile = (FILE *)((void *)0);
  return;
}
}
static int computeInputPixelOffsets(struct crop_mask *crop , struct image_data *image ,
                                    struct offset *off ) 
{ 
  double scale ;
  float xres ;
  float yres ;
  uint32 tmargin ;
  uint32 bmargin ;
  uint32 lmargin ;
  uint32 rmargin ;
  uint32 startx ;
  uint32 endx ;
  uint32 starty ;
  uint32 endy ;
  uint32 width ;
  uint32 length ;
  uint32 crop_width ;
  uint32 crop_length ;
  uint32 i ;
  uint32 max_width ;
  uint32 max_length ;
  uint32 zwidth ;
  uint32 zlength ;
  uint32 buffsize ;
  uint32 x1 ;
  uint32 x2 ;
  uint32 y1___0 ;
  uint32 y2 ;

  {
  if ((int )image->res_unit != 2) {
    if ((int )image->res_unit != 3) {
      xres = (float )1.0;
      yres = (float )1.0;
    } else {
      goto _L___0;
    }
  } else {
    _L___0: 
    if (image->xres == (float )0) {
      goto _L;
    } else
    if (image->yres == (float )0) {
      _L: 
      if ((int )crop->res_unit != 1) {
        if ((int )crop->crop_mode & 16) {
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Cannot compute margins or fixed size sections without image resolution");
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Specify units in pixels and try again");
          return (-1);
        } else
        if ((int )crop->crop_mode & 1) {
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Cannot compute margins or fixed size sections without image resolution");
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Specify units in pixels and try again");
          return (-1);
        } else
        if ((int )crop->crop_mode & 4) {
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Cannot compute margins or fixed size sections without image resolution");
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Specify units in pixels and try again");
          return (-1);
        } else
        if ((int )crop->crop_mode & 2) {
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Cannot compute margins or fixed size sections without image resolution");
          TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Specify units in pixels and try again");
          return (-1);
        }
      }
    }
    xres = image->xres;
    yres = image->yres;
  }
  scale = 1.0;
  if ((int )crop->res_unit == 3) {
    goto case_3;
  }
  if ((int )crop->res_unit == 2) {
    goto case_2;
  }
  goto switch_default;
  case_3: 
  if ((int )image->res_unit == 2) {
    scale = 1.0 / 2.54;
  }
  goto switch_break;
  case_2: 
  if ((int )image->res_unit == 3) {
    scale = 2.54;
  }
  goto switch_break;
  switch_default: 
  goto switch_break;
  switch_break: ;
  if ((int )crop->crop_mode & 16) {
    max_length = (uint32 )0;
    max_width = max_length;
    i = (uint32 )0;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (i < (uint32 )crop->regions)) {
        goto while_break;
      }
      if ((int )crop->res_unit == 2) {
        x1 = (uint32 )((crop->corners[i].X1 * scale) * (double )xres);
        x2 = (uint32 )((crop->corners[i].X2 * scale) * (double )xres);
        y1___0 = (uint32 )((crop->corners[i].Y1 * scale) * (double )yres);
        y2 = (uint32 )((crop->corners[i].Y2 * scale) * (double )yres);
      } else
      if ((int )crop->res_unit == 3) {
        x1 = (uint32 )((crop->corners[i].X1 * scale) * (double )xres);
        x2 = (uint32 )((crop->corners[i].X2 * scale) * (double )xres);
        y1___0 = (uint32 )((crop->corners[i].Y1 * scale) * (double )yres);
        y2 = (uint32 )((crop->corners[i].Y2 * scale) * (double )yres);
      } else {
        x1 = (uint32 )crop->corners[i].X1;
        x2 = (uint32 )crop->corners[i].X2;
        y1___0 = (uint32 )crop->corners[i].Y1;
        y2 = (uint32 )crop->corners[i].Y2;
      }
      if (x1 < 1U) {
        crop->regionlist[i].x1 = (uint32 )0;
      } else {
        crop->regionlist[i].x1 = x1 - 1U;
      }
      if (x2 > image->width - 1U) {
        crop->regionlist[i].x2 = image->width - 1U;
      } else {
        crop->regionlist[i].x2 = x2 - 1U;
      }
      zwidth = (crop->regionlist[i].x2 - crop->regionlist[i].x1) + 1U;
      if (y1___0 < 1U) {
        crop->regionlist[i].y1 = (uint32 )0;
      } else {
        crop->regionlist[i].y1 = y1___0 - 1U;
      }
      if (y2 > image->length - 1U) {
        crop->regionlist[i].y2 = image->length - 1U;
      } else {
        crop->regionlist[i].y2 = y2 - 1U;
      }
      zlength = (crop->regionlist[i].y2 - crop->regionlist[i].y1) + 1U;
      if (zwidth > max_width) {
        max_width = zwidth;
      }
      if (zlength > max_length) {
        max_length = zlength;
      }
      buffsize = (((zwidth * (uint32 )image->bps) * (uint32 )image->spp + 7U) / 8U) * (zlength + 1U);
      crop->regionlist[i].buffsize = buffsize;
      crop->bufftotal += buffsize;
      if ((int )crop->img_mode == 0) {
        if ((int )crop->edge_ref == 4) {
          goto case_4;
        }
        if ((int )crop->edge_ref == 2) {
          goto case_4;
        }
        goto switch_default___0;
        case_4: 
        crop->combined_length = zlength;
        crop->combined_width += zwidth;
        goto switch_break___0;
        switch_default___0: 
        crop->combined_width = zwidth;
        crop->combined_length += zlength;
        goto switch_break___0;
        switch_break___0: ;
      }
      i ++;
    }
    while_break___0: /* CIL Label */ ;
    }
    while_break: ;
    return (0);
  }
  if ((int )crop->crop_mode & 1) {
    if ((int )crop->res_unit != 2) {
      if ((int )crop->res_unit != 3) {
        tmargin = (uint32 )crop->margins[0];
        lmargin = (uint32 )crop->margins[1];
        bmargin = (uint32 )crop->margins[2];
        rmargin = (uint32 )crop->margins[3];
      } else {
        tmargin = (uint32 )((crop->margins[0] * scale) * (double )yres);
        lmargin = (uint32 )((crop->margins[1] * scale) * (double )xres);
        bmargin = (uint32 )((crop->margins[2] * scale) * (double )yres);
        rmargin = (uint32 )((crop->margins[3] * scale) * (double )xres);
      }
    } else {
      tmargin = (uint32 )((crop->margins[0] * scale) * (double )yres);
      lmargin = (uint32 )((crop->margins[1] * scale) * (double )xres);
      bmargin = (uint32 )((crop->margins[2] * scale) * (double )yres);
      rmargin = (uint32 )((crop->margins[3] * scale) * (double )xres);
    }
    if (lmargin + rmargin > image->width) {
      TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Combined left and right margins exceed image width");
      lmargin = (uint32 )0;
      rmargin = (uint32 )0;
      return (-1);
    }
    if (tmargin + bmargin > image->length) {
      TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Combined top and bottom margins exceed image length");
      tmargin = (uint32 )0;
      bmargin = (uint32 )0;
      return (-1);
    }
  } else {
    tmargin = (uint32 )0;
    lmargin = (uint32 )0;
    bmargin = (uint32 )0;
    rmargin = (uint32 )0;
  }
  if ((int )crop->res_unit != 2) {
    if ((int )crop->res_unit != 3) {
      if ((int )crop->crop_mode & 2) {
        width = (uint32 )crop->width;
      } else {
        width = (image->width - lmargin) - rmargin;
      }
      if ((int )crop->crop_mode & 4) {
        length = (uint32 )crop->length;
      } else {
        length = (image->length - tmargin) - bmargin;
      }
    } else {
      goto _L___1;
    }
  } else {
    _L___1: 
    if ((int )crop->crop_mode & 2) {
      width = (uint32 )((crop->width * scale) * (double )image->xres);
    } else {
      width = (image->width - lmargin) - rmargin;
    }
    if ((int )crop->crop_mode & 4) {
      length = (uint32 )((crop->length * scale) * (double )image->yres);
    } else {
      length = (image->length - tmargin) - bmargin;
    }
  }
  off->tmargin = tmargin;
  off->bmargin = bmargin;
  off->lmargin = lmargin;
  off->rmargin = rmargin;
  if ((int )crop->edge_ref == 3) {
    goto case_3___0;
  }
  if ((int )crop->edge_ref == 4) {
    goto case_4___0;
  }
  goto switch_default___1;
  case_3___0: 
  startx = lmargin;
  if (startx + width >= image->width - rmargin) {
    endx = (image->width - rmargin) - 1U;
  } else {
    endx = (startx + width) - 1U;
  }
  endy = (image->length - bmargin) - 1U;
  if (endy - length <= tmargin) {
    starty = tmargin;
  } else {
    starty = (endy - length) + 1U;
  }
  goto switch_break___1;
  case_4___0: 
  endx = (image->width - rmargin) - 1U;
  if (endx - width <= lmargin) {
    startx = lmargin;
  } else {
    startx = (endx - width) + 1U;
  }
  starty = tmargin;
  if (starty + length >= image->length - bmargin) {
    endy = (image->length - bmargin) - 1U;
  } else {
    endy = (starty + length) - 1U;
  }
  goto switch_break___1;
  switch_default___1: 
  startx = lmargin;
  if (startx + width >= image->width - rmargin) {
    endx = (image->width - rmargin) - 1U;
  } else {
    endx = (startx + width) - 1U;
  }
  starty = tmargin;
  if (starty + length >= image->length - bmargin) {
    endy = (image->length - bmargin) - 1U;
  } else {
    endy = (starty + length) - 1U;
  }
  goto switch_break___1;
  switch_break___1: 
  off->startx = startx;
  off->starty = starty;
  off->endx = endx;
  off->endy = endy;
  crop_width = (endx - startx) + 1U;
  crop_length = (endy - starty) + 1U;
  if (crop_width <= 0U) {
    TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Invalid left/right margins and /or image crop width requested");
    return (-1);
  }
  if (crop_width > image->width) {
    crop_width = image->width;
  }
  if (crop_length <= 0U) {
    TIFFError((char const   *)"computeInputPixelOffsets", (char const   *)"Invalid top/bottom margins and /or image crop length requested");
    return (-1);
  }
  if (crop_length > image->length) {
    crop_length = image->length;
  }
  off->crop_width = crop_width;
  off->crop_length = crop_length;
  return (0);
}
}
static int getCropOffsets(struct image_data *image , struct crop_mask *crop , struct dump_opts *dump ) 
{ 
  struct offset offsets ;
  int i ;
  int32 test ;
  uint32 seg ;
  uint32 total ;
  uint32 need_buff ;
  uint32 buffsize ;
  uint32 zwidth ;
  uint32 zlength ;
  int tmp ;

  {
  need_buff = (uint32 )0;
  memset((void *)(& offsets), '\000', sizeof(struct offset ));
  crop->bufftotal = (uint32 )0;
  crop->combined_width = (uint32 )0;
  crop->combined_length = (uint32 )0;
  crop->selections = (uint16 )0;
  if ((int )crop->crop_mode & 1) {
    goto _L;
  } else
  if ((int )crop->crop_mode & 16) {
    goto _L;
  } else
  if ((int )crop->crop_mode & 4) {
    goto _L;
  } else
  if ((int )crop->crop_mode & 2) {
    _L: 
    tmp = computeInputPixelOffsets(crop, image, & offsets);
    if (tmp) {
      TIFFError((char const   *)"getCropOffsets", (char const   *)"Unable to compute crop margins");
      return (-1);
    }
    need_buff = (uint32 )1;
    crop->selections = crop->regions;
    if ((int )crop->crop_mode & 16) {
      return (0);
    }
  } else {
    offsets.tmargin = (uint32 )0;
    offsets.lmargin = (uint32 )0;
    offsets.bmargin = (uint32 )0;
    offsets.rmargin = (uint32 )0;
    offsets.crop_width = image->width;
    offsets.crop_length = image->length;
    offsets.startx = (uint32 )0;
    offsets.endx = image->width - 1U;
    offsets.starty = (uint32 )0;
    offsets.endy = image->length - 1U;
    need_buff = (uint32 )0;
  }
  if ((unsigned long )dump->outfile != (unsigned long )((void *)0)) {
    dump_info(dump->outfile, dump->format, "", "Margins: Top: %d  Left: %d  Bottom: %d  Right: %d",
              offsets.tmargin, offsets.lmargin, offsets.bmargin, offsets.rmargin);
    dump_info(dump->outfile, dump->format, "", "Crop region within margins: Adjusted Width:  %6d  Length: %6d",
              offsets.crop_width, offsets.crop_length);
  }
  if (! ((int )crop->crop_mode & 8)) {
    if (need_buff == 0U) {
      crop->selections = (uint16 )0;
      crop->combined_width = image->width;
      crop->combined_length = image->length;
      return (0);
    } else {
      crop->selections = (uint16 )1;
      crop->zones = (uint16 )1;
      crop->zonelist[0].total = 1;
      crop->zonelist[0].position = 1;
    }
  } else {
    crop->selections = crop->zones;
  }
  i = 0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < (int )crop->zones)) {
      goto while_break;
    }
    seg = (uint32 )crop->zonelist[i].position;
    total = (uint32 )crop->zonelist[i].total;
    if ((int )crop->edge_ref == 2) {
      goto case_2;
    }
    if ((int )crop->edge_ref == 3) {
      goto case_3;
    }
    if ((int )crop->edge_ref == 4) {
      goto case_4;
    }
    goto switch_default;
    case_2: 
    zlength = offsets.crop_length;
    crop->regionlist[i].y1 = offsets.starty;
    crop->regionlist[i].y2 = offsets.endy;
    crop->regionlist[i].x1 = offsets.startx + (uint32 )((((double )offsets.crop_width * 1.0) * (double )(seg - 1U)) / (double )total);
    test = (int32 )offsets.startx + (int32 )((((double )offsets.crop_width * 1.0) * (double )seg) / (double )total);
    if (test < 1) {
      crop->regionlist[i].x2 = (uint32 )0;
    } else
    if (test > (int32 )(image->width - 1U)) {
      crop->regionlist[i].x2 = image->width - 1U;
    } else {
      crop->regionlist[i].x2 = (uint32 )(test - 1);
    }
    zwidth = (crop->regionlist[i].x2 - crop->regionlist[i].x1) + 1U;
    crop->combined_length = zlength;
    if ((int )crop->exp_mode == 0) {
      crop->combined_width += zwidth;
    } else {
      crop->combined_width = zwidth;
    }
    goto switch_break;
    case_3: 
    zwidth = offsets.crop_width;
    crop->regionlist[i].x1 = offsets.startx;
    crop->regionlist[i].x2 = offsets.endx;
    test = (int32 )(offsets.endy - (uint32 )((((double )offsets.crop_length * 1.0) * (double )seg) / (double )total));
    if (test < 1) {
      crop->regionlist[i].y1 = (uint32 )0;
    } else {
      crop->regionlist[i].y1 = (uint32 )(test + 1);
    }
    test = (int32 )((double )offsets.endy - (((double )offsets.crop_length * 1.0) * (double )(seg - 1U)) / (double )total);
    if (test < 1) {
      crop->regionlist[i].y2 = (uint32 )0;
    } else
    if (test > (int32 )(image->length - 1U)) {
      crop->regionlist[i].y2 = image->length - 1U;
    } else {
      crop->regionlist[i].y2 = (uint32 )test;
    }
    zlength = (crop->regionlist[i].y2 - crop->regionlist[i].y1) + 1U;
    if ((int )crop->exp_mode == 0) {
      crop->combined_length += zlength;
    } else {
      crop->combined_length = zlength;
    }
    crop->combined_width = zwidth;
    goto switch_break;
    case_4: 
    zlength = offsets.crop_length;
    crop->regionlist[i].y1 = offsets.starty;
    crop->regionlist[i].y2 = offsets.endy;
    crop->regionlist[i].x1 = offsets.startx + (uint32 )(((double )(offsets.crop_width * (total - seg)) * 1.0) / (double )total);
    test = (int32 )((double )offsets.startx + ((double )(offsets.crop_width * ((total - seg) + 1U)) * 1.0) / (double )total);
    if (test < 1) {
      crop->regionlist[i].x2 = (uint32 )0;
    } else
    if (test > (int32 )(image->width - 1U)) {
      crop->regionlist[i].x2 = image->width - 1U;
    } else {
      crop->regionlist[i].x2 = (uint32 )(test - 1);
    }
    zwidth = (crop->regionlist[i].x2 - crop->regionlist[i].x1) + 1U;
    crop->combined_length = zlength;
    if ((int )crop->exp_mode == 0) {
      crop->combined_width += zwidth;
    } else {
      crop->combined_width = zwidth;
    }
    goto switch_break;
    switch_default: 
    zwidth = offsets.crop_width;
    crop->regionlist[i].x1 = offsets.startx;
    crop->regionlist[i].x2 = offsets.endx;
    crop->regionlist[i].y1 = offsets.starty + (uint32 )((((double )offsets.crop_length * 1.0) * (double )(seg - 1U)) / (double )total);
    test = (int32 )(offsets.starty + (uint32 )((((double )offsets.crop_length * 1.0) * (double )seg) / (double )total));
    if (test < 1) {
      crop->regionlist[i].y2 = (uint32 )0;
    } else
    if (test > (int32 )(image->length - 1U)) {
      crop->regionlist[i].y2 = image->length - 1U;
    } else {
      crop->regionlist[i].y2 = (uint32 )(test - 1);
    }
    zlength = (crop->regionlist[i].y2 - crop->regionlist[i].y1) + 1U;
    if ((int )crop->exp_mode == 0) {
      crop->combined_length += zlength;
    } else {
      crop->combined_length = zlength;
    }
    crop->combined_width = zwidth;
    goto switch_break;
    switch_break: 
    buffsize = (((zwidth * (uint32 )image->bps) * (uint32 )image->spp + 7U) / 8U) * (zlength + 1U);
    crop->regionlist[i].width = zwidth;
    crop->regionlist[i].length = zlength;
    crop->regionlist[i].buffsize = buffsize;
    crop->bufftotal += buffsize;
    if ((unsigned long )dump->outfile != (unsigned long )((void *)0)) {
      dump_info(dump->outfile, dump->format, "", "Zone %d, width: %4d, length: %4d, x1: %4d  x2: %4d  y1: %4d  y2: %4d",
                i + 1, zwidth, zlength, crop->regionlist[i].x1, crop->regionlist[i].x2,
                crop->regionlist[i].y1, crop->regionlist[i].y2);
    }
    i ++;
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int computeOutputPixelOffsets(struct crop_mask *crop , struct image_data *image ,
                                     struct pagedef *page , struct pageseg *sections ,
                                     struct dump_opts *dump ) 
{ 
  double scale ;
  double pwidth ;
  double plength ;
  uint32 iwidth ;
  uint32 ilength ;
  uint32 owidth ;
  uint32 olength ;
  uint32 orows ;
  uint32 ocols ;
  uint32 hmargin ;
  uint32 vmargin ;
  uint32 x1 ;
  uint32 x2 ;
  uint32 y1___0 ;
  uint32 y2 ;
  uint32 line_bytes ;
  uint32 i ;
  uint32 j ;
  uint32 k ;
  uint32 tmp ;

  {
  scale = 1.0;
  if ((int )page->res_unit == 1) {
    page->res_unit = image->res_unit;
  }
  if ((int )image->res_unit == 3) {
    goto case_3;
  }
  if ((int )image->res_unit == 2) {
    goto case_2;
  }
  goto switch_default;
  case_3: 
  if ((int )page->res_unit == 2) {
    scale = 1.0 / 2.54;
  }
  goto switch_break;
  case_2: 
  if ((int )page->res_unit == 3) {
    scale = 2.54;
  }
  goto switch_break;
  switch_default: 
  goto switch_break;
  switch_break: ;
  if (crop->combined_width > 0U) {
    iwidth = crop->combined_width;
  } else {
    iwidth = image->width;
  }
  if (crop->combined_length > 0U) {
    ilength = crop->combined_length;
  } else {
    ilength = image->length;
  }
  if (page->hres <= 1.0) {
    page->hres = (double )image->xres;
  }
  if (page->vres <= 1.0) {
    page->vres = (double )image->yres;
  }
  if (page->hres < 1.0) {
    TIFFError((char const   *)"computeOutputPixelOffsets", (char const   *)"Invalid horizontal or vertical resolution specified or read from input image");
    return (1);
  } else
  if (page->vres < 1.0) {
    TIFFError((char const   *)"computeOutputPixelOffsets", (char const   *)"Invalid horizontal or vertical resolution specified or read from input image");
    return (1);
  }
  if (page->width <= (double )0) {
    pwidth = (double )iwidth;
  } else {
    pwidth = page->width;
  }
  if (page->length <= (double )0) {
    plength = (double )ilength;
  } else {
    plength = page->length;
  }
  if (dump->debug) {
    TIFFError((char const   *)"", (char const   *)"Page size: %s, Vres: %3.2f, Hres: %3.2f, Hmargin: %3.2f, Vmargin: %3.2f",
              page->name, page->vres, page->hres, page->hmargin, page->vmargin);
    TIFFError((char const   *)"", (char const   *)"Res_unit: %d, Scale: %3.2f, Page width: %3.2f, length: %3.2f",
              (int )page->res_unit, scale, pwidth, plength);
  }
  if (page->mode & 4U) {
    if ((int )page->res_unit == 2) {
      hmargin = (uint32 )(((page->hmargin * scale) * page->hres) * (double )(((int )image->bps + 7) / 8));
      vmargin = (uint32 )(((page->vmargin * scale) * page->vres) * (double )(((int )image->bps + 7) / 8));
    } else
    if ((int )page->res_unit == 3) {
      hmargin = (uint32 )(((page->hmargin * scale) * page->hres) * (double )(((int )image->bps + 7) / 8));
      vmargin = (uint32 )(((page->vmargin * scale) * page->vres) * (double )(((int )image->bps + 7) / 8));
    } else {
      hmargin = (uint32 )((page->hmargin * scale) * (double )(((int )image->bps + 7) / 8));
      vmargin = (uint32 )((page->vmargin * scale) * (double )(((int )image->bps + 7) / 8));
    }
    if ((double )hmargin * 2.0 > pwidth * page->hres) {
      TIFFError((char const   *)"computeOutputPixelOffsets", (char const   *)"Combined left and right margins exceed page width");
      hmargin = (uint32 )0;
      return (-1);
    }
    if ((double )vmargin * 2.0 > plength * page->vres) {
      TIFFError((char const   *)"computeOutputPixelOffsets", (char const   *)"Combined top and bottom margins exceed page length");
      vmargin = (uint32 )0;
      return (-1);
    }
  } else {
    hmargin = (uint32 )0;
    vmargin = (uint32 )0;
  }
  if (page->mode & 8U) {
    if (page->mode & 4U) {
      TIFFError((char const   *)"computeOutputPixelOffsets", (char const   *)"Output margins cannot be specified with rows and columns");
    }
    owidth = (iwidth + (page->cols - 1U)) / page->cols;
    olength = (ilength + (page->rows - 1U)) / page->rows;
  } else
  if (page->mode & 2U) {
    owidth = (uint32 )(pwidth * page->hres - (double )(hmargin * 2U));
    olength = (uint32 )(plength * page->vres - (double )(vmargin * 2U));
  } else {
    owidth = (uint32 )((double )iwidth - (double )(hmargin * 2U) * page->hres);
    olength = (uint32 )((double )ilength - (double )(vmargin * 2U) * page->vres);
  }
  if (owidth > iwidth) {
    owidth = iwidth;
  }
  if (olength > ilength) {
    olength = ilength;
  }
  if (page->orient == 1U) {
    goto case_1;
  }
  if (page->orient == 0U) {
    goto case_1;
  }
  if (page->orient == 2U) {
    goto case_2___0;
  }
  goto switch_default___0;
  case_1: 
  ocols = (iwidth + (owidth - 1U)) / owidth;
  orows = (ilength + (olength - 1U)) / olength;
  goto switch_break___0;
  case_2___0: 
  ocols = (iwidth + (olength - 1U)) / olength;
  orows = (ilength + (owidth - 1U)) / owidth;
  x1 = olength;
  olength = owidth;
  owidth = x1;
  goto switch_break___0;
  switch_default___0: 
  x1 = (iwidth + (owidth - 1U)) / owidth;
  x2 = (ilength + (olength - 1U)) / olength;
  y1___0 = (iwidth + (olength - 1U)) / olength;
  y2 = (ilength + (owidth - 1U)) / owidth;
  if (x1 * x2 < y1___0 * y2) {
    ocols = x1;
    orows = x2;
  } else {
    ocols = y1___0;
    orows = y2;
    x1 = olength;
    olength = owidth;
    owidth = x1;
  }
  switch_break___0: ;
  if (ocols < 1U) {
    ocols = (uint32 )1;
  }
  if (orows < 1U) {
    orows = (uint32 )1;
  }
  if (page->rows < 1U) {
    page->rows = orows;
  }
  if (page->cols < 1U) {
    page->cols = ocols;
  }
  if (owidth * (uint32 )image->bps & 7U) {
    tmp = (owidth * (uint32 )image->bps >> 3) + 1U;
  } else {
    tmp = owidth * (uint32 )image->bps >> 3;
  }
  line_bytes = tmp * (uint32 )image->spp;
  if (page->rows * page->cols > 32U) {
    TIFFError((char const   *)"computeOutputPixelOffsets", (char const   *)"Rows and Columns exceed maximum sections\nIncrease resolution or reduce sections");
    return (-1);
  }
  k = (uint32 )0;
  i = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < orows)) {
      goto while_break;
    }
    y1___0 = olength * i;
    y2 = olength * (i + 1U) - 1U;
    if (y2 >= ilength) {
      y2 = ilength - 1U;
    }
    j = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (j < ocols)) {
        goto while_break___0;
      }
      x1 = owidth * j;
      x2 = owidth * (j + 1U) - 1U;
      if (x2 >= iwidth) {
        x2 = iwidth - 1U;
      }
      (sections + k)->x1 = x1;
      (sections + k)->x2 = x2;
      (sections + k)->y1 = y1___0;
      (sections + k)->y2 = y2;
      (sections + k)->buffsize = line_bytes * olength;
      (sections + k)->position = (int )(k + 1U);
      (sections + k)->total = (int )(orows * ocols);
      j ++;
      k ++;
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: 
    i ++;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static uint32 prev_readsize  =    (uint32 )0;
static int loadImage(TIFF *in , struct image_data *image , struct dump_opts *dump ,
                     unsigned char **read_ptr ) 
{ 
  uint32 i ;
  float xres ;
  float yres ;
  uint16 nstrips ;
  uint16 ntiles ;
  uint16 planar ;
  uint16 bps ;
  uint16 spp ;
  uint16 res_unit ;
  uint16 orientation ;
  uint16 input_compression ;
  uint16 input_photometric ;
  uint16 subsampling_horiz ;
  uint16 subsampling_vert ;
  uint32 width ;
  uint32 length ;
  uint32 stsize ;
  uint32 tlsize ;
  uint32 buffsize ;
  uint32 scanlinesize ;
  uint32 tw ;
  uint32 tl ;
  uint32 tile_rowsize ;
  unsigned char *read_buff ;
  unsigned char *new_buff ;
  int readunit ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  uint32 tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  uint32 tmp___9 ;
  int tmp___10 ;
  void *tmp___11 ;
  void *tmp___12 ;
  void *tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;

  {
  xres = (float )0.0;
  yres = (float )0.0;
  nstrips = (uint16 )0;
  ntiles = (uint16 )0;
  planar = (uint16 )0;
  bps = (uint16 )0;
  spp = (uint16 )0;
  res_unit = (uint16 )0;
  orientation = (uint16 )0;
  input_compression = (uint16 )0;
  input_photometric = (uint16 )0;
  width = (uint32 )0;
  length = (uint32 )0;
  stsize = (uint32 )0;
  tlsize = (uint32 )0;
  buffsize = (uint32 )0;
  scanlinesize = (uint32 )0;
  tw = (uint32 )0;
  tl = (uint32 )0;
  tile_rowsize = (uint32 )0;
  read_buff = (unsigned char *)((void *)0);
  new_buff = (unsigned char *)((void *)0);
  readunit = 0;
  TIFFGetFieldDefaulted(in, (uint32 )258, & bps);
  TIFFGetFieldDefaulted(in, (uint32 )277, & spp);
  TIFFGetFieldDefaulted(in, (uint32 )284, & planar);
  TIFFGetFieldDefaulted(in, (uint32 )274, & orientation);
  tmp = TIFFGetFieldDefaulted(in, (uint32 )262, & input_photometric);
  if (! tmp) {
    TIFFError((char const   *)"loadImage", (char const   *)"Image lacks Photometric interpreation tag");
  }
  tmp___0 = TIFFGetField(in, (uint32 )256, & width);
  if (! tmp___0) {
    TIFFError((char const   *)"loadimage", (char const   *)"Image lacks image width tag");
  }
  tmp___1 = TIFFGetField(in, (uint32 )257, & length);
  if (! tmp___1) {
    TIFFError((char const   *)"loadimage", (char const   *)"Image lacks image length tag");
  }
  TIFFGetFieldDefaulted(in, (uint32 )282, & xres);
  TIFFGetFieldDefaulted(in, (uint32 )283, & yres);
  tmp___2 = TIFFGetFieldDefaulted(in, (uint32 )296, & res_unit);
  if (! tmp___2) {
    res_unit = (uint16 )2;
  }
  tmp___3 = TIFFGetField(in, (uint32 )259, & input_compression);
  if (! tmp___3) {
    input_compression = (uint16 )1;
  }
  tmp___4 = TIFFScanlineSize(in);
  scanlinesize = (uint32 )tmp___4;
  image->bps = bps;
  image->spp = spp;
  image->planar = planar;
  image->width = width;
  image->length = length;
  image->xres = xres;
  image->yres = yres;
  image->res_unit = res_unit;
  image->compression = input_compression;
  image->photometric = input_photometric;
  image->orientation = orientation;
  if ((int )orientation == 1) {
    goto case_1;
  }
  if ((int )orientation == 0) {
    goto case_1;
  }
  if ((int )orientation == 2) {
    goto case_2;
  }
  if ((int )orientation == 3) {
    goto case_3;
  }
  if ((int )orientation == 4) {
    goto case_4;
  }
  if ((int )orientation == 5) {
    goto case_5;
  }
  if ((int )orientation == 6) {
    goto case_6;
  }
  if ((int )orientation == 7) {
    goto case_7;
  }
  if ((int )orientation == 8) {
    goto case_8;
  }
  goto switch_default;
  case_1: 
  image->adjustments = (uint16 )0;
  goto switch_break;
  case_2: 
  image->adjustments = (uint16 )1;
  goto switch_break;
  case_3: 
  image->adjustments = (uint16 )16;
  goto switch_break;
  case_4: 
  image->adjustments = (uint16 )2;
  goto switch_break;
  case_5: 
  image->adjustments = (uint16 )10;
  goto switch_break;
  case_6: 
  image->adjustments = (uint16 )8;
  goto switch_break;
  case_7: 
  image->adjustments = (uint16 )34;
  goto switch_break;
  case_8: 
  image->adjustments = (uint16 )32;
  goto switch_break;
  switch_default: 
  image->adjustments = (uint16 )0;
  image->orientation = (uint16 )1;
  switch_break: ;
  if ((int )bps == 0) {
    TIFFError((char const   *)"loadImage", (char const   *)"Invalid samples per pixel (%d) or bits per sample (%d)",
              (int )spp, (int )bps);
    return (-1);
  } else
  if ((int )spp == 0) {
    TIFFError((char const   *)"loadImage", (char const   *)"Invalid samples per pixel (%d) or bits per sample (%d)",
              (int )spp, (int )bps);
    return (-1);
  }
  tmp___10 = TIFFIsTiled(in);
  if (tmp___10) {
    readunit = 2;
    tmp___5 = TIFFTileSize(in);
    tlsize = (uint32 )tmp___5;
    tmp___6 = TIFFNumberOfTiles(in);
    ntiles = (uint16 )tmp___6;
    TIFFGetField(in, (uint32 )322, & tw);
    TIFFGetField(in, (uint32 )323, & tl);
    tmp___7 = TIFFTileRowSize(in);
    tile_rowsize = (uint32 )tmp___7;
    buffsize = tlsize * (uint32 )ntiles;
    if (buffsize < ((uint32 )ntiles * tl) * tile_rowsize) {
      buffsize = ((uint32 )ntiles * tl) * tile_rowsize;
    }
    if ((unsigned long )dump->infile != (unsigned long )((void *)0)) {
      dump_info(dump->infile, dump->format, "", "Tilesize: %u, Number of Tiles: %u, Tile row size: %u",
                tlsize, (int )ntiles, tile_rowsize);
    }
  } else {
    readunit = 1;
    TIFFGetFieldDefaulted(in, (uint32 )278, & rowsperstrip);
    tmp___8 = TIFFStripSize(in);
    stsize = (uint32 )tmp___8;
    tmp___9 = TIFFNumberOfStrips(in);
    nstrips = (uint16 )tmp___9;
    buffsize = stsize * (uint32 )nstrips;
    if (buffsize < (((length * width) * (uint32 )spp) * (uint32 )bps + 7U) / 8U) {
      buffsize = (((length * width) * (uint32 )spp) * (uint32 )bps + 7U) / 8U;
    }
    if ((unsigned long )dump->infile != (unsigned long )((void *)0)) {
      dump_info(dump->infile, dump->format, "", "Stripsize: %u, Number of Strips: %u, Rows per Strip: %u, Scanline size: %u",
                stsize, (int )nstrips, rowsperstrip, scanlinesize);
    }
  }
  if ((int )input_compression == 7) {
    jpegcolormode = 0x0001;
    TIFFSetField(in, (uint32 )65538, 0x0001);
  } else
  if ((int )input_photometric == 6) {
    TIFFGetFieldDefaulted(in, (uint32 )530, & subsampling_horiz, & subsampling_vert);
    if ((int )subsampling_horiz != 1) {
      TIFFError((char const   *)"loadImage", (char const   *)"Can\'t copy/convert subsampled image with subsampling %d horiz %d vert",
                (int )subsampling_horiz, (int )subsampling_vert);
      return (-1);
    } else
    if ((int )subsampling_vert != 1) {
      TIFFError((char const   *)"loadImage", (char const   *)"Can\'t copy/convert subsampled image with subsampling %d horiz %d vert",
                (int )subsampling_horiz, (int )subsampling_vert);
      return (-1);
    }
  }
  read_buff = *read_ptr;
  if (! read_buff) {
    tmp___11 = _TIFFmalloc((tmsize_t )(buffsize + 3U));
    read_buff = (unsigned char *)tmp___11;
  } else
  if (prev_readsize < buffsize) {
    tmp___12 = _TIFFrealloc((void *)read_buff, (tmsize_t )(buffsize + 3U));
    new_buff = (unsigned char *)tmp___12;
    if (! new_buff) {
      free((void *)read_buff);
      tmp___13 = _TIFFmalloc((tmsize_t )(buffsize + 3U));
      read_buff = (unsigned char *)tmp___13;
    } else {
      read_buff = new_buff;
    }
  }
  if (! read_buff) {
    TIFFError((char const   *)"loadImage", (char const   *)"Unable to allocate/reallocate read buffer");
    return (-1);
  }
  *(read_buff + buffsize) = (unsigned char)0;
  *(read_buff + (buffsize + 1U)) = (unsigned char)0;
  *(read_buff + (buffsize + 2U)) = (unsigned char)0;
  prev_readsize = buffsize;
  *read_ptr = read_buff;
  if (readunit == 1) {
    goto case_1___0;
  }
  if (readunit == 2) {
    goto case_2___0;
  }
  goto switch_default___0;
  case_1___0: 
  if ((int )planar == 1) {
    tmp___14 = readContigStripsIntoBuffer(in, read_buff);
    if (! tmp___14) {
      TIFFError((char const   *)"loadImage", (char const   *)"Unable to read contiguous strips into buffer");
      return (-1);
    }
  } else {
    tmp___15 = readSeparateStripsIntoBuffer(in, read_buff, length, width, spp, dump);
    if (! tmp___15) {
      TIFFError((char const   *)"loadImage", (char const   *)"Unable to read separate strips into buffer");
      return (-1);
    }
  }
  goto switch_break___0;
  case_2___0: 
  if ((int )planar == 1) {
    tmp___16 = readContigTilesIntoBuffer(in, read_buff, length, width, tw, tl, spp,
                                         bps);
    if (! tmp___16) {
      TIFFError((char const   *)"loadImage", (char const   *)"Unable to read contiguous tiles into buffer");
      return (-1);
    }
  } else {
    tmp___17 = readSeparateTilesIntoBuffer(in, read_buff, length, width, tw, tl, spp,
                                           bps);
    if (! tmp___17) {
      TIFFError((char const   *)"loadImage", (char const   *)"Unable to read separate tiles into buffer");
      return (-1);
    }
  }
  goto switch_break___0;
  switch_default___0: 
  TIFFError((char const   *)"loadImage", (char const   *)"Unsupported image file format");
  return (-1);
  goto switch_break___0;
  switch_break___0: ;
  if ((unsigned long )dump->infile != (unsigned long )((void *)0)) {
    if (dump->level == 2) {
      dump_info(dump->infile, dump->format, "loadImage", "Image width %d, length %d, Raw image data, %4d bytes",
                width, length, buffsize);
      dump_info(dump->infile, dump->format, "", "Bits per sample %d, Samples per pixel %d",
                (int )bps, (int )spp);
      i = (uint32 )0;
      {
      while (1) {
        while_continue: /* CIL Label */ ;

        if (! (i < length)) {
          goto while_break;
        }
        dump_buffer(dump->infile, dump->format, (uint32 )1, scanlinesize, i, read_buff + i * scanlinesize);
        i ++;
      }
      while_break___0: /* CIL Label */ ;
      }
      while_break: ;
    }
  }
  return (0);
}
}
static int correct_orientation(struct image_data *image , unsigned char **work_buff_ptr ) 
{ 
  uint16 mirror ;
  uint16 rotation ;
  unsigned char *work_buff ;
  int tmp ;
  int tmp___0 ;

  {
  work_buff = *work_buff_ptr;
  if ((unsigned long )image == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"correct_orientatin", (char const   *)"Invalid image or buffer pointer");
    return (-1);
  } else
  if ((unsigned long )work_buff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"correct_orientatin", (char const   *)"Invalid image or buffer pointer");
    return (-1);
  }
  if ((int )image->adjustments & 1) {
    goto _L;
  } else
  if ((int )image->adjustments & 2) {
    _L: 
    mirror = (uint16 )((int )image->adjustments & 3);
    tmp = mirrorImage(image->spp, image->bps, mirror, image->width, image->length,
                      work_buff);
    if (tmp) {
      TIFFError((char const   *)"correct_orientation", (char const   *)"Unable to mirror image");
      return (-1);
    }
  }
  if ((int )image->adjustments & 56) {
    if ((int )image->adjustments & 8) {
      rotation = (uint16 )90;
    } else
    if ((int )image->adjustments & 16) {
      rotation = (uint16 )180;
    } else
    if ((int )image->adjustments & 32) {
      rotation = (uint16 )270;
    } else {
      TIFFError((char const   *)"correct_orientation", (char const   *)"Invalid rotation value: %d",
                (int )image->adjustments & 56);
      return (-1);
    }
    tmp___0 = rotateImage(rotation, image, & image->width, & image->length, work_buff_ptr);
    if (tmp___0) {
      TIFFError((char const   *)"correct_orientation", (char const   *)"Unable to rotate image");
      return (-1);
    }
    image->orientation = (uint16 )1;
  }
  return (0);
}
}
static int extractCompositeRegions(struct image_data *image , struct crop_mask *crop ,
                                   unsigned char *read_buff , unsigned char *crop_buff ) 
{ 
  int shift_width ;
  int bytes_per_sample ;
  int bytes_per_pixel ;
  uint32 i ;
  uint32 trailing_bits ;
  uint32 prev_trailing_bits ;
  uint32 row ;
  uint32 first_row ;
  uint32 last_row ;
  uint32 first_col ;
  uint32 last_col ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 src_offset ;
  uint32 dst_offset ;
  uint32 crop_width ;
  uint32 crop_length ;
  uint32 img_width ;
  uint32 prev_length ;
  uint32 prev_width ;
  uint32 composite_width ;
  uint16 bps ;
  uint16 spp ;
  uint8 *src ;
  uint8 *dst ;
  tsample_t count ;
  tsample_t sample ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;

  {
  sample = (tsample_t )0;
  img_width = image->width;
  bps = image->bps;
  spp = image->spp;
  count = spp;
  bytes_per_sample = ((int )bps + 7) / 8;
  bytes_per_pixel = ((int )bps * (int )spp + 7) / 8;
  if ((int )bps % 8 == 0) {
    shift_width = 0;
  } else
  if (bytes_per_pixel < bytes_per_sample + 1) {
    shift_width = bytes_per_pixel;
  } else {
    shift_width = bytes_per_sample + 1;
  }
  src = read_buff;
  dst = crop_buff;
  prev_length = (uint32 )0;
  prev_width = prev_length;
  trailing_bits = (uint32 )0;
  prev_trailing_bits = trailing_bits;
  composite_width = crop->combined_width;
  crop->combined_width = (uint32 )0;
  crop->combined_length = (uint32 )0;
  i = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < (uint32 )crop->selections)) {
      goto while_break;
    }
    first_row = crop->regionlist[i].y1;
    last_row = crop->regionlist[i].y2;
    first_col = crop->regionlist[i].x1;
    last_col = crop->regionlist[i].x2;
    crop_width = (last_col - first_col) + 1U;
    crop_length = (last_row - first_row) + 1U;
    crop->regionlist[i].width = crop_width;
    crop->regionlist[i].length = crop_length;
    crop->regionlist[i].buffptr = crop_buff;
    src_rowsize = ((img_width * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
    dst_rowsize = ((crop_width * (uint32 )bps) * (uint32 )count + 7U) / 8U;
    if ((int )crop->edge_ref == 4) {
      goto case_4___0;
    }
    if ((int )crop->edge_ref == 2) {
      goto case_4___0;
    }
    goto switch_default;
    switch_default: 
    if (i > 0U) {
      if (crop_width != crop->regionlist[i - 1U].width) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Only equal width regions can be combined for -E top or bottom");
        return (1);
      }
    }
    crop->combined_width = crop_width;
    crop->combined_length += crop_length;
    row = first_row;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (row <= last_row)) {
        goto while_break___0;
      }
      src_offset = row * src_rowsize;
      dst_offset = (row - first_row) * dst_rowsize;
      src = read_buff + src_offset;
      dst = (crop_buff + dst_offset) + prev_length * dst_rowsize;
      if (shift_width == 0) {
        goto case_0;
      }
      if (shift_width == 1) {
        goto case_1;
      }
      if (shift_width == 2) {
        goto case_2;
      }
      if (shift_width == 5) {
        goto case_5;
      }
      if (shift_width == 4) {
        goto case_5;
      }
      if (shift_width == 3) {
        goto case_5;
      }
      goto switch_default___0;
      case_0: 
      tmp = extractContigSamplesBytes(src, dst, img_width, sample, spp, bps, count,
                                      first_col, last_col + 1U);
      if (tmp) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
      goto switch_break___0;
      case_1: 
      if ((int )bps == 1) {
        tmp___0 = extractContigSamplesShifted8bits(src, dst, img_width, sample, spp,
                                                   bps, count, first_col, last_col + 1U,
                                                   (int )prev_trailing_bits);
        if (tmp___0) {
          TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                    row);
          return (1);
        }
        goto switch_break___0;
      } else {
        tmp___1 = extractContigSamplesShifted16bits(src, dst, img_width, sample, spp,
                                                    bps, count, first_col, last_col + 1U,
                                                    (int )prev_trailing_bits);
        if (tmp___1) {
          TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                    row);
          return (1);
        }
      }
      goto switch_break___0;
      case_2: 
      tmp___2 = extractContigSamplesShifted24bits(src, dst, img_width, sample, spp,
                                                  bps, count, first_col, last_col + 1U,
                                                  (int )prev_trailing_bits);
      if (tmp___2) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
      goto switch_break___0;
      case_5: 
      tmp___3 = extractContigSamplesShifted32bits(src, dst, img_width, sample, spp,
                                                  bps, count, first_col, last_col + 1U,
                                                  (int )prev_trailing_bits);
      if (tmp___3) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
      goto switch_break___0;
      switch_default___0: 
      TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unsupported bit depth %d",
                (int )bps);
      return (1);
      switch_break___0: 
      row ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    prev_length += crop_length;
    goto switch_break;
    case_4___0: 
    if (i > 0U) {
      if (crop_length != crop->regionlist[i - 1U].length) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Only equal length regions can be combined for -E left or right");
        return (1);
      }
    }
    crop->combined_width += crop_width;
    crop->combined_length = crop_length;
    dst_rowsize = ((composite_width * (uint32 )bps) * (uint32 )count + 7U) / 8U;
    trailing_bits = ((crop_width * (uint32 )bps) * (uint32 )count) % 8U;
    row = first_row;
    {
    while (1) {
      while_continue___1: /* CIL Label */ ;

      if (! (row <= last_row)) {
        goto while_break___1;
      }
      src_offset = row * src_rowsize;
      dst_offset = (row - first_row) * dst_rowsize;
      src = read_buff + src_offset;
      dst = (crop_buff + dst_offset) + prev_width;
      if (shift_width == 0) {
        goto case_0___0;
      }
      if (shift_width == 1) {
        goto case_1___0;
      }
      if (shift_width == 2) {
        goto case_2___1;
      }
      if (shift_width == 5) {
        goto case_5___0;
      }
      if (shift_width == 4) {
        goto case_5___0;
      }
      if (shift_width == 3) {
        goto case_5___0;
      }
      goto switch_default___1;
      case_0___0: 
      tmp___4 = extractContigSamplesBytes(src, dst, img_width, sample, spp, bps, count,
                                          first_col, last_col + 1U);
      if (tmp___4) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
      goto switch_break___1;
      case_1___0: 
      if ((int )bps == 1) {
        tmp___5 = extractContigSamplesShifted8bits(src, dst, img_width, sample, spp,
                                                   bps, count, first_col, last_col + 1U,
                                                   (int )prev_trailing_bits);
        if (tmp___5) {
          TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                    row);
          return (1);
        }
        goto switch_break___1;
      } else {
        tmp___6 = extractContigSamplesShifted16bits(src, dst, img_width, sample, spp,
                                                    bps, count, first_col, last_col + 1U,
                                                    (int )prev_trailing_bits);
        if (tmp___6) {
          TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                    row);
          return (1);
        }
      }
      goto switch_break___1;
      case_2___1: 
      tmp___7 = extractContigSamplesShifted24bits(src, dst, img_width, sample, spp,
                                                  bps, count, first_col, last_col + 1U,
                                                  (int )prev_trailing_bits);
      if (tmp___7) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
      goto switch_break___1;
      case_5___0: 
      tmp___8 = extractContigSamplesShifted32bits(src, dst, img_width, sample, spp,
                                                  bps, count, first_col, last_col + 1U,
                                                  (int )prev_trailing_bits);
      if (tmp___8) {
        TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
      goto switch_break___1;
      switch_default___1: 
      TIFFError((char const   *)"extractCompositeRegions", (char const   *)"Unsupported bit depth %d",
                (int )bps);
      return (1);
      switch_break___1: 
      row ++;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___1: 
    prev_width += ((crop_width * (uint32 )bps) * (uint32 )count) / 8U;
    prev_trailing_bits += trailing_bits;
    if (prev_trailing_bits > 7U) {
      prev_trailing_bits -= 8U;
    }
    goto switch_break;
    switch_break: 
    i ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  if (crop->combined_width != composite_width) {
    TIFFError((char const   *)"combineSeparateRegions", (char const   *)"Combined width does not match composite width");
  }
  return (0);
}
}
static int extractSeparateRegion(struct image_data *image , struct crop_mask *crop ,
                                 unsigned char *read_buff , unsigned char *crop_buff ,
                                 int region ) 
{ 
  int shift_width ;
  int prev_trailing_bits ;
  uint32 bytes_per_sample ;
  uint32 bytes_per_pixel ;
  uint32 src_rowsize ;
  uint32 dst_rowsize ;
  uint32 row ;
  uint32 first_row ;
  uint32 last_row ;
  uint32 first_col ;
  uint32 last_col ;
  uint32 src_offset ;
  uint32 dst_offset ;
  uint32 crop_width ;
  uint32 crop_length ;
  uint32 img_width ;
  uint16 bps ;
  uint16 spp ;
  uint8 *src ;
  uint8 *dst ;
  tsample_t count ;
  tsample_t sample ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;

  {
  prev_trailing_bits = 0;
  sample = (tsample_t )0;
  img_width = image->width;
  bps = image->bps;
  spp = image->spp;
  count = spp;
  bytes_per_sample = (uint32 )(((int )bps + 7) / 8);
  bytes_per_pixel = (uint32 )(((int )bps * (int )spp + 7) / 8);
  if ((int )bps % 8 == 0) {
    shift_width = 0;
  } else
  if (bytes_per_pixel < bytes_per_sample + 1U) {
    shift_width = (int )bytes_per_pixel;
  } else {
    shift_width = (int )(bytes_per_sample + 1U);
  }
  first_row = crop->regionlist[region].y1;
  last_row = crop->regionlist[region].y2;
  first_col = crop->regionlist[region].x1;
  last_col = crop->regionlist[region].x2;
  crop_width = (last_col - first_col) + 1U;
  crop_length = (last_row - first_row) + 1U;
  crop->regionlist[region].width = crop_width;
  crop->regionlist[region].length = crop_length;
  crop->regionlist[region].buffptr = crop_buff;
  src = read_buff;
  dst = crop_buff;
  src_rowsize = ((img_width * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  dst_rowsize = ((crop_width * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  row = first_row;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row <= last_row)) {
      goto while_break;
    }
    src_offset = row * src_rowsize;
    dst_offset = (row - first_row) * dst_rowsize;
    src = read_buff + src_offset;
    dst = crop_buff + dst_offset;
    if (shift_width == 0) {
      goto case_0;
    }
    if (shift_width == 1) {
      goto case_1;
    }
    if (shift_width == 2) {
      goto case_2;
    }
    if (shift_width == 5) {
      goto case_5;
    }
    if (shift_width == 4) {
      goto case_5;
    }
    if (shift_width == 3) {
      goto case_5;
    }
    goto switch_default;
    case_0: 
    tmp = extractContigSamplesBytes(src, dst, img_width, sample, spp, bps, count,
                                    first_col, last_col + 1U);
    if (tmp) {
      TIFFError((char const   *)"extractSeparateRegion", (char const   *)"Unable to extract row %d",
                row);
      return (1);
    }
    goto switch_break;
    case_1: 
    if ((int )bps == 1) {
      tmp___0 = extractContigSamplesShifted8bits(src, dst, img_width, sample, spp,
                                                 bps, count, first_col, last_col + 1U,
                                                 prev_trailing_bits);
      if (tmp___0) {
        TIFFError((char const   *)"extractSeparateRegion", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
      goto switch_break;
    } else {
      tmp___1 = extractContigSamplesShifted16bits(src, dst, img_width, sample, spp,
                                                  bps, count, first_col, last_col + 1U,
                                                  prev_trailing_bits);
      if (tmp___1) {
        TIFFError((char const   *)"extractSeparateRegion", (char const   *)"Unable to extract row %d",
                  row);
        return (1);
      }
    }
    goto switch_break;
    case_2: 
    tmp___2 = extractContigSamplesShifted24bits(src, dst, img_width, sample, spp,
                                                bps, count, first_col, last_col + 1U,
                                                prev_trailing_bits);
    if (tmp___2) {
      TIFFError((char const   *)"extractSeparateRegion", (char const   *)"Unable to extract row %d",
                row);
      return (1);
    }
    goto switch_break;
    case_5: 
    tmp___3 = extractContigSamplesShifted32bits(src, dst, img_width, sample, spp,
                                                bps, count, first_col, last_col + 1U,
                                                prev_trailing_bits);
    if (tmp___3) {
      TIFFError((char const   *)"extractSeparateRegion", (char const   *)"Unable to extract row %d",
                row);
      return (1);
    }
    goto switch_break;
    switch_default: 
    TIFFError((char const   *)"extractSeparateRegion", (char const   *)"Unsupported bit depth %d",
              (int )bps);
    return (1);
    switch_break: 
    row ++;
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int extractImageSection(struct image_data *image , struct pageseg *section ,
                               unsigned char *src_buff , unsigned char *sect_buff ) 
{ 
  unsigned char bytebuff1 ;
  unsigned char bytebuff2 ;
  uint32 img_width ;
  uint32 img_rowsize ;
  uint32 j ;
  uint32 shift1 ;
  uint32 shift2 ;
  uint32 trailing_bits ;
  uint32 row ;
  uint32 first_row ;
  uint32 last_row ;
  uint32 first_col ;
  uint32 last_col ;
  uint32 src_offset ;
  uint32 dst_offset ;
  uint32 row_offset ;
  uint32 col_offset ;
  uint32 offset1 ;
  uint32 offset2 ;
  uint32 full_bytes ;
  uint32 sect_width ;
  uint16 bps ;
  uint16 spp ;

  {
  img_width = image->width;
  bps = image->bps;
  spp = image->spp;
  src_offset = (uint32 )0;
  dst_offset = (uint32 )0;
  first_row = section->y1;
  last_row = section->y2;
  first_col = section->x1;
  last_col = section->x2;
  sect_width = (last_col - first_col) + 1U;
  img_rowsize = ((img_width * (uint32 )bps + 7U) / 8U) * (uint32 )spp;
  full_bytes = ((sect_width * (uint32 )spp) * (uint32 )bps) / 8U;
  trailing_bits = (sect_width * (uint32 )bps) % 8U;
  if ((int )bps % 8 == 0) {
    col_offset = ((first_col * (uint32 )spp) * (uint32 )bps) / 8U;
    row = first_row;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (row <= last_row)) {
        goto while_break;
      }
      row_offset = row * img_rowsize;
      src_offset = row_offset + col_offset;
      _TIFFmemcpy((void *)(sect_buff + dst_offset), (void const   *)(src_buff + src_offset),
                  (tmsize_t )full_bytes);
      dst_offset += full_bytes;
      row ++;
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break: ;
  } else {
    shift1 = (unsigned int )spp * ((first_col * (uint32 )bps) % 8U);
    shift2 = (unsigned int )spp * ((last_col * (uint32 )bps) % 8U);
    row = first_row;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (row <= last_row)) {
        goto while_break___0;
      }
      row_offset = row * img_rowsize;
      offset1 = row_offset + (first_col * (uint32 )bps) / 8U;
      offset2 = row_offset + (last_col * (uint32 )bps) / 8U;
      bytebuff2 = (unsigned char)0;
      bytebuff1 = bytebuff2;
      if (shift1 == 0U) {
        _TIFFmemcpy((void *)(sect_buff + dst_offset), (void const   *)(src_buff + offset1),
                    (tmsize_t )full_bytes);
        dst_offset += full_bytes;
        if (trailing_bits != 0U) {
          bytebuff2 = (unsigned char )((int )*(src_buff + offset2) & (255 << (7U - shift2)));
          *(sect_buff + dst_offset) = bytebuff2;
          dst_offset ++;
        }
      } else {
        j = (uint32 )0;
        {
        while (1) {
          while_continue___1: /* CIL Label */ ;

          if (! (j <= full_bytes)) {
            goto while_break___1;
          }
          bytebuff1 = (unsigned char )((int )*(src_buff + (offset1 + j)) & (255 >> shift1));
          bytebuff2 = (unsigned char )((int )*(src_buff + ((offset1 + j) + 1U)) & (255 << (7U - shift1)));
          *(sect_buff + (dst_offset + j)) = (unsigned char )(((int )bytebuff1 << shift1) | ((int )bytebuff2 >> (8U - shift1)));
          j ++;
        }
        while_break___4: /* CIL Label */ ;
        }
        while_break___1: 
        dst_offset += full_bytes;
        if (trailing_bits != 0U) {
          if (shift2 > shift1) {
            bytebuff1 = (unsigned char )((int )*(src_buff + (offset1 + full_bytes)) & (255 << (7U - shift2)));
            bytebuff2 = (unsigned char )((int )bytebuff1 & (255 << shift1));
            *(sect_buff + dst_offset) = bytebuff2;
          } else
          if (shift2 < shift1) {
            bytebuff2 = (unsigned char )(255 << ((shift1 - shift2) - 1U));
            *(sect_buff + dst_offset) = (unsigned char )((int )*(sect_buff + dst_offset) & (int )bytebuff2);
          }
        }
        dst_offset ++;
      }
      row ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: ;
  }
  return (0);
}
}
static int writeSelections(TIFF *in , TIFF **out , struct crop_mask *crop , struct image_data *image ,
                           struct dump_opts *dump , struct buffinfo *seg_buffs , char *mp ,
                           char *filename , unsigned int *page , unsigned int total_pages ) 
{ 
  int i ;
  int page_count ;
  int autoindex ;
  unsigned char *crop_buff ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;

  {
  autoindex = 0;
  crop_buff = (unsigned char *)((void *)0);
  if ((int )crop->exp_mode == 0) {
    goto case_0;
  }
  if ((int )crop->exp_mode == 1) {
    goto case_1;
  }
  if ((int )crop->exp_mode == 2) {
    goto case_2;
  }
  if ((int )crop->exp_mode == 3) {
    goto case_3;
  }
  if ((int )crop->exp_mode == 4) {
    goto case_4;
  }
  goto switch_default;
  case_0: 
  autoindex = 0;
  crop_buff = (seg_buffs + 0)->buffer;
  tmp = update_output_file(out, mp, autoindex, filename, page);
  if (tmp) {
    return (1);
  }
  page_count = (int )total_pages;
  tmp___0 = writeCroppedImage(in, *out, image, dump, crop->combined_width, crop->combined_length,
                              crop_buff, (int )*page, (int )total_pages);
  if (tmp___0) {
    TIFFError((char const   *)"writeRegions", (char const   *)"Unable to write new image");
    return (-1);
  }
  goto switch_break;
  case_1: 
  autoindex = 0;
  tmp___1 = update_output_file(out, mp, autoindex, filename, page);
  if (tmp___1) {
    return (1);
  }
  page_count = (int )((unsigned int )crop->selections * total_pages);
  i = 0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < (int )crop->selections)) {
      goto while_break;
    }
    crop_buff = (seg_buffs + i)->buffer;
    tmp___2 = writeCroppedImage(in, *out, image, dump, crop->regionlist[i].width,
                                crop->regionlist[i].length, crop_buff, (int )*page,
                                page_count);
    if (tmp___2) {
      TIFFError((char const   *)"writeRegions", (char const   *)"Unable to write new image");
      return (-1);
    }
    i ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  goto switch_break;
  case_2: 
  autoindex = 1;
  tmp___3 = update_output_file(out, mp, autoindex, filename, page);
  if (tmp___3) {
    return (1);
  }
  crop_buff = (seg_buffs + 0)->buffer;
  tmp___4 = writeCroppedImage(in, *out, image, dump, crop->combined_width, crop->combined_length,
                              crop_buff, (int )*page, (int )total_pages);
  if (tmp___4) {
    TIFFError((char const   *)"writeRegions", (char const   *)"Unable to write new image");
    return (-1);
  }
  goto switch_break;
  case_3: 
  autoindex = 1;
  page_count = (int )crop->selections;
  tmp___5 = update_output_file(out, mp, autoindex, filename, page);
  if (tmp___5) {
    return (1);
  }
  i = 0;
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;

    if (! (i < (int )crop->selections)) {
      goto while_break___0;
    }
    crop_buff = (seg_buffs + i)->buffer;
    tmp___6 = writeCroppedImage(in, *out, image, dump, crop->regionlist[i].width,
                                crop->regionlist[i].length, crop_buff, (int )*page,
                                page_count);
    if (tmp___6) {
      TIFFError((char const   *)"writeRegions", (char const   *)"Unable to write new image");
      return (-1);
    }
    i ++;
  }
  while_break___3: /* CIL Label */ ;
  }
  while_break___0: ;
  goto switch_break;
  case_4: 
  autoindex = 1;
  page_count = 1;
  i = 0;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (i < (int )crop->selections)) {
      goto while_break___1;
    }
    tmp___7 = update_output_file(out, mp, autoindex, filename, page);
    if (tmp___7) {
      return (1);
    }
    crop_buff = (seg_buffs + i)->buffer;
    tmp___8 = writeCroppedImage(in, *out, image, dump, crop->regionlist[i].width,
                                crop->regionlist[i].length, crop_buff, (int )*page,
                                page_count);
    if (tmp___8) {
      TIFFError((char const   *)"writeRegions", (char const   *)"Unable to write new image");
      return (-1);
    }
    i ++;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  goto switch_break;
  switch_default: 
  return (1);
  switch_break: ;
  return (0);
}
}
static int writeImageSections(TIFF *in , TIFF *out , struct image_data *image , struct pagedef *page ,
                              struct pageseg *sections , struct dump_opts *dump ,
                              unsigned char *src_buff , unsigned char **sect_buff_ptr ) 
{ 
  double hres ;
  double vres ;
  uint32 i ;
  uint32 k ;
  uint32 width ;
  uint32 length ;
  uint32 sectsize ;
  unsigned char *sect_buff ;
  double tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  sect_buff = *sect_buff_ptr;
  hres = page->hres;
  vres = page->vres;
  k = page->cols * page->rows;
  if (k < 1U) {
    TIFFError((char const   *)"writeImageSections", (char const   *)"%d Rows and Columns exceed maximum sections\nIncrease resolution or reduce sections",
              k);
    return (-1);
  } else
  if (k > 32U) {
    TIFFError((char const   *)"writeImageSections", (char const   *)"%d Rows and Columns exceed maximum sections\nIncrease resolution or reduce sections",
              k);
    return (-1);
  }
  i = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (i < k)) {
      goto while_break;
    }
    width = ((sections + i)->x2 - (sections + i)->x1) + 1U;
    length = ((sections + i)->y2 - (sections + i)->y1) + 1U;
    tmp = ceil((double )(width * (uint32 )image->bps + 7U) / (double )8);
    sectsize = ((uint32 )tmp * (uint32 )image->spp) * length;
    tmp___0 = createImageSection(sectsize, sect_buff_ptr);
    if (tmp___0) {
      TIFFError((char const   *)"writeImageSections", (char const   *)"Unable to allocate section buffer");
      exit(-1);
    }
    sect_buff = *sect_buff_ptr;
    tmp___1 = extractImageSection(image, sections + i, src_buff, sect_buff);
    if (tmp___1) {
      TIFFError((char const   *)"writeImageSections", (char const   *)"Unable to extract image sections");
      exit(-1);
    }
    tmp___2 = writeSingleSection(in, out, image, dump, width, length, hres, vres,
                                 sect_buff);
    if (tmp___2) {
      TIFFError((char const   *)"writeImageSections", (char const   *)"Unable to write image section");
      exit(-1);
    }
    i ++;
  }
  while_break___0: /* CIL Label */ ;
  }
  while_break: ;
  return (0);
}
}
static int writeSingleSection(TIFF *in , TIFF *out , struct image_data *image , struct dump_opts *dump ,
                              uint32 width , uint32 length , double hres , double vres ,
                              unsigned char *sect_buff ) 
{ 
  uint16 bps ;
  uint16 spp ;
  uint16 input_compression ;
  uint16 input_photometric ;
  uint16 input_planar ;
  struct cpTag *p ;
  int tmp ;
  char *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  uint32 len32 ;
  void **data ;
  int tmp___6 ;
  uint16 ninks ;
  char const   *inknames ;
  int inknameslen ;
  size_t tmp___7 ;
  char const   *cp ;
  char *tmp___8 ;
  size_t tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  unsigned short pg0 ;
  unsigned short pg1 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;

  {
  input_compression = image->compression;
  input_photometric = image->photometric;
  spp = image->spp;
  bps = image->bps;
  TIFFSetField(out, (uint32 )256, width);
  TIFFSetField(out, (uint32 )257, length);
  TIFFSetField(out, (uint32 )258, (int )bps);
  TIFFSetField(out, (uint32 )277, (int )spp);
  if ((int )compression != 65535) {
    TIFFSetField(out, (uint32 )259, (int )compression);
  } else
  if ((int )input_compression == 6) {
    compression = (uint16 )7;
    jpegcolormode = 0x0000;
    TIFFSetField(out, (uint32 )259, 7);
  } else {
    tmp = TIFFGetField(in, (uint32 )259, & compression);
    if (tmp) {
      TIFFSetField(out, (uint32 )259, (int )compression);
    }
  }
  if ((int )compression == 7) {
    if ((int )input_photometric == 3) {
      goto _L;
    } else
    if ((int )input_photometric == 4) {
      _L: 
      if ((int )input_photometric == 3) {
        tmp___0 = "palette";
      } else {
        tmp___0 = "mask";
      }
      TIFFError((char const   *)"writeSingleSection", (char const   *)"JPEG compression cannot be used with %s image data",
                tmp___0);
      return (-1);
    }
    if ((int )input_photometric == 2) {
      if (jpegcolormode == 0x0001) {
        TIFFSetField(out, (uint32 )262, 6);
      } else {
        TIFFSetField(out, (uint32 )262, (int )input_photometric);
      }
    } else {
      TIFFSetField(out, (uint32 )262, (int )input_photometric);
    }
  } else
  if ((int )compression == 34676) {
    goto _L___0;
  } else
  if ((int )compression == 34677) {
    _L___0: 
    if ((int )spp == 1) {
      tmp___1 = 32844;
    } else {
      tmp___1 = 32845;
    }
    TIFFSetField(out, (uint32 )262, tmp___1);
  } else {
    TIFFSetField(out, (uint32 )262, (int )image->photometric);
  }
  if ((int )input_photometric == 32844) {
    goto _L___1;
  } else
  if ((int )input_photometric == 32845) {
    _L___1: 
    if ((int )compression != 34676) {
      if ((int )compression != 34677) {
        TIFFError((char const   *)"writeSingleSection", (char const   *)"LogL and LogLuv source data require SGI_LOG or SGI_LOG24 compression");
        return (-1);
      }
    }
  }
  if ((int )fillorder != 0) {
    TIFFSetField(out, (uint32 )266, (int )fillorder);
  } else {
    cpTag(in, out, (uint16 )266, (uint16 )1, (TIFFDataType )3);
  }
  TIFFSetField(out, (uint32 )274, (int )image->orientation);
  if (outtiled == -1) {
    outtiled = TIFFIsTiled(in);
  }
  if (outtiled) {
    if (tilewidth == 0U) {
      TIFFGetField(in, (uint32 )322, & tilewidth);
    }
    if (tilelength == 0U) {
      TIFFGetField(in, (uint32 )323, & tilelength);
    }
    if (tilewidth == 0U) {
      TIFFDefaultTileSize(out, & tilewidth, & tilelength);
    } else
    if (tilelength == 0U) {
      TIFFDefaultTileSize(out, & tilewidth, & tilelength);
    }
    TIFFDefaultTileSize(out, & tilewidth, & tilelength);
    TIFFSetField(out, (uint32 )322, tilewidth);
    TIFFSetField(out, (uint32 )323, tilelength);
  } else {
    if (rowsperstrip == 0U) {
      tmp___2 = TIFFGetField(in, (uint32 )278, & rowsperstrip);
      if (! tmp___2) {
        rowsperstrip = TIFFDefaultStripSize(out, rowsperstrip);
      }
      if ((int )compression != 7) {
        if (rowsperstrip > length) {
          rowsperstrip = length;
        }
      }
    } else
    if (rowsperstrip == 4294967295U) {
      rowsperstrip = length;
    }
    TIFFSetField(out, (uint32 )278, rowsperstrip);
  }
  TIFFGetFieldDefaulted(in, (uint32 )284, & input_planar);
  if ((int )config != 65535) {
    TIFFSetField(out, (uint32 )284, (int )config);
  } else {
    tmp___3 = TIFFGetField(in, (uint32 )284, & config);
    if (tmp___3) {
      TIFFSetField(out, (uint32 )284, (int )config);
    }
  }
  if ((int )spp <= 4) {
    cpTag(in, out, (uint16 )301, (uint16 )4, (TIFFDataType )3);
  }
  cpTag(in, out, (uint16 )320, (uint16 )4, (TIFFDataType )3);
  if ((int )compression == 7) {
    goto case_7;
  }
  if ((int )compression == 32946) {
    goto case_32946;
  }
  if ((int )compression == 8) {
    goto case_32946;
  }
  if ((int )compression == 5) {
    goto case_32946;
  }
  if ((int )compression == 4) {
    goto case_4;
  }
  if ((int )compression == 3) {
    goto case_4;
  }
  goto switch_break;
  case_7: 
  if ((int )bps % 8 == 0) {
    TIFFSetField(out, (uint32 )65537, quality);
    TIFFSetField(out, (uint32 )65538, 0x0001);
  } else
  if ((int )bps % 12 == 0) {
    TIFFSetField(out, (uint32 )65537, quality);
    TIFFSetField(out, (uint32 )65538, 0x0001);
  } else {
    TIFFError((char const   *)"writeSingleSection", (char const   *)"JPEG compression requires 8 or 12 bits per sample");
    return (-1);
  }
  goto switch_break;
  case_32946: 
  if ((int )predictor != 65535) {
    TIFFSetField(out, (uint32 )317, (int )predictor);
  } else {
    tmp___4 = TIFFGetField(in, (uint32 )317, & predictor);
    if (tmp___4) {
      TIFFSetField(out, (uint32 )317, (int )predictor);
    }
  }
  goto switch_break;
  case_4: 
  if ((int )compression == 3) {
    if (g3opts != 4294967295U) {
      TIFFSetField(out, (uint32 )292, g3opts);
    } else {
      tmp___5 = TIFFGetField(in, (uint32 )292, & g3opts);
      if (tmp___5) {
        TIFFSetField(out, (uint32 )292, g3opts);
      }
    }
  } else {
    cpTag(in, out, (uint16 )293, (uint16 )1, (TIFFDataType )4);
  }
  cpTag(in, out, (uint16 )326, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )327, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )328, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )34908, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )34910, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )34909, (uint16 )1, (TIFFDataType )2);
  goto switch_break;
  switch_break: 
  tmp___6 = TIFFGetField(in, (uint32 )34675, & len32, & data);
  if (tmp___6) {
    TIFFSetField(out, (uint32 )34675, len32, data);
  }
  tmp___11 = TIFFGetField(in, (uint32 )334, & ninks);
  if (tmp___11) {
    TIFFSetField(out, (uint32 )334, (int )ninks);
    tmp___10 = TIFFGetField(in, (uint32 )333, & inknames);
    if (tmp___10) {
      tmp___7 = strlen(inknames);
      inknameslen = (int )(tmp___7 + 1UL);
      cp = inknames;
      {
      while (1) {
        while_continue: /* CIL Label */ ;

        if (! ((int )ninks > 1)) {
          goto while_break;
        }
        tmp___8 = strchr(cp, '\000');
        cp = (char const   *)tmp___8;
        if (cp) {
          cp ++;
          tmp___9 = strlen(cp);
          inknameslen = (int )((size_t )inknameslen + (tmp___9 + 1UL));
        }
        ninks = (uint16 )((int )ninks - 1);
      }
      while_break___1: /* CIL Label */ ;
      }
      while_break: 
      TIFFSetField(out, (uint32 )333, inknameslen, inknames);
    }
  }
  tmp___13 = TIFFGetField(in, (uint32 )297, & pg0, & pg1);
  if (tmp___13) {
    if (pageNum < 0) {
      TIFFSetField(out, (uint32 )297, (int )pg0, (int )pg1);
    } else {
      tmp___12 = pageNum;
      pageNum ++;
      TIFFSetField(out, (uint32 )297, tmp___12, 0);
    }
  }
  p = tags;
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;

    if (! ((unsigned long )p < (unsigned long )(& tags[sizeof(tags) / sizeof(tags[0])]))) {
      goto while_break___0;
    }
    cpTag(in, out, p->tag, p->count, p->type);
    p ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break___0: 
  TIFFSetField(out, (uint32 )282, (double )((float )hres));
  TIFFSetField(out, (uint32 )283, (double )((float )vres));
  if (outtiled) {
    if ((int )config == 1) {
      writeBufferToContigTiles(out, sect_buff, length, width, spp, dump);
    } else {
      writeBufferToSeparateTiles(out, sect_buff, length, width, spp, dump);
    }
  } else
  if ((int )config == 1) {
    writeBufferToContigStrips(out, sect_buff, length);
  } else {
    writeBufferToSeparateStrips(out, sect_buff, length, width, spp, dump);
  }
  tmp___14 = TIFFWriteDirectory(out);
  if (! tmp___14) {
    TIFFClose(out);
    return (-1);
  }
  return (0);
}
}
static uint32 prev_sectsize  =    (uint32 )0;
static int createImageSection(uint32 sectsize , unsigned char **sect_buff_ptr ) 
{ 
  unsigned char *sect_buff ;
  unsigned char *new_buff ;
  void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;

  {
  sect_buff = (unsigned char *)((void *)0);
  new_buff = (unsigned char *)((void *)0);
  sect_buff = *sect_buff_ptr;
  if (! sect_buff) {
    tmp = _TIFFmalloc((tmsize_t )sectsize);
    sect_buff = (unsigned char *)tmp;
    *sect_buff_ptr = sect_buff;
    _TIFFmemset((void *)sect_buff, 0, (tmsize_t )sectsize);
  } else
  if (prev_sectsize < sectsize) {
    tmp___0 = _TIFFrealloc((void *)sect_buff, (tmsize_t )sectsize);
    new_buff = (unsigned char *)tmp___0;
    if (! new_buff) {
      free((void *)sect_buff);
      tmp___1 = _TIFFmalloc((tmsize_t )sectsize);
      sect_buff = (unsigned char *)tmp___1;
    } else {
      sect_buff = new_buff;
    }
    _TIFFmemset((void *)sect_buff, 0, (tmsize_t )sectsize);
  }
  if (! sect_buff) {
    TIFFError((char const   *)"createImageSection", (char const   *)"Unable to allocate/reallocate section buffer");
    return (-1);
  }
  prev_sectsize = sectsize;
  *sect_buff_ptr = sect_buff;
  return (0);
}
}
static int processCropSelections(struct image_data *image , struct crop_mask *crop ,
                                 unsigned char **read_buff_ptr , struct buffinfo *seg_buffs ) 
{ 
  int i ;
  uint32 width ;
  uint32 length ;
  uint32 total_width ;
  uint32 total_length ;
  tsize_t cropsize ;
  unsigned char *crop_buff ;
  unsigned char *read_buff ;
  unsigned char *next_buff ;
  tsize_t prev_cropsize ;
  void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  char *tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  void *tmp___7 ;
  void *tmp___8 ;
  void *tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  char *tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;

  {
  crop_buff = (unsigned char *)((void *)0);
  read_buff = (unsigned char *)((void *)0);
  next_buff = (unsigned char *)((void *)0);
  prev_cropsize = (tsize_t )0;
  read_buff = *read_buff_ptr;
  if ((int )crop->img_mode == 0) {
    cropsize = (tsize_t )crop->bufftotal;
    crop_buff = (seg_buffs + 0)->buffer;
    if (! crop_buff) {
      tmp = _TIFFmalloc(cropsize);
      crop_buff = (unsigned char *)tmp;
    } else {
      prev_cropsize = (tsize_t )(seg_buffs + 0)->size;
      if (prev_cropsize < cropsize) {
        tmp___0 = _TIFFrealloc((void *)crop_buff, cropsize);
        next_buff = (unsigned char *)tmp___0;
        if (! next_buff) {
          _TIFFfree((void *)crop_buff);
          tmp___1 = _TIFFmalloc(cropsize);
          crop_buff = (unsigned char *)tmp___1;
        } else {
          crop_buff = next_buff;
        }
      }
    }
    if (! crop_buff) {
      TIFFError((char const   *)"processCropSelections", (char const   *)"Unable to allocate/reallocate crop buffer");
      return (-1);
    }
    _TIFFmemset((void *)crop_buff, 0, cropsize);
    (seg_buffs + 0)->buffer = crop_buff;
    (seg_buffs + 0)->size = (uint32 )cropsize;
    tmp___2 = extractCompositeRegions(image, crop, read_buff, crop_buff);
    if (tmp___2 != 0) {
      return (1);
    }
    if ((int )crop->crop_mode & 128) {
      if ((int )crop->photometric == 1) {
        goto case_1;
      }
      if ((int )crop->photometric == 0) {
        goto case_1;
      }
      if ((int )crop->photometric == 11) {
        goto case_11;
      }
      if ((int )crop->photometric == 10) {
        goto case_11;
      }
      goto switch_default___0;
      case_1: 
      image->photometric = crop->photometric;
      goto switch_break;
      case_11: 
      tmp___3 = invertImage(image->photometric, image->spp, image->bps, crop->combined_width,
                            crop->combined_length, crop_buff);
      if (tmp___3) {
        TIFFError((char const   *)"processCropSelections", (char const   *)"Failed to invert colorspace for composite regions");
        return (-1);
      }
      if ((int )crop->photometric == 11) {
        if ((int )image->photometric == 0) {
          goto case_0___0;
        }
        if ((int )image->photometric == 1) {
          goto case_1___0;
        }
        goto switch_default;
        case_0___0: 
        image->photometric = (uint16 )1;
        goto switch_break___0;
        case_1___0: 
        image->photometric = (uint16 )0;
        goto switch_break___0;
        switch_default: 
        goto switch_break___0;
        switch_break___0: ;
      }
      goto switch_break;
      switch_default___0: 
      goto switch_break;
      switch_break: ;
    }
    if ((int )crop->crop_mode & 64) {
      tmp___5 = mirrorImage(image->spp, image->bps, crop->mirror, crop->combined_width,
                            crop->combined_length, crop_buff);
      if (tmp___5) {
        if ((int )crop->rotation == 1) {
          tmp___4 = "horizontally";
        } else {
          tmp___4 = "vertically";
        }
        TIFFError((char const   *)"processCropSelections", (char const   *)"Failed to mirror composite regions %s",
                  tmp___4);
        return (-1);
      }
    }
    if ((int )crop->crop_mode & 32) {
      tmp___6 = rotateImage(crop->rotation, image, & crop->combined_width, & crop->combined_length,
                            & crop_buff);
      if (tmp___6) {
        TIFFError((char const   *)"processCropSelections", (char const   *)"Failed to rotate composite regions by %d degrees",
                  (int )crop->rotation);
        return (-1);
      }
      (seg_buffs + 0)->buffer = crop_buff;
      (seg_buffs + 0)->size = (((crop->combined_width * (uint32 )image->bps + 7U) / 8U) * (uint32 )image->spp) * crop->combined_length;
    }
  } else {
    total_length = (uint32 )0;
    total_width = total_length;
    i = 0;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (i < (int )crop->selections)) {
        goto while_break;
      }
      cropsize = (tsize_t )crop->bufftotal;
      crop_buff = (seg_buffs + i)->buffer;
      if (! crop_buff) {
        tmp___7 = _TIFFmalloc(cropsize);
        crop_buff = (unsigned char *)tmp___7;
      } else {
        prev_cropsize = (tsize_t )(seg_buffs + 0)->size;
        if (prev_cropsize < cropsize) {
          tmp___8 = _TIFFrealloc((void *)crop_buff, cropsize);
          next_buff = (unsigned char *)tmp___8;
          if (! next_buff) {
            _TIFFfree((void *)crop_buff);
            tmp___9 = _TIFFmalloc(cropsize);
            crop_buff = (unsigned char *)tmp___9;
          } else {
            crop_buff = next_buff;
          }
        }
      }
      if (! crop_buff) {
        TIFFError((char const   *)"processCropSelections", (char const   *)"Unable to allocate/reallocate crop buffer");
        return (-1);
      }
      _TIFFmemset((void *)crop_buff, 0, cropsize);
      (seg_buffs + i)->buffer = crop_buff;
      (seg_buffs + i)->size = (uint32 )cropsize;
      tmp___10 = extractSeparateRegion(image, crop, read_buff, crop_buff, i);
      if (tmp___10) {
        TIFFError((char const   *)"processCropSelections", (char const   *)"Unable to extract cropped region %d from image",
                  i);
        return (-1);
      }
      width = crop->regionlist[i].width;
      length = crop->regionlist[i].length;
      if ((int )crop->crop_mode & 128) {
        if ((int )crop->photometric == 1) {
          goto case_1___1;
        }
        if ((int )crop->photometric == 0) {
          goto case_1___1;
        }
        if ((int )crop->photometric == 11) {
          goto case_11___0;
        }
        if ((int )crop->photometric == 10) {
          goto case_11___0;
        }
        goto switch_default___2;
        case_1___1: 
        image->photometric = crop->photometric;
        goto switch_break___1;
        case_11___0: 
        tmp___11 = invertImage(image->photometric, image->spp, image->bps, width,
                               length, crop_buff);
        if (tmp___11) {
          TIFFError((char const   *)"processCropSelections", (char const   *)"Failed to invert colorspace for region");
          return (-1);
        }
        if ((int )crop->photometric == 11) {
          if ((int )image->photometric == 0) {
            goto case_0___2;
          }
          if ((int )image->photometric == 1) {
            goto case_1___2;
          }
          goto switch_default___1;
          case_0___2: 
          image->photometric = (uint16 )1;
          goto switch_break___2;
          case_1___2: 
          image->photometric = (uint16 )0;
          goto switch_break___2;
          switch_default___1: 
          goto switch_break___2;
          switch_break___2: ;
        }
        goto switch_break___1;
        switch_default___2: 
        goto switch_break___1;
        switch_break___1: ;
      }
      if ((int )crop->crop_mode & 64) {
        tmp___13 = mirrorImage(image->spp, image->bps, crop->mirror, width, length,
                               crop_buff);
        if (tmp___13) {
          if ((int )crop->rotation == 1) {
            tmp___12 = "horizontally";
          } else {
            tmp___12 = "vertically";
          }
          TIFFError((char const   *)"processCropSelections", (char const   *)"Failed to mirror crop region %s",
                    tmp___12);
          return (-1);
        }
      }
      if ((int )crop->crop_mode & 32) {
        tmp___14 = rotateImage(crop->rotation, image, & crop->regionlist[i].width,
                               & crop->regionlist[i].length, & crop_buff);
        if (tmp___14) {
          TIFFError((char const   *)"processCropSelections", (char const   *)"Failed to rotate crop region by %d degrees",
                    (int )crop->rotation);
          return (-1);
        }
        total_width += crop->regionlist[i].width;
        total_length += crop->regionlist[i].length;
        crop->combined_width = total_width;
        crop->combined_length = total_length;
        (seg_buffs + i)->buffer = crop_buff;
        (seg_buffs + i)->size = (((crop->regionlist[i].width * (uint32 )image->bps + 7U) / 8U) * (uint32 )image->spp) * crop->regionlist[i].length;
      }
      i ++;
    }
    while_break___0: /* CIL Label */ ;
    }
    while_break: ;
  }
  return (0);
}
}
static tsize_t prev_cropsize  =    (tsize_t )0;
static int createCroppedImage(struct image_data *image , struct crop_mask *crop ,
                              unsigned char **read_buff_ptr , unsigned char **crop_buff_ptr ) 
{ 
  tsize_t cropsize ;
  unsigned char *read_buff ;
  unsigned char *crop_buff ;
  unsigned char *new_buff ;
  void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;
  int tmp___2 ;
  char *tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  read_buff = (unsigned char *)((void *)0);
  crop_buff = (unsigned char *)((void *)0);
  new_buff = (unsigned char *)((void *)0);
  read_buff = *read_buff_ptr;
  crop_buff = read_buff;
  *crop_buff_ptr = read_buff;
  crop->combined_width = image->width;
  crop->combined_length = image->length;
  cropsize = (tsize_t )crop->bufftotal;
  crop_buff = *crop_buff_ptr;
  if (! crop_buff) {
    tmp = _TIFFmalloc(cropsize);
    crop_buff = (unsigned char *)tmp;
    *crop_buff_ptr = crop_buff;
    _TIFFmemset((void *)crop_buff, 0, cropsize);
    prev_cropsize = cropsize;
  } else
  if (prev_cropsize < cropsize) {
    tmp___0 = _TIFFrealloc((void *)crop_buff, cropsize);
    new_buff = (unsigned char *)tmp___0;
    if (! new_buff) {
      free((void *)crop_buff);
      tmp___1 = _TIFFmalloc(cropsize);
      crop_buff = (unsigned char *)tmp___1;
    } else {
      crop_buff = new_buff;
    }
    _TIFFmemset((void *)crop_buff, 0, cropsize);
  }
  if (! crop_buff) {
    TIFFError((char const   *)"createCroppedImage", (char const   *)"Unable to allocate/reallocate crop buffer");
    return (-1);
  }
  *crop_buff_ptr = crop_buff;
  if ((int )crop->crop_mode & 128) {
    if ((int )crop->photometric == 1) {
      goto case_1;
    }
    if ((int )crop->photometric == 0) {
      goto case_1;
    }
    if ((int )crop->photometric == 11) {
      goto case_11;
    }
    if ((int )crop->photometric == 10) {
      goto case_11;
    }
    goto switch_default___0;
    case_1: 
    image->photometric = crop->photometric;
    goto switch_break;
    case_11: 
    tmp___2 = invertImage(image->photometric, image->spp, image->bps, crop->combined_width,
                          crop->combined_length, crop_buff);
    if (tmp___2) {
      TIFFError((char const   *)"createCroppedImage", (char const   *)"Failed to invert colorspace for image or cropped selection");
      return (-1);
    }
    if ((int )crop->photometric == 11) {
      if ((int )image->photometric == 0) {
        goto case_0___0;
      }
      if ((int )image->photometric == 1) {
        goto case_1___0;
      }
      goto switch_default;
      case_0___0: 
      image->photometric = (uint16 )1;
      goto switch_break___0;
      case_1___0: 
      image->photometric = (uint16 )0;
      goto switch_break___0;
      switch_default: 
      goto switch_break___0;
      switch_break___0: ;
    }
    goto switch_break;
    switch_default___0: 
    goto switch_break;
    switch_break: ;
  }
  if ((int )crop->crop_mode & 64) {
    tmp___4 = mirrorImage(image->spp, image->bps, crop->mirror, crop->combined_width,
                          crop->combined_length, crop_buff);
    if (tmp___4) {
      if ((int )crop->rotation == 1) {
        tmp___3 = "horizontally";
      } else {
        tmp___3 = "vertically";
      }
      TIFFError((char const   *)"createCroppedImage", (char const   *)"Failed to mirror image or cropped selection %s",
                tmp___3);
      return (-1);
    }
  }
  if ((int )crop->crop_mode & 32) {
    tmp___5 = rotateImage(crop->rotation, image, & crop->combined_width, & crop->combined_length,
                          crop_buff_ptr);
    if (tmp___5) {
      TIFFError((char const   *)"createCroppedImage", (char const   *)"Failed to rotate image or cropped selection by %d degrees",
                (int )crop->rotation);
      return (-1);
    }
  }
  if ((unsigned long )crop_buff == (unsigned long )read_buff) {
    *read_buff_ptr = (unsigned char *)((void *)0);
  }
  return (0);
}
}
static int writeCroppedImage(TIFF *in , TIFF *out , struct image_data *image , struct dump_opts *dump ,
                             uint32 width , uint32 length , unsigned char *crop_buff ,
                             int pagenum , int total_pages ) 
{ 
  uint16 bps ;
  uint16 spp ;
  uint16 input_compression ;
  uint16 input_photometric ;
  uint16 input_planar ;
  struct cpTag *p ;
  int tmp ;
  char *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  uint32 len32 ;
  void **data ;
  int tmp___7 ;
  uint16 ninks ;
  char const   *inknames ;
  int inknameslen ;
  size_t tmp___8 ;
  char const   *cp ;
  char *tmp___9 ;
  size_t tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  unsigned short pg0 ;
  unsigned short pg1 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;

  {
  input_compression = image->compression;
  input_photometric = image->photometric;
  spp = image->spp;
  bps = image->bps;
  TIFFSetField(out, (uint32 )256, width);
  TIFFSetField(out, (uint32 )257, length);
  TIFFSetField(out, (uint32 )258, (int )bps);
  TIFFSetField(out, (uint32 )277, (int )spp);
  if ((int )compression != 65535) {
    TIFFSetField(out, (uint32 )259, (int )compression);
  } else
  if ((int )input_compression == 6) {
    compression = (uint16 )7;
    jpegcolormode = 0x0000;
    TIFFSetField(out, (uint32 )259, 7);
  } else {
    tmp = TIFFGetField(in, (uint32 )259, & compression);
    if (tmp) {
      TIFFSetField(out, (uint32 )259, (int )compression);
    }
  }
  if ((int )compression == 7) {
    if ((int )input_photometric == 3) {
      goto _L;
    } else
    if ((int )input_photometric == 4) {
      _L: 
      if ((int )input_photometric == 3) {
        tmp___0 = "palette";
      } else {
        tmp___0 = "mask";
      }
      TIFFError((char const   *)"writeCroppedImage", (char const   *)"JPEG compression cannot be used with %s image data",
                tmp___0);
      return (-1);
    }
    if ((int )input_photometric == 2) {
      if (jpegcolormode == 0x0001) {
        TIFFSetField(out, (uint32 )262, 6);
      } else {
        TIFFSetField(out, (uint32 )262, (int )input_photometric);
      }
    } else {
      TIFFSetField(out, (uint32 )262, (int )input_photometric);
    }
  } else
  if ((int )compression == 34676) {
    goto _L___1;
  } else
  if ((int )compression == 34677) {
    _L___1: 
    if ((int )spp == 1) {
      tmp___1 = 32844;
    } else {
      tmp___1 = 32845;
    }
    TIFFSetField(out, (uint32 )262, tmp___1);
  } else
  if ((int )input_compression == 34676) {
    goto _L___0;
  } else
  if ((int )input_compression == 34677) {
    _L___0: 
    if ((int )spp == 1) {
      tmp___2 = 32844;
    } else {
      tmp___2 = 32845;
    }
    TIFFSetField(out, (uint32 )262, tmp___2);
  } else {
    TIFFSetField(out, (uint32 )262, (int )image->photometric);
  }
  if ((int )input_photometric == 32844) {
    goto _L___2;
  } else
  if ((int )input_photometric == 32845) {
    _L___2: 
    if ((int )compression != 34676) {
      if ((int )compression != 34677) {
        TIFFError((char const   *)"writeCroppedImage", (char const   *)"LogL and LogLuv source data require SGI_LOG or SGI_LOG24 compression");
        return (-1);
      }
    }
  }
  if ((int )fillorder != 0) {
    TIFFSetField(out, (uint32 )266, (int )fillorder);
  } else {
    cpTag(in, out, (uint16 )266, (uint16 )1, (TIFFDataType )3);
  }
  TIFFSetField(out, (uint32 )274, (int )image->orientation);
  if (outtiled == -1) {
    outtiled = TIFFIsTiled(in);
  }
  if (outtiled) {
    if (tilewidth == 0U) {
      TIFFGetField(in, (uint32 )322, & tilewidth);
    }
    if (tilelength == 0U) {
      TIFFGetField(in, (uint32 )323, & tilelength);
    }
    if (tilewidth == 0U) {
      TIFFDefaultTileSize(out, & tilewidth, & tilelength);
    } else
    if (tilelength == 0U) {
      TIFFDefaultTileSize(out, & tilewidth, & tilelength);
    }
    TIFFSetField(out, (uint32 )322, tilewidth);
    TIFFSetField(out, (uint32 )323, tilelength);
  } else {
    if (rowsperstrip == 0U) {
      tmp___3 = TIFFGetField(in, (uint32 )278, & rowsperstrip);
      if (! tmp___3) {
        rowsperstrip = TIFFDefaultStripSize(out, rowsperstrip);
      }
      if ((int )compression != 7) {
        if (rowsperstrip > length) {
          rowsperstrip = length;
        }
      }
    } else
    if (rowsperstrip == 4294967295U) {
      rowsperstrip = length;
    }
    TIFFSetField(out, (uint32 )278, rowsperstrip);
  }
  TIFFGetFieldDefaulted(in, (uint32 )284, & input_planar);
  if ((int )config != 65535) {
    TIFFSetField(out, (uint32 )284, (int )config);
  } else {
    tmp___4 = TIFFGetField(in, (uint32 )284, & config);
    if (tmp___4) {
      TIFFSetField(out, (uint32 )284, (int )config);
    }
  }
  if ((int )spp <= 4) {
    cpTag(in, out, (uint16 )301, (uint16 )4, (TIFFDataType )3);
  }
  cpTag(in, out, (uint16 )320, (uint16 )4, (TIFFDataType )3);
  if ((int )compression == 7) {
    goto case_7;
  }
  if ((int )compression == 32946) {
    goto case_32946;
  }
  if ((int )compression == 8) {
    goto case_32946;
  }
  if ((int )compression == 5) {
    goto case_32946;
  }
  if ((int )compression == 4) {
    goto case_4;
  }
  if ((int )compression == 3) {
    goto case_4;
  }
  if ((int )compression == 1) {
    goto case_1;
  }
  goto switch_default;
  case_7: 
  if ((int )bps % 8 == 0) {
    TIFFSetField(out, (uint32 )65537, quality);
    TIFFSetField(out, (uint32 )65538, 0x0001);
  } else
  if ((int )bps % 12 == 0) {
    TIFFSetField(out, (uint32 )65537, quality);
    TIFFSetField(out, (uint32 )65538, 0x0001);
  } else {
    TIFFError((char const   *)"writeCroppedImage", (char const   *)"JPEG compression requires 8 or 12 bits per sample");
    return (-1);
  }
  goto switch_break;
  case_32946: 
  if ((int )predictor != 65535) {
    TIFFSetField(out, (uint32 )317, (int )predictor);
  } else {
    tmp___5 = TIFFGetField(in, (uint32 )317, & predictor);
    if (tmp___5) {
      TIFFSetField(out, (uint32 )317, (int )predictor);
    }
  }
  goto switch_break;
  case_4: 
  if ((int )bps != 1) {
    TIFFError((char const   *)"writeCroppedImage", (char const   *)"Group 3/4 compression is not usable with bps > 1");
    return (-1);
  }
  if ((int )compression == 3) {
    if (g3opts != 4294967295U) {
      TIFFSetField(out, (uint32 )292, g3opts);
    } else {
      tmp___6 = TIFFGetField(in, (uint32 )292, & g3opts);
      if (tmp___6) {
        TIFFSetField(out, (uint32 )292, g3opts);
      }
    }
  } else {
    cpTag(in, out, (uint16 )293, (uint16 )1, (TIFFDataType )4);
  }
  cpTag(in, out, (uint16 )326, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )327, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )328, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )34908, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )34910, (uint16 )1, (TIFFDataType )4);
  cpTag(in, out, (uint16 )34909, (uint16 )1, (TIFFDataType )2);
  goto switch_break;
  case_1: 
  goto switch_break;
  switch_default: 
  goto switch_break;
  switch_break: 
  tmp___7 = TIFFGetField(in, (uint32 )34675, & len32, & data);
  if (tmp___7) {
    TIFFSetField(out, (uint32 )34675, len32, data);
  }
  tmp___12 = TIFFGetField(in, (uint32 )334, & ninks);
  if (tmp___12) {
    TIFFSetField(out, (uint32 )334, (int )ninks);
    tmp___11 = TIFFGetField(in, (uint32 )333, & inknames);
    if (tmp___11) {
      tmp___8 = strlen(inknames);
      inknameslen = (int )(tmp___8 + 1UL);
      cp = inknames;
      {
      while (1) {
        while_continue: /* CIL Label */ ;

        if (! ((int )ninks > 1)) {
          goto while_break;
        }
        tmp___9 = strchr(cp, '\000');
        cp = (char const   *)tmp___9;
        if (cp) {
          cp ++;
          tmp___10 = strlen(cp);
          inknameslen = (int )((size_t )inknameslen + (tmp___10 + 1UL));
        }
        ninks = (uint16 )((int )ninks - 1);
      }
      while_break___1: /* CIL Label */ ;
      }
      while_break: 
      TIFFSetField(out, (uint32 )333, inknameslen, inknames);
    }
  }
  tmp___13 = TIFFGetField(in, (uint32 )297, & pg0, & pg1);
  if (tmp___13) {
    TIFFSetField(out, (uint32 )297, pagenum, total_pages);
  }
  p = tags;
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;

    if (! ((unsigned long )p < (unsigned long )(& tags[sizeof(tags) / sizeof(tags[0])]))) {
      goto while_break___0;
    }
    cpTag(in, out, p->tag, p->count, p->type);
    p ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break___0: ;
  if (outtiled) {
    if ((int )config == 1) {
      tmp___14 = writeBufferToContigTiles(out, crop_buff, length, width, spp, dump);
      if (tmp___14) {
        TIFFError((char const   *)"", (char const   *)"Unable to write contiguous tile data for page %d",
                  pagenum);
      }
    } else {
      tmp___15 = writeBufferToSeparateTiles(out, crop_buff, length, width, spp, dump);
      if (tmp___15) {
        TIFFError((char const   *)"", (char const   *)"Unable to write separate tile data for page %d",
                  pagenum);
      }
    }
  } else
  if ((int )config == 1) {
    tmp___16 = writeBufferToContigStrips(out, crop_buff, length);
    if (tmp___16) {
      TIFFError((char const   *)"", (char const   *)"Unable to write contiguous strip data for page %d",
                pagenum);
    }
  } else {
    tmp___17 = writeBufferToSeparateStrips(out, crop_buff, length, width, spp, dump);
    if (tmp___17) {
      TIFFError((char const   *)"", (char const   *)"Unable to write separate strip data for page %d",
                pagenum);
    }
  }
  tmp___18 = TIFFWriteDirectory(out);
  if (! tmp___18) {
    TIFFError((char const   *)"", (char const   *)"Failed to write IFD for page number %d",
              pagenum);
    TIFFClose(out);
    return (-1);
  }
  return (0);
}
}
static int rotateContigSamples8bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                    uint32 length , uint32 col , uint8 *src , uint8 *dst ) 
{ 
  int ready_bits ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 row ;
  uint32 rowsize ;
  uint32 bit_offset ;
  uint8 matchbits ;
  uint8 maskbits ;
  uint8 buff1 ;
  uint8 buff2 ;
  uint8 *next ;
  tsample_t sample ;
  uint8 *tmp ;
  uint8 *tmp___0 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  rowsize = (uint32 )0;
  bit_offset = (uint32 )0;
  matchbits = (uint8 )0;
  maskbits = (uint8 )0;
  buff1 = (uint8 )0;
  buff2 = (uint8 )0;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples8bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples8bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  }
  rowsize = ((uint32 )((int )bps * (int )spp) * width + 7U) / 8U;
  ready_bits = 0;
  maskbits = (uint8 )(255 >> (8 - (int )bps));
  buff2 = (uint8 )0;
  buff1 = buff2;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      if ((int )rotation == 90) {
        goto case_90;
      }
      if ((int )rotation == 270) {
        goto case_270;
      }
      goto switch_default;
      case_90: 
      next = (src + src_byte) - row * rowsize;
      goto switch_break;
      case_270: 
      next = (src + src_byte) + row * rowsize;
      goto switch_break;
      switch_default: 
      TIFFError((char const   *)"rotateContigSamples8bits", (char const   *)"Invalid rotation %d",
                (int )rotation);
      return (1);
      switch_break: 
      matchbits = (uint8 )((int )maskbits << ((8U - src_bit) - (uint32 )bps));
      buff1 = (uint8 )(((int )*next & (int )matchbits) << src_bit);
      if (ready_bits >= 8) {
        tmp = dst;
        dst ++;
        *tmp = buff2;
        buff2 = buff1;
        ready_bits -= 8;
      } else {
        buff2 = (uint8 )((int )buff2 | ((int )buff1 >> ready_bits));
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: 
    row ++;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: ;
  if (ready_bits > 0) {
    buff1 = (uint8 )((unsigned int )buff2 & (255U << (8 - ready_bits)));
    tmp___0 = dst;
    dst ++;
    *tmp___0 = buff1;
  }
  return (0);
}
}
static int rotateContigSamples16bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                     uint32 length , uint32 col , uint8 *src , uint8 *dst ) 
{ 
  int ready_bits ;
  uint32 row ;
  uint32 rowsize ;
  uint32 bit_offset ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint16 matchbits ;
  uint16 maskbits ;
  uint16 buff1 ;
  uint16 buff2 ;
  uint8 bytebuff ;
  uint8 *next ;
  tsample_t sample ;
  uint8 *tmp ;
  uint8 *tmp___0 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  matchbits = (uint16 )0;
  maskbits = (uint16 )0;
  buff1 = (uint16 )0;
  buff2 = (uint16 )0;
  bytebuff = (uint8 )0;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples16bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples16bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  }
  rowsize = ((uint32 )((int )bps * (int )spp) * width + 7U) / 8U;
  ready_bits = 0;
  maskbits = (uint16 )(65535 >> (16 - (int )bps));
  buff2 = (uint16 )0;
  buff1 = buff2;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      if ((int )rotation == 90) {
        goto case_90;
      }
      if ((int )rotation == 270) {
        goto case_270;
      }
      goto switch_default;
      case_90: 
      next = (src + src_byte) - row * rowsize;
      goto switch_break;
      case_270: 
      next = (src + src_byte) + row * rowsize;
      goto switch_break;
      switch_default: 
      TIFFError((char const   *)"rotateContigSamples8bits", (char const   *)"Invalid rotation %d",
                (int )rotation);
      return (1);
      switch_break: 
      matchbits = (uint16 )((int )maskbits << ((16U - src_bit) - (uint32 )bps));
      if (little_endian) {
        buff1 = (uint16 )(((int )*(next + 0) << 8) | (int )*(next + 1));
      } else {
        buff1 = (uint16 )(((int )*(next + 1) << 8) | (int )*(next + 0));
      }
      buff1 = (uint16 )(((int )buff1 & (int )matchbits) << src_bit);
      if (ready_bits >= 8) {
        bytebuff = (uint8 )((int )buff2 >> 8);
        tmp = dst;
        dst ++;
        *tmp = bytebuff;
        ready_bits -= 8;
        buff2 = (uint16 )(((int )buff2 << 8) | ((int )buff1 >> ready_bits));
      } else {
        bytebuff = (uint8 )0;
        buff2 = (uint16 )((int )buff2 | ((int )buff1 >> ready_bits));
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: 
    row ++;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: ;
  if (ready_bits > 0) {
    bytebuff = (uint8 )((int )buff2 >> 8);
    tmp___0 = dst;
    dst ++;
    *tmp___0 = bytebuff;
  }
  return (0);
}
}
static int rotateContigSamples24bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                     uint32 length , uint32 col , uint8 *src , uint8 *dst ) 
{ 
  int ready_bits ;
  uint32 row ;
  uint32 rowsize ;
  uint32 bit_offset ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 matchbits ;
  uint32 maskbits ;
  uint32 buff1 ;
  uint32 buff2 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 *next ;
  tsample_t sample ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  uint8 *tmp___1 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  src_bit = (uint32 )0;
  matchbits = (uint32 )0;
  maskbits = (uint32 )0;
  buff1 = (uint32 )0;
  buff2 = (uint32 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples24bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples24bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  }
  rowsize = ((uint32 )((int )bps * (int )spp) * width + 7U) / 8U;
  ready_bits = 0;
  maskbits = 4294967295U >> (32 - (int )bps);
  buff2 = (uint32 )0;
  buff1 = buff2;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      if ((int )rotation == 90) {
        goto case_90;
      }
      if ((int )rotation == 270) {
        goto case_270;
      }
      goto switch_default;
      case_90: 
      next = (src + src_byte) - row * rowsize;
      goto switch_break;
      case_270: 
      next = (src + src_byte) + row * rowsize;
      goto switch_break;
      switch_default: 
      TIFFError((char const   *)"rotateContigSamples8bits", (char const   *)"Invalid rotation %d",
                (int )rotation);
      return (1);
      switch_break: 
      matchbits = maskbits << ((32U - src_bit) - (uint32 )bps);
      if (little_endian) {
        buff1 = (uint32 )(((((int )*(next + 0) << 24) | ((int )*(next + 1) << 16)) | ((int )*(next + 2) << 8)) | (int )*(next + 3));
      } else {
        buff1 = (uint32 )(((((int )*(next + 3) << 24) | ((int )*(next + 2) << 16)) | ((int )*(next + 1) << 8)) | (int )*(next + 0));
      }
      buff1 = (buff1 & matchbits) << src_bit;
      if (ready_bits >= 16) {
        bytebuff1 = (uint8 )(buff2 >> 24);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 16);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        ready_bits -= 16;
        buff2 = (buff2 << 16) | (buff1 >> ready_bits);
      } else {
        bytebuff2 = (uint8 )0;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    row ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 24);
    tmp___1 = dst;
    dst ++;
    *tmp___1 = bytebuff1;
    buff2 <<= 8;
    bytebuff2 = bytebuff1;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int rotateContigSamples32bits(uint16 rotation , uint16 spp , uint16 bps , uint32 width ,
                                     uint32 length , uint32 col , uint8 *src , uint8 *dst ) 
{ 
  int ready_bits ;
  uint32 row ;
  uint32 rowsize ;
  uint32 bit_offset ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 longbuff1 ;
  uint32 longbuff2 ;
  uint64 maskbits ;
  uint64 matchbits ;
  uint64 buff1 ;
  uint64 buff2 ;
  uint64 buff3 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 bytebuff3 ;
  uint8 bytebuff4 ;
  uint8 *next ;
  tsample_t sample ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  uint8 *tmp___1 ;
  uint8 *tmp___2 ;
  uint8 *tmp___3 ;

  {
  ready_bits = 0;
  longbuff1 = (uint32 )0;
  longbuff2 = (uint32 )0;
  maskbits = (uint64 )0;
  matchbits = (uint64 )0;
  buff1 = (uint64 )0;
  buff2 = (uint64 )0;
  buff3 = (uint64 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  bytebuff3 = (uint8 )0;
  bytebuff4 = (uint8 )0;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples24bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"rotateContigSamples24bits", (char const   *)"Invalid src or destination buffer");
    return (1);
  }
  rowsize = ((uint32 )((int )bps * (int )spp) * width + 7U) / 8U;
  ready_bits = 0;
  maskbits = 18446744073709551615UL >> (64 - (int )bps);
  buff2 = (uint64 )0;
  buff1 = buff2;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break;
    }
    bit_offset = (col * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      if ((int )rotation == 90) {
        goto case_90;
      }
      if ((int )rotation == 270) {
        goto case_270;
      }
      goto switch_default;
      case_90: 
      next = (src + src_byte) - row * rowsize;
      goto switch_break;
      case_270: 
      next = (src + src_byte) + row * rowsize;
      goto switch_break;
      switch_default: 
      TIFFError((char const   *)"rotateContigSamples8bits", (char const   *)"Invalid rotation %d",
                (int )rotation);
      return (1);
      switch_break: 
      matchbits = maskbits << ((64U - src_bit) - (uint32 )bps);
      if (little_endian) {
        longbuff1 = (uint32 )(((((int )*(next + 0) << 24) | ((int )*(next + 1) << 16)) | ((int )*(next + 2) << 8)) | (int )*(next + 3));
        longbuff2 = longbuff1;
      } else {
        longbuff1 = (uint32 )(((((int )*(next + 3) << 24) | ((int )*(next + 2) << 16)) | ((int )*(next + 1) << 8)) | (int )*(next + 0));
        longbuff2 = longbuff1;
      }
      buff3 = ((uint64 )longbuff1 << 32) | (unsigned long )longbuff2;
      buff1 = (buff3 & matchbits) << src_bit;
      if (ready_bits < 32) {
        bytebuff4 = (uint8 )0;
        bytebuff3 = bytebuff4;
        bytebuff2 = bytebuff3;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      } else {
        bytebuff1 = (uint8 )(buff2 >> 56);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 48);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        bytebuff3 = (uint8 )(buff2 >> 40);
        tmp___1 = dst;
        dst ++;
        *tmp___1 = bytebuff3;
        bytebuff4 = (uint8 )(buff2 >> 32);
        tmp___2 = dst;
        dst ++;
        *tmp___2 = bytebuff4;
        ready_bits -= 32;
        buff2 = (buff2 << 32) | (buff1 >> ready_bits);
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    row ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 56);
    tmp___3 = dst;
    dst ++;
    *tmp___3 = bytebuff1;
    buff2 <<= 8;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int rotateImage(uint16 rotation , struct image_data *image , uint32 *img_width ,
                       uint32 *img_length , unsigned char **ibuff_ptr ) 
{ 
  int shift_width ;
  uint32 bytes_per_pixel ;
  uint32 bytes_per_sample ;
  uint32 row ;
  uint32 rowsize ;
  uint32 src_offset ;
  uint32 dst_offset ;
  uint32 i ;
  uint32 col ;
  uint32 width ;
  uint32 length ;
  uint32 colsize ;
  uint32 buffsize ;
  uint32 col_offset ;
  uint32 pix_offset ;
  unsigned char *ibuff ;
  unsigned char *src ;
  unsigned char *dst ;
  uint16 spp ;
  uint16 bps ;
  float res_temp ;
  unsigned char *rbuff ;
  void *tmp ;
  unsigned char *tmp___0 ;
  unsigned char *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  unsigned char *tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  unsigned char *tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;

  {
  rbuff = (unsigned char *)((void *)0);
  width = *img_width;
  length = *img_length;
  spp = image->spp;
  bps = image->bps;
  rowsize = ((uint32 )((int )bps * (int )spp) * width + 7U) / 8U;
  colsize = ((uint32 )((int )bps * (int )spp) * length + 7U) / 8U;
  if (colsize * width > rowsize * length) {
    buffsize = (colsize + 1U) * width;
  } else {
    buffsize = (rowsize + 1U) * length;
  }
  bytes_per_sample = (uint32 )(((int )bps + 7) / 8);
  bytes_per_pixel = (uint32 )(((int )bps * (int )spp + 7) / 8);
  if (bytes_per_pixel < bytes_per_sample + 1U) {
    shift_width = (int )bytes_per_pixel;
  } else {
    shift_width = (int )(bytes_per_sample + 1U);
  }
  if ((int )rotation == 360) {
    goto case_360;
  }
  if ((int )rotation == 0) {
    goto case_360;
  }
  if ((int )rotation == 270) {
    goto case_270;
  }
  if ((int )rotation == 180) {
    goto case_270;
  }
  if ((int )rotation == 90) {
    goto case_270;
  }
  goto switch_default;
  case_360: 
  return (0);
  case_270: 
  goto switch_break;
  switch_default: 
  TIFFError((char const   *)"rotateImage", (char const   *)"Invalid rotation angle %d",
            (int )rotation);
  return (-1);
  switch_break: 
  tmp = _TIFFmalloc((tmsize_t )buffsize);
  rbuff = (unsigned char *)tmp;
  if (! rbuff) {
    TIFFError((char const   *)"rotateImage", (char const   *)"Unable to allocate rotation buffer of %1u bytes",
              buffsize);
    return (-1);
  }
  _TIFFmemset((void *)rbuff, '\000', (tmsize_t )buffsize);
  ibuff = *ibuff_ptr;
  if ((int )rotation == 180) {
    goto case_180___0;
  }
  if ((int )rotation == 90) {
    goto case_90___0;
  }
  if ((int )rotation == 270) {
    goto case_270___0;
  }
  goto switch_default___3;
  case_180___0: 
  if ((int )bps % 8 == 0) {
    src = ibuff;
    pix_offset = (uint32 )(((int )spp * (int )bps) / 8);
    row = (uint32 )0;
    {
    while (1) {
      while_continue: /* CIL Label */ ;

      if (! (row < length)) {
        goto while_break;
      }
      dst_offset = ((length - row) - 1U) * rowsize;
      col = (uint32 )0;
      {
      while (1) {
        while_continue___0: /* CIL Label */ ;

        if (! (col < width)) {
          goto while_break___0;
        }
        col_offset = ((width - col) - 1U) * pix_offset;
        dst = (rbuff + dst_offset) + col_offset;
        i = (uint32 )0;
        {
        while (1) {
          while_continue___1: /* CIL Label */ ;

          if (! (i < bytes_per_pixel)) {
            goto while_break___1;
          }
          tmp___0 = dst;
          dst ++;
          tmp___1 = src;
          src ++;
          *tmp___0 = *tmp___1;
          i ++;
        }
        while_break___13: /* CIL Label */ ;
        }
        while_break___1: 
        col ++;
      }
      while_break___12: /* CIL Label */ ;
      }
      while_break___0: 
      row ++;
    }
    while_break___11: /* CIL Label */ ;
    }
    while_break: ;
  } else {
    row = (uint32 )0;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! (row < length)) {
        goto while_break___2;
      }
      src_offset = row * rowsize;
      dst_offset = ((length - row) - 1U) * rowsize;
      src = ibuff + src_offset;
      dst = rbuff + dst_offset;
      if (shift_width == 1) {
        goto case_1;
      }
      if (shift_width == 2) {
        goto case_2;
      }
      if (shift_width == 5) {
        goto case_5;
      }
      if (shift_width == 4) {
        goto case_5;
      }
      if (shift_width == 3) {
        goto case_5;
      }
      goto switch_default___0;
      case_1: 
      if ((int )bps == 1) {
        tmp___2 = reverseSamples8bits(spp, bps, width, src, dst);
        if (tmp___2) {
          _TIFFfree((void *)rbuff);
          return (-1);
        }
        goto switch_break___1;
      }
      tmp___3 = reverseSamples16bits(spp, bps, width, src, dst);
      if (tmp___3) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___1;
      case_2: 
      tmp___4 = reverseSamples24bits(spp, bps, width, src, dst);
      if (tmp___4) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___1;
      case_5: 
      tmp___5 = reverseSamples32bits(spp, bps, width, src, dst);
      if (tmp___5) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___1;
      switch_default___0: 
      TIFFError((char const   *)"rotateImage", (char const   *)"Unsupported bit depth %d",
                (int )bps);
      _TIFFfree((void *)rbuff);
      return (-1);
      switch_break___1: 
      row ++;
    }
    while_break___14: /* CIL Label */ ;
    }
    while_break___2: ;
  }
  _TIFFfree((void *)ibuff);
  *ibuff_ptr = rbuff;
  goto switch_break___0;
  case_90___0: 
  if ((int )bps % 8 == 0) {
    col = (uint32 )0;
    {
    while (1) {
      while_continue___3: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___3;
      }
      src_offset = (length - 1U) * rowsize + col * bytes_per_pixel;
      dst_offset = col * colsize;
      src = ibuff + src_offset;
      dst = rbuff + dst_offset;
      row = length;
      {
      while (1) {
        while_continue___4: /* CIL Label */ ;

        if (! (row > 0U)) {
          goto while_break___4;
        }
        i = (uint32 )0;
        {
        while (1) {
          while_continue___5: /* CIL Label */ ;

          if (! (i < bytes_per_pixel)) {
            goto while_break___5;
          }
          tmp___6 = dst;
          dst ++;
          *tmp___6 = *(src + i);
          i ++;
        }
        while_break___17: /* CIL Label */ ;
        }
        while_break___5: 
        src -= rowsize;
        row --;
      }
      while_break___16: /* CIL Label */ ;
      }
      while_break___4: 
      col ++;
    }
    while_break___15: /* CIL Label */ ;
    }
    while_break___3: ;
  } else {
    col = (uint32 )0;
    {
    while (1) {
      while_continue___6: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___6;
      }
      src_offset = (length - 1U) * rowsize;
      dst_offset = col * colsize;
      src = ibuff + src_offset;
      dst = rbuff + dst_offset;
      if (shift_width == 1) {
        goto case_1___0;
      }
      if (shift_width == 2) {
        goto case_2___0;
      }
      if (shift_width == 5) {
        goto case_5___0;
      }
      if (shift_width == 4) {
        goto case_5___0;
      }
      if (shift_width == 3) {
        goto case_5___0;
      }
      goto switch_default___1;
      case_1___0: 
      if ((int )bps == 1) {
        tmp___7 = rotateContigSamples8bits(rotation, spp, bps, width, length, col,
                                           src, dst);
        if (tmp___7) {
          _TIFFfree((void *)rbuff);
          return (-1);
        }
        goto switch_break___2;
      }
      tmp___8 = rotateContigSamples16bits(rotation, spp, bps, width, length, col,
                                          src, dst);
      if (tmp___8) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___2;
      case_2___0: 
      tmp___9 = rotateContigSamples24bits(rotation, spp, bps, width, length, col,
                                          src, dst);
      if (tmp___9) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___2;
      case_5___0: 
      tmp___10 = rotateContigSamples32bits(rotation, spp, bps, width, length, col,
                                           src, dst);
      if (tmp___10) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___2;
      switch_default___1: 
      TIFFError((char const   *)"rotateImage", (char const   *)"Unsupported bit depth %d",
                (int )bps);
      _TIFFfree((void *)rbuff);
      return (-1);
      switch_break___2: 
      col ++;
    }
    while_break___18: /* CIL Label */ ;
    }
    while_break___6: ;
  }
  _TIFFfree((void *)ibuff);
  *ibuff_ptr = rbuff;
  *img_width = length;
  *img_length = width;
  image->width = length;
  image->length = width;
  res_temp = image->xres;
  image->xres = image->yres;
  image->yres = res_temp;
  goto switch_break___0;
  case_270___0: 
  if ((int )bps % 8 == 0) {
    col = (uint32 )0;
    {
    while (1) {
      while_continue___7: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___7;
      }
      src_offset = col * bytes_per_pixel;
      dst_offset = ((width - col) - 1U) * colsize;
      src = ibuff + src_offset;
      dst = rbuff + dst_offset;
      row = length;
      {
      while (1) {
        while_continue___8: /* CIL Label */ ;

        if (! (row > 0U)) {
          goto while_break___8;
        }
        i = (uint32 )0;
        {
        while (1) {
          while_continue___9: /* CIL Label */ ;

          if (! (i < bytes_per_pixel)) {
            goto while_break___9;
          }
          tmp___11 = dst;
          dst ++;
          *tmp___11 = *(src + i);
          i ++;
        }
        while_break___21: /* CIL Label */ ;
        }
        while_break___9: 
        src += rowsize;
        row --;
      }
      while_break___20: /* CIL Label */ ;
      }
      while_break___8: 
      col ++;
    }
    while_break___19: /* CIL Label */ ;
    }
    while_break___7: ;
  } else {
    col = (uint32 )0;
    {
    while (1) {
      while_continue___10: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___10;
      }
      src_offset = (uint32 )0;
      dst_offset = ((width - col) - 1U) * colsize;
      src = ibuff + src_offset;
      dst = rbuff + dst_offset;
      if (shift_width == 1) {
        goto case_1___1;
      }
      if (shift_width == 2) {
        goto case_2___1;
      }
      if (shift_width == 5) {
        goto case_5___1;
      }
      if (shift_width == 4) {
        goto case_5___1;
      }
      if (shift_width == 3) {
        goto case_5___1;
      }
      goto switch_default___2;
      case_1___1: 
      if ((int )bps == 1) {
        tmp___12 = rotateContigSamples8bits(rotation, spp, bps, width, length, col,
                                            src, dst);
        if (tmp___12) {
          _TIFFfree((void *)rbuff);
          return (-1);
        }
        goto switch_break___3;
      }
      tmp___13 = rotateContigSamples16bits(rotation, spp, bps, width, length, col,
                                           src, dst);
      if (tmp___13) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___3;
      case_2___1: 
      tmp___14 = rotateContigSamples24bits(rotation, spp, bps, width, length, col,
                                           src, dst);
      if (tmp___14) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___3;
      case_5___1: 
      tmp___15 = rotateContigSamples32bits(rotation, spp, bps, width, length, col,
                                           src, dst);
      if (tmp___15) {
        _TIFFfree((void *)rbuff);
        return (-1);
      }
      goto switch_break___3;
      switch_default___2: 
      TIFFError((char const   *)"rotateImage", (char const   *)"Unsupported bit depth %d",
                (int )bps);
      _TIFFfree((void *)rbuff);
      return (-1);
      switch_break___3: 
      col ++;
    }
    while_break___22: /* CIL Label */ ;
    }
    while_break___10: ;
  }
  _TIFFfree((void *)ibuff);
  *ibuff_ptr = rbuff;
  *img_width = length;
  *img_length = width;
  image->width = length;
  image->length = width;
  res_temp = image->xres;
  image->xres = image->yres;
  image->yres = res_temp;
  goto switch_break___0;
  switch_default___3: 
  goto switch_break___0;
  switch_break___0: ;
  return (0);
}
}
static int reverseSamples8bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                               uint8 *obuff ) 
{ 
  int ready_bits ;
  uint32 col ;
  uint32 src_byte ;
  uint32 src_bit ;
  uint32 bit_offset ;
  uint8 match_bits ;
  uint8 mask_bits ;
  uint8 buff1 ;
  uint8 buff2 ;
  unsigned char *src ;
  unsigned char *dst ;
  tsample_t sample ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;

  {
  ready_bits = 0;
  bit_offset = (uint32 )0;
  match_bits = (uint8 )0;
  mask_bits = (uint8 )0;
  buff1 = (uint8 )0;
  buff2 = (uint8 )0;
  if ((unsigned long )ibuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamples8bits", (char const   *)"Invalid image or work buffer");
    return (1);
  } else
  if ((unsigned long )obuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamples8bits", (char const   *)"Invalid image or work buffer");
    return (1);
  }
  ready_bits = 0;
  mask_bits = (uint8 )(255 >> (8 - (int )bps));
  dst = obuff;
  col = width;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col > 0U)) {
      goto while_break;
    }
    bit_offset = ((col - 1U) * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        src_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        src_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      src = ibuff + src_byte;
      match_bits = (uint8 )((int )mask_bits << ((8U - src_bit) - (uint32 )bps));
      buff1 = (uint8 )(((int )*src & (int )match_bits) << src_bit);
      if (ready_bits < 8) {
        buff2 = (uint8 )((int )buff2 | ((int )buff1 >> ready_bits));
      } else {
        tmp = dst;
        dst ++;
        *tmp = buff2;
        buff2 = buff1;
        ready_bits -= 8;
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: 
    col --;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: ;
  if (ready_bits > 0) {
    buff1 = (uint8 )((unsigned int )buff2 & (255U << (8 - ready_bits)));
    tmp___0 = dst;
    dst ++;
    *tmp___0 = buff1;
  }
  return (0);
}
}
static int reverseSamples16bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                                uint8 *obuff ) 
{ 
  int ready_bits ;
  uint32 col ;
  uint32 src_byte ;
  uint32 high_bit ;
  uint32 bit_offset ;
  uint16 match_bits ;
  uint16 mask_bits ;
  uint16 buff1 ;
  uint16 buff2 ;
  uint8 bytebuff ;
  unsigned char *src ;
  unsigned char *dst ;
  tsample_t sample ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  high_bit = (uint32 )0;
  bit_offset = (uint32 )0;
  match_bits = (uint16 )0;
  mask_bits = (uint16 )0;
  buff1 = (uint16 )0;
  buff2 = (uint16 )0;
  bytebuff = (uint8 )0;
  if ((unsigned long )ibuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSample16bits", (char const   *)"Invalid image or work buffer");
    return (1);
  } else
  if ((unsigned long )obuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSample16bits", (char const   *)"Invalid image or work buffer");
    return (1);
  }
  ready_bits = 0;
  mask_bits = (uint16 )(65535 >> (16 - (int )bps));
  dst = obuff;
  col = width;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col > 0U)) {
      goto while_break;
    }
    bit_offset = ((col - 1U) * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        high_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        high_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      src = ibuff + src_byte;
      match_bits = (uint16 )((int )mask_bits << ((16U - high_bit) - (uint32 )bps));
      if (little_endian) {
        buff1 = (uint16 )(((int )*(src + 0) << 8) | (int )*(src + 1));
      } else {
        buff1 = (uint16 )(((int )*(src + 1) << 8) | (int )*(src + 0));
      }
      buff1 = (uint16 )(((int )buff1 & (int )match_bits) << high_bit);
      if (ready_bits < 8) {
        bytebuff = (uint8 )0;
        buff2 = (uint16 )((int )buff2 | ((int )buff1 >> ready_bits));
      } else {
        bytebuff = (uint8 )((int )buff2 >> 8);
        tmp = dst;
        dst ++;
        *tmp = bytebuff;
        ready_bits -= 8;
        buff2 = (uint16 )(((int )buff2 << 8) | ((int )buff1 >> ready_bits));
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___2: /* CIL Label */ ;
    }
    while_break___0: 
    col --;
  }
  while_break___1: /* CIL Label */ ;
  }
  while_break: ;
  if (ready_bits > 0) {
    bytebuff = (uint8 )((int )buff2 >> 8);
    tmp___0 = dst;
    dst ++;
    *tmp___0 = bytebuff;
  }
  return (0);
}
}
static int reverseSamples24bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                                uint8 *obuff ) 
{ 
  int ready_bits ;
  uint32 col ;
  uint32 src_byte ;
  uint32 high_bit ;
  uint32 bit_offset ;
  uint32 match_bits ;
  uint32 mask_bits ;
  uint32 buff1 ;
  uint32 buff2 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  unsigned char *src ;
  unsigned char *dst ;
  tsample_t sample ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;
  unsigned char *tmp___1 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  high_bit = (uint32 )0;
  bit_offset = (uint32 )0;
  match_bits = (uint32 )0;
  mask_bits = (uint32 )0;
  buff1 = (uint32 )0;
  buff2 = (uint32 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  if ((unsigned long )ibuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamples24bits", (char const   *)"Invalid image or work buffer");
    return (1);
  } else
  if ((unsigned long )obuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamples24bits", (char const   *)"Invalid image or work buffer");
    return (1);
  }
  ready_bits = 0;
  mask_bits = 4294967295U >> (32 - (int )bps);
  dst = obuff;
  col = width;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col > 0U)) {
      goto while_break;
    }
    bit_offset = ((col - 1U) * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        high_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        high_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      src = ibuff + src_byte;
      match_bits = mask_bits << ((32U - high_bit) - (uint32 )bps);
      if (little_endian) {
        buff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
      } else {
        buff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
      }
      buff1 = (buff1 & match_bits) << high_bit;
      if (ready_bits < 16) {
        bytebuff2 = (uint8 )0;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      } else {
        bytebuff1 = (uint8 )(buff2 >> 24);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 16);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        ready_bits -= 16;
        buff2 = (buff2 << 16) | (buff1 >> ready_bits);
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col --;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 24);
    tmp___1 = dst;
    dst ++;
    *tmp___1 = bytebuff1;
    buff2 <<= 8;
    bytebuff2 = bytebuff1;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int reverseSamples32bits(uint16 spp , uint16 bps , uint32 width , uint8 *ibuff ,
                                uint8 *obuff ) 
{ 
  int ready_bits ;
  uint32 bit_offset ;
  uint32 src_byte ;
  uint32 high_bit ;
  uint32 col ;
  uint32 longbuff1 ;
  uint32 longbuff2 ;
  uint64 mask_bits ;
  uint64 match_bits ;
  uint64 buff1 ;
  uint64 buff2 ;
  uint64 buff3 ;
  uint8 bytebuff1 ;
  uint8 bytebuff2 ;
  uint8 bytebuff3 ;
  uint8 bytebuff4 ;
  unsigned char *src ;
  unsigned char *dst ;
  tsample_t sample ;
  unsigned char *tmp ;
  unsigned char *tmp___0 ;
  unsigned char *tmp___1 ;
  unsigned char *tmp___2 ;
  unsigned char *tmp___3 ;

  {
  ready_bits = 0;
  src_byte = (uint32 )0;
  high_bit = (uint32 )0;
  longbuff1 = (uint32 )0;
  longbuff2 = (uint32 )0;
  mask_bits = (uint64 )0;
  match_bits = (uint64 )0;
  buff1 = (uint64 )0;
  buff2 = (uint64 )0;
  buff3 = (uint64 )0;
  bytebuff1 = (uint8 )0;
  bytebuff2 = (uint8 )0;
  bytebuff3 = (uint8 )0;
  bytebuff4 = (uint8 )0;
  if ((unsigned long )ibuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamples32bits", (char const   *)"Invalid image or work buffer");
    return (1);
  } else
  if ((unsigned long )obuff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamples32bits", (char const   *)"Invalid image or work buffer");
    return (1);
  }
  ready_bits = 0;
  mask_bits = 18446744073709551615UL >> (64 - (int )bps);
  dst = obuff;
  col = width;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col > 0U)) {
      goto while_break;
    }
    bit_offset = ((col - 1U) * (uint32 )bps) * (uint32 )spp;
    sample = (tsample_t )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! ((int )sample < (int )spp)) {
        goto while_break___0;
      }
      if ((int )sample == 0) {
        src_byte = bit_offset / 8U;
        high_bit = bit_offset % 8U;
      } else {
        src_byte = (bit_offset + (uint32 )((int )sample * (int )bps)) / 8U;
        high_bit = (bit_offset + (uint32 )((int )sample * (int )bps)) % 8U;
      }
      src = ibuff + src_byte;
      match_bits = mask_bits << ((64U - high_bit) - (uint32 )bps);
      if (little_endian) {
        longbuff1 = (uint32 )(((((int )*(src + 0) << 24) | ((int )*(src + 1) << 16)) | ((int )*(src + 2) << 8)) | (int )*(src + 3));
        longbuff2 = longbuff1;
      } else {
        longbuff1 = (uint32 )(((((int )*(src + 3) << 24) | ((int )*(src + 2) << 16)) | ((int )*(src + 1) << 8)) | (int )*(src + 0));
        longbuff2 = longbuff1;
      }
      buff3 = ((uint64 )longbuff1 << 32) | (unsigned long )longbuff2;
      buff1 = (buff3 & match_bits) << high_bit;
      if (ready_bits < 32) {
        bytebuff4 = (uint8 )0;
        bytebuff3 = bytebuff4;
        bytebuff2 = bytebuff3;
        bytebuff1 = bytebuff2;
        buff2 |= buff1 >> ready_bits;
      } else {
        bytebuff1 = (uint8 )(buff2 >> 56);
        tmp = dst;
        dst ++;
        *tmp = bytebuff1;
        bytebuff2 = (uint8 )(buff2 >> 48);
        tmp___0 = dst;
        dst ++;
        *tmp___0 = bytebuff2;
        bytebuff3 = (uint8 )(buff2 >> 40);
        tmp___1 = dst;
        dst ++;
        *tmp___1 = bytebuff3;
        bytebuff4 = (uint8 )(buff2 >> 32);
        tmp___2 = dst;
        dst ++;
        *tmp___2 = bytebuff4;
        ready_bits -= 32;
        buff2 = (buff2 << 32) | (buff1 >> ready_bits);
      }
      ready_bits += (int )bps;
      sample = (tsample_t )((int )sample + 1);
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: 
    col --;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (ready_bits > 0)) {
      goto while_break___1;
    }
    bytebuff1 = (uint8 )(buff2 >> 56);
    tmp___3 = dst;
    dst ++;
    *tmp___3 = bytebuff1;
    buff2 <<= 8;
    ready_bits -= 8;
  }
  while_break___4: /* CIL Label */ ;
  }
  while_break___1: ;
  return (0);
}
}
static int reverseSamplesBytes(uint16 spp , uint16 bps , uint32 width , uint8 *src ,
                               uint8 *dst ) 
{ 
  int i ;
  uint32 col ;
  uint32 bytes_per_pixel ;
  uint32 col_offset ;
  uint8 bytebuff1 ;
  unsigned char swapbuff[32] ;
  uint8 *tmp ;

  {
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamplesBytes", (char const   *)"Invalid input or output buffer");
    return (1);
  } else
  if ((unsigned long )dst == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"reverseSamplesBytes", (char const   *)"Invalid input or output buffer");
    return (1);
  }
  bytes_per_pixel = (uint32 )(((int )bps * (int )spp + 7) / 8);
  if ((int )bps / 8 == 2) {
    goto case_2;
  }
  if ((int )bps / 8 == 3) {
    goto case_2;
  }
  if ((int )bps / 8 == 4) {
    goto case_2;
  }
  if ((int )bps / 8 == 8) {
    goto case_2;
  }
  if ((int )bps / 8 == 1) {
    goto case_1;
  }
  goto switch_default;
  case_2: 
  col = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (col < width / 2U)) {
      goto while_break;
    }
    col_offset = col * bytes_per_pixel;
    _TIFFmemcpy((void *)(swapbuff), (void const   *)(src + col_offset), (tmsize_t )bytes_per_pixel);
    _TIFFmemcpy((void *)(src + col_offset), (void const   *)((dst - col_offset) - bytes_per_pixel),
                (tmsize_t )bytes_per_pixel);
    _TIFFmemcpy((void *)((dst - col_offset) - bytes_per_pixel), (void const   *)(swapbuff),
                (tmsize_t )bytes_per_pixel);
    col ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  goto switch_break;
  case_1: 
  col = (uint32 )0;
  {
  while (1) {
    while_continue___0: /* CIL Label */ ;

    if (! (col < width / 2U)) {
      goto while_break___0;
    }
    i = 0;
    {
    while (1) {
      while_continue___1: /* CIL Label */ ;

      if (! (i < (int )spp)) {
        goto while_break___1;
      }
      bytebuff1 = *src;
      tmp = src;
      src ++;
      *tmp = *((dst - (int )spp) + i);
      *((dst - (int )spp) + i) = bytebuff1;
      i ++;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___1: 
    dst -= (int )spp;
    col ++;
  }
  while_break___3: /* CIL Label */ ;
  }
  while_break___0: ;
  goto switch_break;
  switch_default: 
  TIFFError((char const   *)"reverseSamplesBytes", (char const   *)"Unsupported bit depth %d",
            (int )bps);
  return (1);
  switch_break: ;
  return (0);
}
}
static int mirrorImage(uint16 spp , uint16 bps , uint16 mirror , uint32 width , uint32 length ,
                       unsigned char *ibuff ) 
{ 
  int shift_width ;
  uint32 bytes_per_pixel ;
  uint32 bytes_per_sample ;
  uint32 row ;
  uint32 rowsize ;
  uint32 row_offset ;
  unsigned char *line_buff ;
  unsigned char *src ;
  unsigned char *dst ;
  void *tmp ;
  int tmp___0 ;
  void *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;

  {
  line_buff = (unsigned char *)((void *)0);
  src = ibuff;
  rowsize = ((width * (uint32 )bps) * (uint32 )spp + 7U) / 8U;
  if ((int )mirror == 2) {
    goto case_2;
  }
  if ((int )mirror == 3) {
    goto case_2;
  }
  if ((int )mirror == 1) {
    goto case_1;
  }
  goto switch_default___0;
  case_2: 
  tmp = _TIFFmalloc((tmsize_t )rowsize);
  line_buff = (unsigned char *)tmp;
  if ((unsigned long )line_buff == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"mirrorImage", (char const   *)"Unable to allocate mirror line buffer of %1u bytes",
              rowsize);
    return (-1);
  }
  dst = ibuff + rowsize * (length - 1U);
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < length / 2U)) {
      goto while_break;
    }
    _TIFFmemcpy((void *)line_buff, (void const   *)src, (tmsize_t )rowsize);
    _TIFFmemcpy((void *)src, (void const   *)dst, (tmsize_t )rowsize);
    _TIFFmemcpy((void *)dst, (void const   *)line_buff, (tmsize_t )rowsize);
    src += rowsize;
    dst -= rowsize;
    row ++;
  }
  while_break___2: /* CIL Label */ ;
  }
  while_break: ;
  if (line_buff) {
    _TIFFfree((void *)line_buff);
  }
  if ((int )mirror == 2) {
    goto switch_break;
  }
  case_1: 
  if ((int )bps % 8 == 0) {
    row = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (row < length)) {
        goto while_break___0;
      }
      row_offset = row * rowsize;
      src = ibuff + row_offset;
      dst = (ibuff + row_offset) + rowsize;
      tmp___0 = reverseSamplesBytes(spp, bps, width, src, dst);
      if (tmp___0) {
        return (-1);
      }
      row ++;
    }
    while_break___3: /* CIL Label */ ;
    }
    while_break___0: ;
  } else {
    tmp___1 = _TIFFmalloc((tmsize_t )(rowsize + 1U));
    line_buff = (unsigned char *)tmp___1;
    if (! line_buff) {
      TIFFError((char const   *)"mirrorImage", (char const   *)"Unable to allocate mirror line buffer");
      return (-1);
    }
    bytes_per_sample = (uint32 )(((int )bps + 7) / 8);
    bytes_per_pixel = (uint32 )(((int )bps * (int )spp + 7) / 8);
    if (bytes_per_pixel < bytes_per_sample + 1U) {
      shift_width = (int )bytes_per_pixel;
    } else {
      shift_width = (int )(bytes_per_sample + 1U);
    }
    row = (uint32 )0;
    {
    while (1) {
      while_continue___1: /* CIL Label */ ;

      if (! (row < length)) {
        goto while_break___1;
      }
      row_offset = row * rowsize;
      src = ibuff + row_offset;
      _TIFFmemset((void *)line_buff, '\000', (tmsize_t )rowsize);
      if (shift_width == 1) {
        goto case_1___0;
      }
      if (shift_width == 2) {
        goto case_2___0;
      }
      if (shift_width == 5) {
        goto case_5;
      }
      if (shift_width == 4) {
        goto case_5;
      }
      if (shift_width == 3) {
        goto case_5;
      }
      goto switch_default;
      case_1___0: 
      tmp___2 = reverseSamples16bits(spp, bps, width, src, line_buff);
      if (tmp___2) {
        _TIFFfree((void *)line_buff);
        return (-1);
      }
      _TIFFmemcpy((void *)src, (void const   *)line_buff, (tmsize_t )rowsize);
      goto switch_break___0;
      case_2___0: 
      tmp___3 = reverseSamples24bits(spp, bps, width, src, line_buff);
      if (tmp___3) {
        _TIFFfree((void *)line_buff);
        return (-1);
      }
      _TIFFmemcpy((void *)src, (void const   *)line_buff, (tmsize_t )rowsize);
      goto switch_break___0;
      case_5: 
      tmp___4 = reverseSamples32bits(spp, bps, width, src, line_buff);
      if (tmp___4) {
        _TIFFfree((void *)line_buff);
        return (-1);
      }
      _TIFFmemcpy((void *)src, (void const   *)line_buff, (tmsize_t )rowsize);
      goto switch_break___0;
      switch_default: 
      TIFFError((char const   *)"mirrorImage", (char const   *)"Unsupported bit depth %d",
                (int )bps);
      _TIFFfree((void *)line_buff);
      return (-1);
      switch_break___0: 
      row ++;
    }
    while_break___4: /* CIL Label */ ;
    }
    while_break___1: ;
    if (line_buff) {
      _TIFFfree((void *)line_buff);
    }
  }
  goto switch_break;
  switch_default___0: 
  TIFFError((char const   *)"mirrorImage", (char const   *)"Invalid mirror axis %d",
            (int )mirror);
  return (-1);
  goto switch_break;
  switch_break: ;
  return (0);
}
}
static int invertImage(uint16 photometric , uint16 spp , uint16 bps , uint32 width ,
                       uint32 length , unsigned char *work_buff ) 
{ 
  uint32 row ;
  uint32 col ;
  unsigned char bytebuff1 ;
  unsigned char bytebuff2 ;
  unsigned char bytebuff3 ;
  unsigned char bytebuff4 ;
  unsigned char *src ;
  uint16 *src_uint16 ;
  uint32 *src_uint32 ;
  int tmp ;

  {
  if ((int )spp != 1) {
    TIFFError((char const   *)"invertImage", (char const   *)"Image inversion not supported for more than one sample per pixel");
    return (-1);
  }
  if ((int )photometric != 0) {
    if ((int )photometric != 1) {
      TIFFError((char const   *)"invertImage", (char const   *)"Only black and white and grayscale images can be inverted");
      return (-1);
    }
  }
  src = work_buff;
  if ((unsigned long )src == (unsigned long )((void *)0)) {
    TIFFError((char const   *)"invertImage", (char const   *)"Invalid crop buffer passed to invertImage");
    return (-1);
  }
  if ((int )bps == 32) {
    goto case_32;
  }
  if ((int )bps == 16) {
    goto case_16;
  }
  if ((int )bps == 8) {
    goto case_8;
  }
  if ((int )bps == 4) {
    goto case_4;
  }
  if ((int )bps == 2) {
    goto case_2;
  }
  if ((int )bps == 1) {
    goto case_1;
  }
  goto switch_default;
  case_32: 
  src_uint32 = (uint32 *)src;
  row = (uint32 )0;
  {
  while (1) {
    while_continue: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___0: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___0;
      }
      *src_uint32 = 0xFFFFFFFF - *src_uint32;
      src_uint32 ++;
      col ++;
    }
    while_break___12: /* CIL Label */ ;
    }
    while_break___0: 
    row ++;
  }
  while_break___11: /* CIL Label */ ;
  }
  while_break: ;
  goto switch_break;
  case_16: 
  src_uint16 = (uint16 *)src;
  row = (uint32 )0;
  {
  while (1) {
    while_continue___1: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break___1;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___2: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___2;
      }
      *src_uint16 = (uint16 )(65535 - (int )*src_uint16);
      src_uint16 ++;
      col ++;
    }
    while_break___14: /* CIL Label */ ;
    }
    while_break___2: 
    row ++;
  }
  while_break___13: /* CIL Label */ ;
  }
  while_break___1: ;
  goto switch_break;
  case_8: 
  row = (uint32 )0;
  {
  while (1) {
    while_continue___3: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break___3;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___4: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___4;
      }
      *src = (unsigned char )(255 - (int )*src);
      src ++;
      col ++;
    }
    while_break___16: /* CIL Label */ ;
    }
    while_break___4: 
    row ++;
  }
  while_break___15: /* CIL Label */ ;
  }
  while_break___3: ;
  goto switch_break;
  case_4: 
  row = (uint32 )0;
  {
  while (1) {
    while_continue___5: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break___5;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___6: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___6;
      }
      bytebuff1 = (unsigned char )(16 - (int )((uint8 )((int )*src & (240 >> 4))));
      bytebuff2 = (unsigned char )(16 - ((int )*src & 15));
      *src = (unsigned char )(((int )bytebuff1 << 4) & (int )bytebuff2);
      src ++;
      col ++;
    }
    while_break___18: /* CIL Label */ ;
    }
    while_break___6: 
    row ++;
  }
  while_break___17: /* CIL Label */ ;
  }
  while_break___5: ;
  goto switch_break;
  case_2: 
  row = (uint32 )0;
  {
  while (1) {
    while_continue___7: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break___7;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___8: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___8;
      }
      bytebuff1 = (unsigned char )(4 - (int )((uint8 )((int )*src & (192 >> 6))));
      bytebuff2 = (unsigned char )(4 - (int )((uint8 )((int )*src & (48 >> 4))));
      bytebuff3 = (unsigned char )(4 - (int )((uint8 )((int )*src & (12 >> 2))));
      bytebuff4 = (unsigned char )(4 - (int )((uint8 )((int )*src & 3)));
      if ((int )bytebuff1 << 6) {
        tmp = 1;
      } else
      if ((int )bytebuff2 << 4) {
        tmp = 1;
      } else
      if ((int )bytebuff3 << 2) {
        tmp = 1;
      } else
      if (bytebuff4) {
        tmp = 1;
      } else {
        tmp = 0;
      }
      *src = (unsigned char )tmp;
      src ++;
      col ++;
    }
    while_break___20: /* CIL Label */ ;
    }
    while_break___8: 
    row ++;
  }
  while_break___19: /* CIL Label */ ;
  }
  while_break___7: ;
  goto switch_break;
  case_1: 
  row = (uint32 )0;
  {
  while (1) {
    while_continue___9: /* CIL Label */ ;

    if (! (row < length)) {
      goto while_break___9;
    }
    col = (uint32 )0;
    {
    while (1) {
      while_continue___10: /* CIL Label */ ;

      if (! (col < width)) {
        goto while_break___10;
      }
      *src = (unsigned char )(~ ((int )*src));
      src ++;
      col += (uint32 )(8 / ((int )spp * (int )bps));
    }
    while_break___22: /* CIL Label */ ;
    }
    while_break___10: 
    row ++;
  }
  while_break___21: /* CIL Label */ ;
  }
  while_break___9: ;
  goto switch_break;
  switch_default: 
  TIFFError((char const   *)"invertImage", (char const   *)"Unsupported bit depth %d",
            (int )bps);
  return (-1);
  switch_break: ;
  return (0);
}
}
